"""Regression tests for the orchestration. Run: python -m pytest tests -q"""
import pytest

from core.contracts import ContractEngine
from core.loader import load_package
from core.runtime import SpecialistAgent, parse_action


@pytest.fixture
def bench():
    return SpecialistAgent()


# ---------------------------------------------------------------- package

def test_package_integrity_is_clean():
    pkg = load_package()
    assert pkg.validate() == []
    assert len(pkg.agents) == 9
    assert len(pkg.skills) == 59
    assert pkg.master.id == "onboard360ai"


def test_master_is_also_a_subagent_of_the_specialist_agent():
    pkg = load_package()
    assert "SUB-AGENT" in pkg.master.system_instructions.upper()


def test_every_component_carries_runtime_disclosure():
    pkg = load_package()
    for a in pkg.agents.values():
        assert "RUNTIME DISCLOSURE" in a.system_instructions
    for s in pkg.skills.values():
        assert "RUNTIME DISCLOSURE" in s.system_instructions


# ---------------------------------------------------------------- protocol

def test_parse_action_from_fenced_json():
    a = parse_action('prose\n```json\n{"action":"reply","message":"hi"}\n```')
    assert a["action"] == "reply" and a["message"] == "hi"


def test_parse_action_coerces_bare_prose_to_reply():
    a = parse_action("just talking, no envelope")
    assert a["action"] == "reply"


# ------------------------------------------------------------ orchestration

def test_opening_turn_stays_on_master(bench):
    t = bench.send("hello")
    assert t.stack == ["onboard360ai"]
    assert "ICMP Partner Onboarding" in t.reply


def test_implementation_branch_hands_off_to_intake_verification(bench):
    bench.send("hello")
    t = bench.send("actual project implementation")
    assert t.stack[-1] == "intake-verification"
    assert any(e["kind"] == "handoff" for e in t.trace)


def test_poc_branch_hands_off_to_poc_assistance(bench):
    bench.send("hello")
    t = bench.send("we are running a poc")
    assert t.stack[-1] == "poc-assistance"


def test_intake_retrieval_harvests_state_with_system_provenance(bench):
    for m in ("hello", "actual project implementation", "LJKX-1234"):
        bench.send(m)
    assert bench.state.get("intakeKey") == "LJKX-1234"
    assert bench.state.provenance_of("intakeKey") == "system"
    assert bench.state.get("allocatedScrumTeam") == "Payments Content Services"


def test_full_flow_creates_two_distinct_tickets_in_the_scrum_project(bench):
    for m in ("hello", "implementation", "LJKX-1234", "continue", "continue", "continue"):
        bench.send(m)
    cap = bench.state.get("capacityPlanningTicket")
    spli = bench.state.get("spliTicket")
    assert cap and spli and cap != spli
    assert cap.startswith("PAYSVC-") and spli.startswith("PAYSVC-")


def test_unresolved_intake_fields_become_open_items(bench):
    for m in ("hello", "implementation", "LJKX-1234"):
        bench.send(m)
    keys = {i.key for i in bench.state.open_items}
    assert "ownershipContacts" in keys


# ---------------------------------------------------------------- contracts

def test_contracts_registered_at_all_four_points():
    reg = ContractEngine.registered()
    assert set(reg) == {"pre_model", "post_model", "pre_tool", "post_tool"}
    assert all(reg.values())


def test_br01_blocks_a_malformed_intake_key(bench):
    bench.send("hello")
    bench.send("implementation")
    t = bench.send("force-badkey LJKX-1234")
    fired = [e for e in t.trace if e["kind"] == "contract" and e["rule"] == "BR-01"]
    assert fired, "BR-01 key format contract did not fire"


def test_br23_blocks_an_opening_message_without_runtime_disclosure(bench):
    t = bench.send("force-nodisclose hello")
    fired = [e for e in t.trace if e["kind"] == "contract" and e["rule"] == "BR-23"]
    assert fired, "BR-23 runtime disclosure contract did not fire"


def test_undeclared_tool_is_blocked(bench):
    bench.send("hello")
    bench.send("implementation")
    t = bench.send("force-undeclared")
    fired = [e for e in t.trace if e["label"] == "tool_in_scope"]
    assert fired, "tool scope contract did not fire"


def test_br21_blocks_ticket_creation_against_ljkx(bench):
    for m in ("hello", "implementation", "LJKX-1234", "force-ljkx", "force-ljkx"):
        t = bench.send(m)
        if [e for e in t.trace if e["rule"] == "BR-21" and e["status"] == "fail"]:
            return
    pytest.fail("BR-21 project key contract did not fire")


def test_retry_budget_stops_a_stuck_agent(bench):
    bench.send("hello")
    bench.send("implementation")
    t = bench.send("force-badkey LJKX-1234")
    assert t.steps <= 12
    assert "Stopped" in t.reply or "limit" in t.reply


# --------------------------------------------------------------- isolation

def test_reset_clears_state_stack_and_trace(bench):
    bench.send("hello")
    bench.send("implementation")
    bench.reset()
    assert bench.stack == ["onboard360ai"]
    assert bench.state.values == {}
    assert bench.trace.events == []
