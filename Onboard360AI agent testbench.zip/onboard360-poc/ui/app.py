"""FastAPI server. Serves the chat UI and exposes the runtime over HTTP."""
from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from config.settings import settings
from core.loader import load_package
from core.runtime import SpecialistAgent
from llm.registry import get_client, reset_cache

STATIC = Path(__file__).parent / "static"

app = FastAPI(title="Onboard360AI — Agent Test Bench", version="0.1.0")

# One session per process. This is a single-operator test bench, not a service.
_package = load_package()
_agent: SpecialistAgent | None = None


def bench() -> SpecialistAgent:
    global _agent
    if _agent is None:
        _agent = SpecialistAgent(package=_package)
    return _agent


class ChatIn(BaseModel):
    message: str


class ProviderIn(BaseModel):
    provider: str


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")


@app.get("/api/topology")
def topology():
    return bench().topology()


@app.get("/api/health")
def health():
    problems = _package.validate()
    try:
        llm = get_client().health()
    except Exception as exc:  # provider misconfiguration must not 500 the page
        llm = {"status": "error", "detail": str(exc), "provider": settings.llm_provider}
    return {
        "package": {
            "path": str(settings.package_path),
            "agents": len(_package.agents),
            "skills": len(_package.skills),
            "rules": len(_package.business_rules),
            "integrity": problems or "clean",
        },
        "llm": llm,
        "toolMode": settings.tool_mode,
        "contracts": {"enabled": settings.enforce_contracts, "mode": settings.contract_mode},
        "limits": {
            "maxStepsPerTurn": settings.max_steps_per_turn,
            "maxHandoffDepth": settings.max_handoff_depth,
            "maxRetriesPerTurn": settings.max_retries_per_turn,
        },
    }


@app.post("/api/chat")
def chat(body: ChatIn):
    if not body.message.strip():
        raise HTTPException(400, "Message is empty.")
    turn = bench().send(body.message)
    return JSONResponse({
        "reply": turn.reply,
        "trace": turn.trace,
        "stack": turn.stack,
        "state": turn.state,
        "steps": turn.steps,
        "contractFailures": turn.contract_failures,
    })


@app.post("/api/reset")
def reset():
    bench().reset()
    return {"ok": True}


@app.post("/api/provider")
def switch_provider(body: ProviderIn):
    """Swap the LLM provider without restarting — useful when wiring the enterprise endpoint."""
    global _agent
    reset_cache()
    settings.llm_provider = body.provider
    try:
        client = get_client(body.provider)
    except Exception as exc:
        raise HTTPException(400, f"Could not initialise provider '{body.provider}': {exc}")
    _agent = SpecialistAgent(package=_package, llm=client)
    return {"ok": True, "provider": client.name, "model": client.model}


@app.get("/api/agent/{agent_id}")
def agent_detail(agent_id: str):
    agent = _package.agents.get(agent_id)
    if not agent:
        raise HTTPException(404, f"No agent '{agent_id}'")
    return {
        "id": agent.id, "name": agent.name, "type": agent.type, "branch": agent.branch,
        "description": agent.description, "goals": agent.goals, "phase": agent.phase,
        "invokes": agent.invokes, "invokedBy": agent.invoked_by,
        "tools": [{"name": t.name, "status": t.status, "phase": t.phase,
                   "functions": t.function_names} for t in agent.tools],
        "skills": [{"id": s.id, "name": s.name, "type": s.skill_type, "phase": s.phase,
                    "description": s.description, "rules": s.business_rules}
                   for s in _package.skills_for(agent.id)],
        "systemInstructions": agent.system_instructions,
    }


@app.get("/api/skill/{skill_id}")
def skill_detail(skill_id: str):
    skill = _package.skills.get(skill_id)
    if not skill:
        raise HTTPException(404, f"No skill '{skill_id}'")
    return {
        "id": skill.id, "name": skill.name, "owner": skill.owner_agent,
        "type": skill.skill_type, "phase": skill.phase, "parent": skill.parent_skill,
        "description": skill.description, "instructions": skill.instructions,
        "rules": skill.business_rules,
        "questions": [q.__dict__ for q in skill.questions],
        "referenceMaterials": skill.reference_materials,
        "tools": [t.name for t in skill.tools],
        "systemInstructions": skill.system_instructions,
        "futureImplementation": skill.future_implementation,
    }


app.mount("/static", StaticFiles(directory=STATIC), name="static")
