"""Resolves the configured provider. Register additional providers here."""
from __future__ import annotations

from config.settings import settings
from llm.base import LLMClient

_CACHE: dict[str, LLMClient] = {}

AVAILABLE = ("enterprise", "openai_compatible", "scripted")


def get_client(provider: str | None = None) -> LLMClient:
    provider = (provider or settings.llm_provider).lower()
    if provider in _CACHE:
        return _CACHE[provider]

    if provider == "enterprise":
        from llm.providers.enterprise import EnterpriseClient
        client: LLMClient = EnterpriseClient(model=settings.llm_model)
    elif provider == "openai_compatible":
        from llm.providers.openai_compatible import OpenAICompatibleClient
        client = OpenAICompatibleClient(model=settings.llm_model)
    elif provider == "scripted":
        from llm.providers.scripted import ScriptedClient
        client = ScriptedClient(model="scripted-deterministic")
    else:
        raise ValueError(
            f"Unknown LLM provider '{provider}'. Set LLM_PROVIDER to one of: {', '.join(AVAILABLE)}."
        )

    _CACHE[provider] = client
    return client


def reset_cache() -> None:
    _CACHE.clear()
