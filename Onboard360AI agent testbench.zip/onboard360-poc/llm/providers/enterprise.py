"""
=============================================================================
 ENTERPRISE LLM CONNECTOR  —  THIS IS THE FILE YOU EDIT
=============================================================================

This is the only place the POC needs to know about your enterprise LLM.
Nothing else in the codebase imports a provider directly.

WHAT TO DO
----------
1. Put your endpoint, credentials and model name in `.env` (copy `.env.example`).
2. Fill in `_build_request()` and `_parse_response()` below to match your
   gateway's contract. Both have worked examples for the three shapes we most
   commonly see in enterprise gateways.
3. Set LLM_PROVIDER=enterprise in `.env`.
4. Verify with:  python -m scripts.check_llm

WHAT THE RUNTIME NEEDS BACK
---------------------------
A single string of assistant text. The agent runtime handles its own action
protocol on top of that text — it does NOT require native tool/function calling,
so a plain completions endpoint is sufficient.

AUTH PATTERNS SUPPORTED OUT OF THE BOX
--------------------------------------
- Static bearer token            -> LLM_API_KEY
- Custom header name             -> LLM_AUTH_HEADER (default "Authorization")
- Header prefix                  -> LLM_AUTH_PREFIX (default "Bearer")
- Extra static headers as JSON   -> LLM_EXTRA_HEADERS
- mTLS client certificate        -> LLM_CLIENT_CERT / LLM_CLIENT_KEY
- Private CA bundle              -> LLM_CA_BUNDLE
- OAuth2 client credentials      -> implement `_fetch_oauth_token()` below
- Corporate proxy                -> HTTPS_PROXY / HTTP_PROXY (honoured by httpx)
"""
from __future__ import annotations

import json
from typing import Any

import httpx

from config.settings import settings
from llm.base import LLMClient, LLMError, Message


class EnterpriseClient(LLMClient):
    name = "enterprise"

    def __init__(self, model: str, **kwargs):
        super().__init__(model, **kwargs)
        if not settings.llm_endpoint:
            raise LLMError(
                "LLM_ENDPOINT is not set. Copy .env.example to .env and set your "
                "enterprise endpoint, or run with LLM_PROVIDER=scripted to test "
                "orchestration without a live model."
            )
        self._client = httpx.Client(
            timeout=settings.llm_timeout_seconds,
            verify=settings.llm_ca_bundle or True,
            cert=self._client_cert(),
            follow_redirects=True,
        )

    # ------------------------------------------------------------------ auth

    def _client_cert(self):
        if settings.llm_client_cert and settings.llm_client_key:
            return (settings.llm_client_cert, settings.llm_client_key)
        if settings.llm_client_cert:
            return settings.llm_client_cert
        return None

    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if settings.llm_api_key:
            prefix = settings.llm_auth_prefix.strip()
            value = f"{prefix} {settings.llm_api_key}".strip() if prefix else settings.llm_api_key
            headers[settings.llm_auth_header] = value
        if settings.llm_extra_headers:
            try:
                headers.update(json.loads(settings.llm_extra_headers))
            except json.JSONDecodeError as exc:
                raise LLMError(f"LLM_EXTRA_HEADERS is not valid JSON: {exc}") from exc
        return headers

    def _fetch_oauth_token(self) -> str:
        """
        TODO (only if your gateway uses OAuth2 client credentials).

        Replace the body with something like:

            resp = httpx.post(
                settings.llm_token_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": settings.llm_client_id,
                    "client_secret": settings.llm_client_secret,
                    "scope": settings.llm_scope,
                },
                timeout=30,
            )
            resp.raise_for_status()
            return resp.json()["access_token"]

        Then call it from `_headers()` instead of using LLM_API_KEY, and cache
        the token until shortly before its expiry.
        """
        raise NotImplementedError("OAuth2 flow not configured — using static token auth.")

    # --------------------------------------------------------------- request

    def _build_request(self, messages: list[Message], **kwargs) -> dict:
        """
        TODO: shape this to match your gateway.

        The default below is the OpenAI-compatible chat shape, which most
        enterprise gateways expose. Two common alternatives are shown after it —
        delete whichever you do not need.
        """
        # ---- Shape A: OpenAI-compatible chat completions (default) ----------
        return {
            "model": self.model,
            "messages": [m.as_dict() for m in messages],
            "temperature": kwargs.get("temperature", settings.llm_temperature),
            "max_tokens": kwargs.get("max_tokens", settings.llm_max_tokens),
        }

        # ---- Shape B: Anthropic-style (system hoisted out of messages) ------
        # system = "\n\n".join(m.content for m in messages if m.role == "system")
        # turns = [m.as_dict() for m in messages if m.role != "system"]
        # return {
        #     "model": self.model,
        #     "system": system,
        #     "messages": turns,
        #     "max_tokens": kwargs.get("max_tokens", settings.llm_max_tokens),
        # }

        # ---- Shape C: single flattened prompt --------------------------------
        # prompt = "\n\n".join(f"{m.role.upper()}:\n{m.content}" for m in messages)
        # return {"model": self.model, "prompt": prompt,
        #         "max_tokens": kwargs.get("max_tokens", settings.llm_max_tokens)}

    def _parse_response(self, payload: dict) -> str:
        """
        TODO: shape this to match your gateway's response.

        Tries the common shapes in order and raises with the actual payload keys
        if none match, so a mismatch is obvious rather than silent.
        """
        # Shape A — OpenAI-compatible
        try:
            choice = payload["choices"][0]
            if "message" in choice:
                return choice["message"]["content"]
            if "text" in choice:
                return choice["text"]
        except (KeyError, IndexError, TypeError):
            pass

        # Shape B — Anthropic-style content blocks
        try:
            blocks = payload["content"]
            return "".join(b.get("text", "") for b in blocks if isinstance(b, dict))
        except (KeyError, TypeError):
            pass

        # Shape C — flat field
        for key in ("output", "completion", "generated_text", "response", "text"):
            if isinstance(payload.get(key), str):
                return payload[key]

        raise LLMError(
            "Could not find assistant text in the gateway response. "
            f"Top-level keys were: {sorted(payload.keys()) if isinstance(payload, dict) else type(payload)}. "
            "Edit EnterpriseClient._parse_response() to match your contract."
        )

    # ---------------------------------------------------------------- invoke

    def _invoke(self, messages: list[Message], **kwargs) -> tuple[str, Any]:
        body = self._build_request(messages, **kwargs)
        try:
            resp = self._client.post(settings.llm_endpoint, json=body, headers=self._headers())
        except httpx.RequestError as exc:
            raise LLMError(f"Could not reach {settings.llm_endpoint}: {exc}") from exc

        if resp.status_code >= 400:
            raise LLMError(
                f"Gateway returned {resp.status_code}. Body: {resp.text[:600]}"
            )
        try:
            payload = resp.json()
        except json.JSONDecodeError as exc:
            raise LLMError(f"Gateway returned non-JSON: {resp.text[:400]}") from exc

        return self._parse_response(payload), payload

    def health(self) -> dict:
        try:
            r = self.complete([Message("user", "Reply with the single word: ready")])
            return {
                "provider": self.name,
                "model": self.model,
                "endpoint": settings.llm_endpoint,
                "status": "ok",
                "latency_ms": r.latency_ms,
                "sample": r.text.strip()[:80],
            }
        except LLMError as exc:
            return {
                "provider": self.name,
                "model": self.model,
                "endpoint": settings.llm_endpoint,
                "status": "error",
                "detail": str(exc),
            }
