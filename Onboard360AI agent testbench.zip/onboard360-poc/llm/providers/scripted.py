"""
Deterministic, offline provider.

Purpose: test the orchestration itself — routing, handoffs, skill activation,
contract enforcement, tool calls, state provenance — without a live model and
without network access. It emits valid action envelopes by reading the ACTIVE
AGENT marker the runtime injects into the system prompt.

It is a test double, not a model. It does not reason; it follows the documented
happy path plus a few deliberate failure paths so contract violations can be
exercised on demand.

Trigger words in a user message force specific behaviour:
  "force-badkey"    -> agent attempts an invalid Jira key (BR-01 contract fires)
  "force-undeclared"-> agent attempts a tool it has not declared (scope contract fires)
  "force-ljkx"      -> agent attempts ticket creation against LJKX (BR-21 contract fires)
  "force-nodisclose"-> agent opens without runtime disclosure (BR-23 contract fires)
"""
from __future__ import annotations

import json
import re
from typing import Any

from llm.base import LLMClient, Message

DISCLOSE = (
    "Integrated today: Jira via MCP (live). Everything else returns Confluence links for now — "
    "the next phase reads those pages and answers from them directly."
)


def _envelope(action: str, **fields) -> str:
    payload = {"thought": fields.pop("thought", "scripted"), "action": action}
    payload.update(fields)
    return "```json\n" + json.dumps(payload, indent=2) + "\n```"


class ScriptedClient(LLMClient):
    name = "scripted"

    def _active_agent(self, messages: list[Message]) -> str:
        for m in messages:
            if m.role == "system":
                found = re.search(r"ACTIVE AGENT:\s*([a-z0-9\-]+)", m.content)
                if found:
                    return found.group(1)
        return "onboard360ai"

    def _active_skill(self, messages: list[Message]) -> str | None:
        for m in messages:
            if m.role == "system":
                found = re.search(r"ACTIVE SKILL:\s*([a-z0-9\-]+)", m.content)
                if found:
                    return found.group(1)
        return None

    def _transcript(self, messages: list[Message]) -> str:
        return "\n".join(m.content.lower() for m in messages if m.role in ("user", "assistant"))

    def _user_turns(self, messages: list[Message]) -> str:
        """Only what the partner actually said. The agent's own questions mention
        both branches, so branch detection must not read assistant text."""
        return "\n".join(
            m.content.lower() for m in messages
            if m.role == "user" and not m.content.startswith(("[TOOL RESULT", "[HANDOFF", "[SKILL", "[CONTRACT", "[ERROR"))
        )

    def _last_user(self, messages: list[Message]) -> str:
        for m in reversed(messages):
            if m.role == "user":
                return m.content.lower()
        return ""

    def _sys(self, messages: list[Message]) -> str:
        """System prompt text — carries the authoritative JOURNEY STATE block."""
        return "\n".join(m.content for m in messages if m.role == "system").lower()

    def _invoke(self, messages: list[Message], **kwargs) -> tuple[str, Any]:
        agent = self._active_agent(messages)
        skill = self._active_skill(messages)
        last = self._last_user(messages)
        convo = self._transcript(messages)
        state = self._sys(messages)

        def has_state(key: str) -> bool:
            return f"{key.lower()} =" in state

        def done(skill_id: str) -> bool:
            return f"done:{skill_id}" in convo

        def finish(skill_id: str, note: str) -> tuple[str, Any]:
            return _envelope("goal_met",
                             message=f"{DISCLOSE}\n\n{note}\n\nDONE:{skill_id}",
                             thought="skill complete"), None

        # ---- forced failure paths, for exercising the contract engine --------
        if "force-undeclared" in last:
            return _envelope("tool_call", tool="Venafi", function="request_certificate",
                             args={"subject": "CN=EREP"},
                             thought="deliberately calling a tool this agent has not declared"), None
        if "force-nodisclose" in last:
            return _envelope("reply", message="Right, let's begin.",
                             thought="deliberately omitting runtime disclosure"), None

        # ---- skill-scoped behaviour -----------------------------------------
        if skill == "ljkx-key-format-validation":
            if has_state("intakeKey"):
                return finish(skill, "Intake key validated and the issue retrieved.")
            found = re.search(r"\b([A-Za-z]{2,}-\d+)\b", convo.upper())
            key = found.group(1) if found else ""
            if "force-badkey" in convo:
                key = "TEST-5678"
            return _envelope("tool_call", tool="Jira MCP", function="get_issue",
                             args={"issueKey": key.upper()},
                             thought=f"format-checked {key}, now retrieving"), None

        if skill == "scrum-team-project-key-resolution":
            if "get_project" in convo:
                return finish(skill, "Scrum team project key resolved and confirmed to exist.")
            candidate = "PAYSVC"
            if has_state("scrumTeamProjectKey"):
                found = re.search(r"scrumteamprojectkey = ([a-z0-9]+)", state)
                if found:
                    candidate = found.group(1).upper()
            return _envelope("tool_call", tool="Jira MCP", function="get_project",
                             args={"projectKey": candidate},
                             thought="confirming the resolved key before any create_issue"), None

        if skill == "capacity-planning-ticket-creation":
            if has_state("capacityPlanningTicket"):
                return finish(skill, "Capacity planning ticket raised in the scrum team's project.")
            project = "LJKX" if "force-ljkx" in convo else "PAYSVC"
            return _envelope("tool_call", tool="Jira MCP", function="create_issue",
                             args={"projectKey": project, "issueType": "Task",
                                   "summary": "ICMP capacity planning - declared volume profile",
                                   "description": "Per-operation volumes, peaks, growth. Volume-change obligation restated."},
                             thought="raising capacity planning ticket"), None

        if skill == "spli-ticket-creation":
            if has_state("spliTicket"):
                return finish(skill, "SPLI ticket raised and linked to the intake.")
            return _envelope("tool_call", tool="Jira MCP", function="create_issue",
                             args={"projectKey": "PAYSVC", "issueType": "Task",
                                   "summary": "SPLI load testing - ICMP onboarding",
                                   "description": "Derived cases: steady-state, peak, special-day, sustained."},
                             thought="raising SPLI ticket"), None

        if skill == "scope-driven-collection-build":
            if has_state("postmanCollection"):
                return finish(skill, "Collection built from the approved scope set.")
            return _envelope("tool_call", tool="Postman Collection Generator", function="build_collection",
                             args={"scopes": ["icmp.ingest", "icmp.search"], "environment": "Innovation",
                                   "serviceAccount": "svc-icmp-innovation",
                                   "baseUrl": "https://apigee.internal/icmp/v1"},
                             thought="building from approved scope only"), None

        if skill:
            return finish(skill, f"Skill `{skill}` completed against the captured context.")

        # ---- agent-scoped behaviour -----------------------------------------
        if agent == "onboard360ai":
            said = self._user_turns(messages)
            if not any(w in said for w in ("poc", "implementation", "project")):
                return _envelope(
                    "reply",
                    message=(f"Welcome to ICMP Partner Onboarding - I'm Onboard360AI.\n\n{DISCLOSE}\n\n"
                             "Before anything else I need to determine your onboarding eligibility status. "
                             "Are you running a POC, or an actual project implementation?"),
                    thought="opening plus eligibility gate"), None
            if "poc" in said and "implementation" not in said:
                return _envelope("handoff", agent_id="poc-assistance",
                                 reason="Partner confirmed POC - no intake required",
                                 thought="routing to POC branch"), None
            return _envelope("handoff", agent_id="intake-verification",
                             reason="Implementation path - intake status must be resolved first",
                             thought="routing to implementation branch"), None

        if agent == "poc-assistance":
            if not done("intake-free-activity-catalogue"):
                return _envelope("invoke_skill", skill_id="intake-free-activity-catalogue",
                                 thought="deliver the intake-free activity list first"), None
            if not done("documentation-pointers"):
                return _envelope("invoke_skill", skill_id="documentation-pointers",
                                 thought="point at the specific documentation per activity"), None
            return _envelope(
                "reply",
                message=(f"{DISCLOSE}\n\nPOC scope, stated upfront: no intake to the ECM or SSAT team, "
                         "no LOB prioritisation, no scrum team, Innovation environment only.\n\n"
                         "Without an intake you can connect to Innovation APIs via Apigee, ingest "
                         "documents, search and read them, use the APIs generally, and request ICMP UI "
                         "access. Which of those do you want to start with?"),
                thought="POC catalogue delivered"), None

        if agent == "intake-verification":
            if not has_state("intakeKey"):
                if not re.search(r"\b[A-Za-z]{2,}-\d+\b", convo.upper()):
                    return _envelope("reply",
                                     message=(f"{DISCLOSE}\n\nHas an ECM onboarding intake already been "
                                              "submitted? If so, give me the Jira number - it must look "
                                              "like LJKX-1234."),
                                     thought="asking for the intake number"), None
                return _envelope("invoke_skill", skill_id="ljkx-key-format-validation",
                                 thought="validate before any tool call"), None
            if not done("scrum-team-project-key-resolution"):
                return _envelope("invoke_skill", skill_id="scrum-team-project-key-resolution",
                                 thought="resolve the downstream ticket project key"), None
            return _envelope("handoff", agent_id="foundational-setup",
                             reason="Intake confirmed; scrum team project key resolved",
                             thought="advancing"), None

        if agent == "foundational-setup":
            if not done("icmp-capabilities-catalogue"):
                return _envelope("invoke_skill", skill_id="icmp-capabilities-catalogue",
                                 thought="establish what the partner actually needs"), None
            if not done("art-aims-routing-boundary"):
                return _envelope("invoke_skill", skill_id="art-aims-routing-boundary",
                                 thought="determine ART vs AIMS for access requests"), None
            return _envelope("handoff", agent_id="volume-assessment",
                             reason="Identity, access and capability set established",
                             thought="advancing"), None

        if agent == "volume-assessment":
            if not done("per-operation-volume-collection"):
                return _envelope("invoke_skill", skill_id="per-operation-volume-collection",
                                 thought="collect volumes per operation"), None
            if not has_state("capacityPlanningTicket"):
                return _envelope("invoke_skill", skill_id="capacity-planning-ticket-creation",
                                 thought="raising the ticket is part of the goal"), None
            return _envelope("handoff", agent_id="load-testing-spli",
                             reason="Volume profile captured and capacity ticket raised",
                             thought="advancing"), None

        if agent == "load-testing-spli":
            if not done("test-case-derivation"):
                return _envelope("invoke_skill", skill_id="test-case-derivation",
                                 thought="derive cases from the volume profile"), None
            if not has_state("spliTicket"):
                return _envelope("invoke_skill", skill_id="spli-ticket-creation",
                                 thought="raise the SPLI ticket"), None
            return _envelope("goal_met",
                             message=f"{DISCLOSE}\n\nSPLI test cases derived and the ticket raised.",
                             thought="goal met"), None

        return _envelope("goal_met",
                         message=f"{DISCLOSE}\n\n`{agent}` has nothing further scripted in this test double.",
                         thought="fallback"), None

    def health(self) -> dict:
        return {"provider": self.name, "model": self.model, "status": "ok",
                "note": "Deterministic test double - no network, no model."}
