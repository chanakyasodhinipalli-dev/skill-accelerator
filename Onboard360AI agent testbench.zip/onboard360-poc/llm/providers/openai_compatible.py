"""Generic OpenAI-compatible endpoint. Useful for local testing against
Ollama, vLLM, LM Studio or any gateway that speaks /v1/chat/completions."""
from __future__ import annotations

from typing import Any

import httpx

from config.settings import settings
from llm.base import LLMClient, LLMError, Message


class OpenAICompatibleClient(LLMClient):
    name = "openai_compatible"

    def __init__(self, model: str, **kwargs):
        super().__init__(model, **kwargs)
        self.base = (settings.llm_endpoint or "http://localhost:11434/v1/chat/completions")
        self._client = httpx.Client(timeout=settings.llm_timeout_seconds)

    def _invoke(self, messages: list[Message], **kwargs) -> tuple[str, Any]:
        headers = {"Content-Type": "application/json"}
        if settings.llm_api_key:
            headers["Authorization"] = f"Bearer {settings.llm_api_key}"
        body = {
            "model": self.model,
            "messages": [m.as_dict() for m in messages],
            "temperature": kwargs.get("temperature", settings.llm_temperature),
            "max_tokens": kwargs.get("max_tokens", settings.llm_max_tokens),
        }
        try:
            resp = self._client.post(self.base, json=body, headers=headers)
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            raise LLMError(f"{self.base}: {exc}") from exc
        payload = resp.json()
        return payload["choices"][0]["message"]["content"], payload
