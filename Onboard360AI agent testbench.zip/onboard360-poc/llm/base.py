"""Provider-agnostic LLM interface.

Every provider implements `_invoke()`. The runtime never imports a provider
directly — it resolves one through `llm.registry.get_client()`, so swapping in
the enterprise endpoint requires no change anywhere else in the codebase.
"""
from __future__ import annotations

import abc
import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Message:
    role: str  # "system" | "user" | "assistant"
    content: str

    def as_dict(self) -> dict:
        return {"role": self.role, "content": self.content}


@dataclass
class LLMResponse:
    text: str
    provider: str
    model: str
    latency_ms: int = 0
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    raw: Any = None
    meta: dict = field(default_factory=dict)


class LLMError(RuntimeError):
    """Raised for any provider failure. The runtime degrades rather than crashing."""


class LLMClient(abc.ABC):
    name: str = "base"

    def __init__(self, model: str, **kwargs):
        self.model = model
        self.options = kwargs

    @abc.abstractmethod
    def _invoke(self, messages: list[Message], **kwargs) -> tuple[str, Any]:
        """Return (text, raw_response). Raise LLMError on failure."""

    def complete(self, messages: list[Message], **kwargs) -> LLMResponse:
        started = time.time()
        text, raw = self._invoke(messages, **kwargs)
        usage = {}
        if isinstance(raw, dict):
            usage = raw.get("usage") or {}
        return LLMResponse(
            text=text,
            provider=self.name,
            model=self.model,
            latency_ms=int((time.time() - started) * 1000),
            prompt_tokens=usage.get("prompt_tokens"),
            completion_tokens=usage.get("completion_tokens"),
            raw=raw,
        )

    def health(self) -> dict:
        return {"provider": self.name, "model": self.model, "status": "unknown"}
