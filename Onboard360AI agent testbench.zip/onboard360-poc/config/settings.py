"""Configuration. Everything is environment-driven; see .env.example."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # dotenv is optional
    pass

ROOT = Path(__file__).resolve().parent.parent


def _b(key: str, default: bool = False) -> bool:
    return os.getenv(key, str(default)).strip().lower() in ("1", "true", "yes", "on")


def _i(key: str, default: int) -> int:
    try:
        return int(os.getenv(key, default))
    except ValueError:
        return default


def _f(key: str, default: float) -> float:
    try:
        return float(os.getenv(key, default))
    except ValueError:
        return default


@dataclass
class Settings:
    # ---- LLM -------------------------------------------------------------
    llm_provider: str = os.getenv("LLM_PROVIDER", "scripted")
    llm_endpoint: str = os.getenv("LLM_ENDPOINT", "")
    llm_model: str = os.getenv("LLM_MODEL", "enterprise-default")
    llm_api_key: str = os.getenv("LLM_API_KEY", "")
    llm_auth_header: str = os.getenv("LLM_AUTH_HEADER", "Authorization")
    llm_auth_prefix: str = os.getenv("LLM_AUTH_PREFIX", "Bearer")
    llm_extra_headers: str = os.getenv("LLM_EXTRA_HEADERS", "")
    llm_ca_bundle: str = os.getenv("LLM_CA_BUNDLE", "")
    llm_client_cert: str = os.getenv("LLM_CLIENT_CERT", "")
    llm_client_key: str = os.getenv("LLM_CLIENT_KEY", "")
    llm_timeout_seconds: float = _f("LLM_TIMEOUT_SECONDS", 90.0)
    llm_temperature: float = _f("LLM_TEMPERATURE", 0.2)
    llm_max_tokens: int = _i("LLM_MAX_TOKENS", 1500)

    # ---- OAuth2 (optional) -----------------------------------------------
    llm_token_url: str = os.getenv("LLM_TOKEN_URL", "")
    llm_client_id: str = os.getenv("LLM_CLIENT_ID", "")
    llm_client_secret: str = os.getenv("LLM_CLIENT_SECRET", "")
    llm_scope: str = os.getenv("LLM_SCOPE", "")

    # ---- Package ---------------------------------------------------------
    package_path: Path = Path(os.getenv("PACKAGE_PATH", str(ROOT / "packages" / "Onboard360AI")))

    # ---- Runtime ---------------------------------------------------------
    max_steps_per_turn: int = _i("MAX_STEPS_PER_TURN", 12)
    max_handoff_depth: int = _i("MAX_HANDOFF_DEPTH", 6)
    max_retries_per_turn: int = _i("MAX_RETRIES_PER_TURN", 2)
    enforce_contracts: bool = _b("ENFORCE_CONTRACTS", True)
    contract_mode: str = os.getenv("CONTRACT_MODE", "block")  # block | warn
    include_skill_instructions: bool = _b("INCLUDE_SKILL_INSTRUCTIONS", True)

    # ---- Tools -----------------------------------------------------------
    tool_mode: str = os.getenv("TOOL_MODE", "mock")  # mock | live
    jira_base_url: str = os.getenv("JIRA_BASE_URL", "")
    jira_token: str = os.getenv("JIRA_TOKEN", "")

    # ---- Server ----------------------------------------------------------
    host: str = os.getenv("HOST", "127.0.0.1")
    port: int = _i("PORT", 8000)


settings = Settings()
