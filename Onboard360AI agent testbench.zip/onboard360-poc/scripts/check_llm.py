"""Verify the enterprise LLM connection in isolation:  python -m scripts.check_llm"""
from config.settings import settings
from llm.base import Message
from llm.registry import get_client

if __name__ == "__main__":
    print(f"provider : {settings.llm_provider}")
    print(f"endpoint : {settings.llm_endpoint or '(not set)'}")
    print(f"model    : {settings.llm_model}\n")
    client = get_client()
    print("health   :", client.health(), "\n")
    try:
        r = client.complete([
            Message("system", "You are a connectivity test. Reply with one short sentence."),
            Message("user", "Confirm you are reachable."),
        ])
        print(f"reply    : {r.text.strip()[:300]}")
        print(f"latency  : {r.latency_ms}ms")
    except Exception as exc:
        print(f"FAILED   : {exc}")
        print("\nEdit llm/providers/enterprise.py — _build_request() and _parse_response() —")
        print("to match your gateway contract, then re-run.")
