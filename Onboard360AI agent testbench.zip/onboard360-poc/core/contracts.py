"""
Real-time contracts, mirroring what the Platform Specialist Agent enforces.

Contracts run at four interception points:
    PRE_MODEL   before the prompt goes to the LLM
    POST_MODEL  after the LLM returns, before the action is acted on
    PRE_TOOL    before a tool function executes
    POST_TOOL   after a tool returns, before the result re-enters the loop

A contract returns a Verdict. In `block` mode a failed verdict stops the action
and feeds the reason back to the agent as a correction. In `warn` mode it is
recorded on the trace and execution continues — useful when you want to see how
far a flow gets rather than stopping at the first violation.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

from config.settings import settings


class Point(str, Enum):
    PRE_MODEL = "pre_model"
    POST_MODEL = "post_model"
    PRE_TOOL = "pre_tool"
    POST_TOOL = "post_tool"


@dataclass
class Verdict:
    passed: bool
    contract: str
    point: Point
    detail: str = ""
    rule: str = ""
    severity: str = "block"  # block | warn


@dataclass
class Ctx:
    """Everything a contract may inspect."""
    agent: Any = None
    skill: Any = None
    state: Any = None
    messages: list = field(default_factory=list)
    response_text: str = ""
    action: dict = field(default_factory=dict)
    tool_name: str = ""
    function_name: str = ""
    args: dict = field(default_factory=dict)
    result: Any = None
    turn_index: int = 0
    is_opening_message: bool = False


Contract = Callable[[Ctx], Verdict]
_REGISTRY: dict[Point, list[tuple[str, Contract]]] = {p: [] for p in Point}


def contract(point: Point, name: str):
    def deco(fn: Contract):
        _REGISTRY[point].append((name, fn))
        return fn
    return deco


def _ok(name, point, rule="") -> Verdict:
    return Verdict(True, name, point, rule=rule)


def _fail(name, point, detail, rule="", severity="block") -> Verdict:
    return Verdict(False, name, point, detail=detail, rule=rule, severity=severity)


# ===========================================================================
# PRE-MODEL
# ===========================================================================

SECRET_PATTERNS = [
    (re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"), "private key material"),
    (re.compile(r"\bBearer\s+[A-Za-z0-9\-._~+/]{20,}"), "bearer token"),
    (re.compile(r"\b\d{16}\b"), "16-digit number"),
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "SSN-shaped value"),
]


@contract(Point.PRE_MODEL, "no_secrets_outbound")
def no_secrets_outbound(c: Ctx) -> Verdict:
    """Never send credential material to the model."""
    blob = "\n".join(getattr(m, "content", "") for m in c.messages)
    for pattern, label in SECRET_PATTERNS:
        if pattern.search(blob):
            return _fail("no_secrets_outbound", Point.PRE_MODEL,
                         f"Prompt contains what looks like {label}; refusing to send it to the model.")
    return _ok("no_secrets_outbound", Point.PRE_MODEL)


@contract(Point.PRE_MODEL, "agent_identity_present")
def agent_identity_present(c: Ctx) -> Verdict:
    """The runtime must always tell the model which agent it is acting as."""
    blob = "\n".join(getattr(m, "content", "") for m in c.messages)
    if "ACTIVE AGENT:" not in blob:
        return _fail("agent_identity_present", Point.PRE_MODEL,
                     "System prompt is missing the ACTIVE AGENT marker.")
    return _ok("agent_identity_present", Point.PRE_MODEL)


# ===========================================================================
# POST-MODEL
# ===========================================================================

@contract(Point.POST_MODEL, "parseable_action")
def parseable_action(c: Ctx) -> Verdict:
    if not c.action or not c.action.get("action"):
        return _fail("parseable_action", Point.POST_MODEL,
                     "Model did not return a recognisable action envelope.")
    return _ok("parseable_action", Point.POST_MODEL)


@contract(Point.POST_MODEL, "runtime_disclosure")
def runtime_disclosure(c: Ctx) -> Verdict:
    """BR-23 — the opening message must state integration state and next phase."""
    if not c.is_opening_message:
        return _ok("runtime_disclosure", Point.POST_MODEL, rule="BR-23")
    msg = (c.action.get("message") or "").lower()
    if not msg:
        return _ok("runtime_disclosure", Point.POST_MODEL, rule="BR-23")
    integrated = any(w in msg for w in ("integrated", "integration", "live", "connected", "today"))
    next_phase = any(w in msg for w in ("next phase", "phase 2", "phase 3", "later", "will add", "next"))
    if integrated and next_phase:
        return _ok("runtime_disclosure", Point.POST_MODEL, rule="BR-23")
    return _fail("runtime_disclosure", Point.POST_MODEL,
                 "Opening message must state what is integrated today AND what the next phase adds.",
                 rule="BR-23")


@contract(Point.POST_MODEL, "declared_handoff_target")
def declared_handoff_target(c: Ctx) -> Verdict:
    if c.action.get("action") != "handoff":
        return _ok("declared_handoff_target", Point.POST_MODEL)
    target = c.action.get("agent_id", "")
    allowed = set(getattr(c.agent, "invokes", []) or [])
    if target not in allowed:
        return _fail("declared_handoff_target", Point.POST_MODEL,
                     f"'{getattr(c.agent,'id','?')}' attempted handoff to '{target}', "
                     f"which is not in its declared invokes: {sorted(allowed) or 'none'}.")
    return _ok("declared_handoff_target", Point.POST_MODEL)


@contract(Point.POST_MODEL, "declared_skill")
def declared_skill(c: Ctx) -> Verdict:
    if c.action.get("action") != "invoke_skill":
        return _ok("declared_skill", Point.POST_MODEL)
    sid = c.action.get("skill_id", "")
    allowed = set(getattr(c.agent, "skill_ids", []) or [])
    if sid not in allowed:
        return _fail("declared_skill", Point.POST_MODEL,
                     f"'{getattr(c.agent,'id','?')}' attempted to invoke skill '{sid}', "
                     f"which it does not own.")
    return _ok("declared_skill", Point.POST_MODEL)


# ===========================================================================
# PRE-TOOL
# ===========================================================================

@contract(Point.PRE_TOOL, "tool_in_scope")
def tool_in_scope(c: Ctx) -> Verdict:
    """An agent or skill may only call tools it has declared."""
    holder = c.skill or c.agent
    # A skill executes inside its agent's tool surface. Skill-declared tools ADD to
    # the agent's, they do not restrict them — otherwise a skill could never use a
    # tool its owning agent legitimately holds.
    declared = {t.name for t in (getattr(c.agent, "tools", []) or [])}
    declared |= {t.name for t in (getattr(c.skill, "tools", []) or [])} if c.skill else set()
    if c.tool_name not in declared:
        return _fail("tool_in_scope", Point.PRE_TOOL,
                     f"'{getattr(holder,'id','?')}' attempted to call '{c.tool_name}', "
                     f"which is not declared. Declared: {sorted(declared) or 'none'}.")
    return _ok("tool_in_scope", Point.PRE_TOOL)


@contract(Point.PRE_TOOL, "ljkx_key_format")
def ljkx_key_format(c: Ctx) -> Verdict:
    """BR-01 — validate the intake key before it reaches Jira."""
    if c.function_name != "get_issue":
        return _ok("ljkx_key_format", Point.PRE_TOOL, rule="BR-01")
    key = str(c.args.get("issueKey", ""))
    if not re.fullmatch(r"LJKX-\d+", key):
        return _fail("ljkx_key_format", Point.PRE_TOOL,
                     f"'{key}' is not a valid ICMP intake key. Required: project key exactly LJKX, "
                     "a hyphen, and a numeric value after it (e.g. LJKX-1234).",
                     rule="BR-01")
    return _ok("ljkx_key_format", Point.PRE_TOOL, rule="BR-01")


@contract(Point.PRE_TOOL, "ticket_project_key_not_ljkx")
def ticket_project_key_not_ljkx(c: Ctx) -> Verdict:
    """Capacity planning and SPLI tickets go to the scrum team's project, never LJKX."""
    if c.function_name != "create_issue":
        return _ok("ticket_project_key_not_ljkx", Point.PRE_TOOL, rule="BR-21")
    project = str(c.args.get("projectKey", "")).upper()
    if not project:
        return _fail("ticket_project_key_not_ljkx", Point.PRE_TOOL,
                     "create_issue called without a projectKey. Resolve the allocated scrum team's "
                     "project key first; never guess.", rule="BR-21")
    if project == "LJKX":
        return _fail("ticket_project_key_not_ljkx", Point.PRE_TOOL,
                     "LJKX is the intake project only. Capacity planning and SPLI tickets must be "
                     "created in the allocated scrum team's own project, resolved from the intake.",
                     rule="BR-21")
    return _ok("ticket_project_key_not_ljkx", Point.PRE_TOOL, rule="BR-21")


@contract(Point.PRE_TOOL, "no_secrets_to_tools")
def no_secrets_to_tools(c: Ctx) -> Verdict:
    blob = str(c.args)
    for pattern, label in SECRET_PATTERNS:
        if pattern.search(blob):
            return _fail("no_secrets_to_tools", Point.PRE_TOOL,
                         f"Tool arguments contain what looks like {label}.")
    return _ok("no_secrets_to_tools", Point.PRE_TOOL)


# ===========================================================================
# POST-TOOL
# ===========================================================================

@contract(Point.POST_TOOL, "tool_result_shape")
def tool_result_shape(c: Ctx) -> Verdict:
    if c.result is None:
        return _fail("tool_result_shape", Point.POST_TOOL,
                     f"{c.tool_name}.{c.function_name} returned nothing.", severity="warn")
    return _ok("tool_result_shape", Point.POST_TOOL)


@contract(Point.POST_TOOL, "no_raw_error_passthrough")
def no_raw_error_passthrough(c: Ctx) -> Verdict:
    """Tool failures must be diagnosed, not forwarded raw to the partner."""
    if isinstance(c.result, dict) and c.result.get("error"):
        if not c.result.get("diagnosis"):
            return _fail("no_raw_error_passthrough", Point.POST_TOOL,
                         "Tool returned an error without a plain-language diagnosis.",
                         severity="warn")
    return _ok("no_raw_error_passthrough", Point.POST_TOOL)


# ===========================================================================
# Engine
# ===========================================================================

class ContractEngine:
    def __init__(self, enabled: bool | None = None, mode: str | None = None):
        self.enabled = settings.enforce_contracts if enabled is None else enabled
        self.mode = mode or settings.contract_mode

    def run(self, point: Point, ctx: Ctx) -> list[Verdict]:
        if not self.enabled:
            return []
        return [fn(ctx) for _, fn in _REGISTRY[point]]

    def blocking_failure(self, verdicts: list[Verdict]) -> Verdict | None:
        for v in verdicts:
            if not v.passed and v.severity == "block" and self.mode == "block":
                return v
        return None

    @staticmethod
    def registered() -> dict[str, list[str]]:
        return {p.value: [n for n, _ in fns] for p, fns in _REGISTRY.items()}
