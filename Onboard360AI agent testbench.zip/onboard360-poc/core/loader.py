"""Loads the agent/skill package from disk into typed registries."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from config.settings import settings
from core.models import Agent, Skill, ToolSpec


@dataclass
class Package:
    manifest: dict
    agents: dict[str, Agent] = field(default_factory=dict)
    skills: dict[str, Skill] = field(default_factory=dict)
    tools: dict[str, ToolSpec] = field(default_factory=dict)
    business_rules: dict[str, dict] = field(default_factory=dict)
    glossary: list[dict] = field(default_factory=list)

    @property
    def master(self) -> Agent:
        for a in self.agents.values():
            if a.is_master:
                return a
        raise ValueError("Package contains no master agent.")

    def skills_for(self, agent_id: str) -> list[Skill]:
        agent = self.agents[agent_id]
        return [self.skills[s] for s in agent.skill_ids if s in self.skills]

    def validate(self) -> list[str]:
        """Return a list of integrity problems. Empty list means clean."""
        problems: list[str] = []
        for a in self.agents.values():
            for sid in a.skill_ids:
                if sid not in self.skills:
                    problems.append(f"agent '{a.id}' declares missing skill '{sid}'")
            for target in a.invokes:
                if target not in self.agents:
                    problems.append(f"agent '{a.id}' invokes unknown agent '{target}'")
        for s in self.skills.values():
            if s.owner_agent not in self.agents:
                problems.append(f"skill '{s.id}' owned by unknown agent '{s.owner_agent}'")
            if s.parent_skill and s.parent_skill not in self.skills:
                problems.append(f"skill '{s.id}' has unknown parent '{s.parent_skill}'")
        return problems


def load_package(path: Path | str | None = None) -> Package:
    root = Path(path or settings.package_path)
    if not root.exists():
        raise FileNotFoundError(f"Package not found at {root}")

    manifest = json.loads((root / "_manifest.json").read_text(encoding="utf-8"))
    pkg = Package(manifest=manifest)

    shared = root / "_shared"
    if (shared / "tools.json").exists():
        raw = json.loads((shared / "tools.json").read_text(encoding="utf-8"))
        for key, spec in raw.get("tools", {}).items():
            t = ToolSpec.from_json(spec)
            pkg.tools[t.name] = t
    if (shared / "business-rules.json").exists():
        raw = json.loads((shared / "business-rules.json").read_text(encoding="utf-8"))
        pkg.business_rules = {r["id"]: r for r in raw.get("rules", [])}
    if (shared / "glossary.json").exists():
        raw = json.loads((shared / "glossary.json").read_text(encoding="utf-8"))
        pkg.glossary = raw.get("terms", [])

    for agent_file in sorted(root.glob("*/agent.json")):
        agent = Agent.from_json(json.loads(agent_file.read_text(encoding="utf-8")))
        pkg.agents[agent.id] = agent
        for skill_file in sorted(agent_file.parent.glob("skills/*/skill.json")):
            skill = Skill.from_json(json.loads(skill_file.read_text(encoding="utf-8")))
            pkg.skills[skill.id] = skill

    return pkg
