"""Onboarding journey state with provenance, per the architecture spec."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

PROVENANCE = ("context", "knowledge_base", "system", "partner", "derived")


@dataclass
class Value:
    value: Any
    provenance: str = "partner"
    source: str = ""
    at: float = field(default_factory=time.time)

    def as_dict(self) -> dict:
        return {"value": self.value, "provenance": self.provenance, "source": self.source}


@dataclass
class OpenItem:
    key: str
    what: str
    blocks: str = ""
    owner: str = ""
    resolved: bool = False


@dataclass
class JourneyState:
    values: dict[str, Value] = field(default_factory=dict)
    open_items: list[OpenItem] = field(default_factory=list)
    completed_agents: list[str] = field(default_factory=list)
    conflicts: list[dict] = field(default_factory=list)

    # ------------------------------------------------------------------ set
    def set(self, key: str, value: Any, provenance: str = "partner", source: str = "") -> None:
        if provenance not in PROVENANCE:
            provenance = "partner"
        existing = self.values.get(key)
        if existing and existing.value != value:
            # Surface conflicts rather than silently overwriting — spec requirement.
            self.conflicts.append({
                "key": key, "was": existing.value, "now": value,
                "was_provenance": existing.provenance, "now_provenance": provenance,
            })
        self.values[key] = Value(value=value, provenance=provenance, source=source)

    def get(self, key: str, default: Any = None) -> Any:
        v = self.values.get(key)
        return v.value if v else default

    def has(self, key: str) -> bool:
        return key in self.values

    def provenance_of(self, key: str) -> str | None:
        v = self.values.get(key)
        return v.provenance if v else None

    # ------------------------------------------------------------ open items
    def add_open_item(self, key: str, what: str, blocks: str = "", owner: str = "") -> None:
        if any(i.key == key and not i.resolved for i in self.open_items):
            return
        self.open_items.append(OpenItem(key=key, what=what, blocks=blocks, owner=owner))

    def resolve_open_item(self, key: str) -> None:
        for i in self.open_items:
            if i.key == key:
                i.resolved = True

    def complete_agent(self, agent_id: str) -> None:
        if agent_id not in self.completed_agents:
            self.completed_agents.append(agent_id)

    # ---------------------------------------------------------------- export
    def snapshot(self) -> dict:
        return {
            "values": {k: v.as_dict() for k, v in self.values.items()},
            "openItems": [i.__dict__ for i in self.open_items if not i.resolved],
            "completedAgents": list(self.completed_agents),
            "conflicts": list(self.conflicts),
        }

    def summary_lines(self) -> list[str]:
        out = []
        for k, v in self.values.items():
            marker = {"system": "◆", "knowledge_base": "◇", "partner": "●",
                      "context": "○", "derived": "◐"}.get(v.provenance, "·")
            out.append(f"{marker} {k} = {v.value}")
        return out
