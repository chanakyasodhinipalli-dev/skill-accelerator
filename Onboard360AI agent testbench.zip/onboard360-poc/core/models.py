"""Typed views over the JSON package produced by the architecture build."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolFunction:
    function: str
    purpose: str = ""
    inputs: dict = field(default_factory=dict)
    returns: str = ""


@dataclass
class ToolSpec:
    name: str
    transport: str = ""
    status: str = "PLANNED"
    phase: str = "P1"
    functions: list[ToolFunction] = field(default_factory=list)

    @property
    def function_names(self) -> list[str]:
        return [f.function for f in self.functions]

    @classmethod
    def from_json(cls, d: dict) -> "ToolSpec":
        return cls(
            name=d.get("name", "unknown"),
            transport=d.get("transport", ""),
            status=d.get("status", "PLANNED"),
            phase=d.get("phase", "P1"),
            functions=[ToolFunction(**{k: v for k, v in f.items()
                                       if k in ("function", "purpose", "inputs", "returns")})
                       for f in d.get("functions", [])],
        )


@dataclass
class Question:
    id: str
    prompt: str
    type: str = "sequential"
    options: list[str] = field(default_factory=list)
    condition: str = ""
    validation: str = ""
    data_to_capture: str = ""

    @classmethod
    def from_json(cls, d: dict) -> "Question":
        return cls(
            id=d.get("id", ""),
            prompt=d.get("prompt", ""),
            type=d.get("type", "sequential"),
            options=d.get("options", []) or [],
            condition=d.get("condition", "") or "",
            validation=d.get("validation", "") or "",
            data_to_capture=d.get("dataToCapture", "") or "",
        )


@dataclass
class Skill:
    id: str
    name: str
    owner_agent: str
    description: str
    system_instructions: str
    user_instructions: str
    instructions: list[str] = field(default_factory=list)
    questions: list[Question] = field(default_factory=list)
    reference_materials: list[dict] = field(default_factory=list)
    tools: list[ToolSpec] = field(default_factory=list)
    business_rules: list[str] = field(default_factory=list)
    phase: str = "P1"
    skill_type: str = "standard"
    parent_skill: str | None = None
    future_implementation: str = ""

    @classmethod
    def from_json(cls, d: dict) -> "Skill":
        return cls(
            id=d["id"], name=d["name"], owner_agent=d["ownerAgent"],
            description=d.get("description", ""),
            system_instructions=d.get("systemInstructions", ""),
            user_instructions=d.get("userInstructions", ""),
            instructions=d.get("instructions", []) or [],
            questions=[Question.from_json(q) for q in d.get("questions", []) or []],
            reference_materials=d.get("referenceMaterials", []) or [],
            tools=[ToolSpec.from_json(t) for t in d.get("tools", []) or []],
            business_rules=d.get("businessRules", []) or [],
            phase=d.get("integrationPhase", "P1"),
            skill_type=d.get("skillType", "standard"),
            parent_skill=d.get("parentSkill"),
            future_implementation=d.get("futureImplementation", ""),
        )


@dataclass
class Agent:
    id: str
    name: str
    type: str
    description: str
    goals: list[str]
    system_instructions: str
    user_instructions: str
    questions: list[Question] = field(default_factory=list)
    tools: list[ToolSpec] = field(default_factory=list)
    skill_ids: list[str] = field(default_factory=list)
    invokes: list[str] = field(default_factory=list)
    invoked_by: list[str] = field(default_factory=list)
    branch: str = "ALL"
    phase: str = "P1"
    release: str = ""

    @property
    def is_master(self) -> bool:
        return self.type == "master-agent"

    @classmethod
    def from_json(cls, d: dict) -> "Agent":
        return cls(
            id=d["id"], name=d["name"], type=d.get("type", "sub-agent"),
            description=d.get("description", ""),
            goals=d.get("goals", []) or [],
            system_instructions=d.get("systemInstructions", ""),
            user_instructions=d.get("userInstructions", ""),
            questions=[Question.from_json(q) for q in d.get("questions", []) or []],
            tools=[ToolSpec.from_json(t) for t in d.get("tools", []) or []],
            skill_ids=d.get("skills", []) or [],
            invokes=d.get("invokes", []) or [],
            invoked_by=d.get("invokedBy", []) or [],
            branch=d.get("branch", "ALL"),
            phase=d.get("integrationPhase", "P1"),
            release=d.get("release", ""),
        )
