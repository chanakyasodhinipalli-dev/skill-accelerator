"""Execution trace. This is what the orchestration tape in the UI renders."""
from __future__ import annotations

import itertools
import time
from dataclasses import dataclass, field, asdict

_ids = itertools.count(1)

KINDS = ("turn", "agent", "handoff", "skill", "skill_end", "model", "tool",
         "contract", "state", "error", "goal")


@dataclass
class Event:
    kind: str
    label: str
    detail: str = ""
    status: str = "ok"          # ok | fail | warn | active
    depth: int = 0
    agent: str = ""
    skill: str = ""
    phase: str = ""
    rule: str = ""
    ms: int = 0
    data: dict = field(default_factory=dict)
    id: int = field(default_factory=lambda: next(_ids))
    at: float = field(default_factory=time.time)

    def as_dict(self) -> dict:
        return asdict(self)


class Trace:
    def __init__(self):
        self.events: list[Event] = []

    def add(self, kind: str, label: str, **kw) -> Event:
        ev = Event(kind=kind, label=label, **kw)
        self.events.append(ev)
        return ev

    def export(self, since: int = 0) -> list[dict]:
        return [e.as_dict() for e in self.events if e.id > since]

    def clear(self) -> None:
        self.events.clear()

    def counts(self) -> dict:
        out: dict[str, int] = {}
        for e in self.events:
            out[e.kind] = out.get(e.kind, 0) + 1
        return out

    def failures(self) -> list[dict]:
        return [e.as_dict() for e in self.events if e.status == "fail"]
