"""
The runtime.

Hierarchy modelled here, matching the architecture:

    Platform Specialist Agent      composes everything at runtime from config,
                                   owns the tool surface and the contract engine
      └── Onboard360AI             master onboarding agent, itself a sub-agent
            └── 8 sub-agents       goal-bearing units
                  └── skills       knowledge/procedure units

Agent-to-agent works through an action protocol carried in the model's text, so
it needs no native tool/function calling and works against any enterprise
gateway that can return a string.

ACTION ENVELOPE
    {"thought": "...", "action": "reply"        , "message": "..."}
    {"thought": "...", "action": "invoke_skill" , "skill_id": "..."}
    {"thought": "...", "action": "handoff"      , "agent_id": "...", "reason": "..."}
    {"thought": "...", "action": "tool_call"    , "tool": "...", "function": "...", "args": {}}
    {"thought": "...", "action": "goal_met"     , "message": "..."}
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

from config.settings import settings
from core.contracts import ContractEngine, Ctx, Point
from core.loader import Package, load_package
from core.models import Agent, Skill
from core.state import JourneyState
from core.trace import Trace
from llm.base import LLMClient, LLMError, Message
from llm.registry import get_client
from tools.registry import ToolRegistry

ACTION_PROTOCOL = """
HOW YOU RESPOND — ACTION PROTOCOL
Reply with exactly one JSON object in a ```json fenced block, and nothing else.
Choose ONE action:

  Speak to the partner:
    {"thought": "why", "action": "reply", "message": "what the partner reads"}

  Run one of your own skills:
    {"thought": "why", "action": "invoke_skill", "skill_id": "<id from YOUR SKILLS>"}

  Hand off to another agent:
    {"thought": "why", "action": "handoff", "agent_id": "<id from AGENTS YOU MAY INVOKE>", "reason": "..."}

  Call a tool:
    {"thought": "why", "action": "tool_call", "tool": "<name>", "function": "<fn>", "args": {}}

  Declare your goal met and hand control back:
    {"thought": "why", "action": "goal_met", "message": "closing summary for the partner"}

RULES
- You may only invoke skills listed under YOUR SKILLS.
- You may only hand off to agents listed under AGENTS YOU MAY INVOKE.
- You may only call tools listed under YOUR TOOLS, using their listed functions.
- Never invent identifiers, keys, URLs or values. If something is unknown, ask for it or say it is unknown.
- One action per response. The runtime will call you again with the result.
""".strip()


@dataclass
class Turn:
    reply: str = ""
    trace: list[dict] = field(default_factory=list)
    stack: list[str] = field(default_factory=list)
    state: dict = field(default_factory=dict)
    steps: int = 0
    contract_failures: list[dict] = field(default_factory=list)


def parse_action(text: str) -> dict:
    """Tolerant extraction of the action envelope from model prose."""
    if not text:
        return {}
    fenced = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    candidates = fenced or []
    if not candidates:
        depth, start = 0, None
        for i, ch in enumerate(text):
            if ch == "{":
                if depth == 0:
                    start = i
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0 and start is not None:
                    candidates.append(text[start:i + 1])
                    start = None
    for blob in reversed(candidates):
        try:
            obj = json.loads(blob)
            if isinstance(obj, dict) and "action" in obj:
                return obj
        except json.JSONDecodeError:
            continue
    # Model replied in plain prose — treat it as a reply so the flow survives.
    return {"action": "reply", "message": text.strip(), "thought": "unstructured response coerced to reply"}


class SpecialistAgent:
    """Platform Specialist Agent — the composition and enforcement layer."""

    def __init__(self, package: Package | None = None, llm: LLMClient | None = None,
                 tools: ToolRegistry | None = None, contracts: ContractEngine | None = None):
        self.package = package or load_package()
        self.llm = llm or get_client()
        self.tools = tools or ToolRegistry()
        self.contracts = contracts or ContractEngine()
        self.state = JourneyState()
        self.trace = Trace()
        self.history: list[Message] = []
        self.stack: list[str] = [self.package.master.id]
        self.turn_count = 0
        self._opened_agents: set[str] = set()

    # ------------------------------------------------------------ prompting

    def _agent_prompt(self, agent: Agent, skill: Skill | None) -> str:
        skills = self.package.skills_for(agent.id)
        parts = [
            f"ACTIVE AGENT: {agent.id}",
            f"AGENT NAME: {agent.name}",
            f"RELEASE: {agent.release or self.package.manifest.get('release', 'MVP 1')}",
            f"PLATFORM: {self.package.manifest.get('platform', 'iDocs Canvas')}",
            f"RUNTIME: {self.package.manifest.get('runtime', 'Platform Specialist Agent on Tachyon SDK')}",
            "",
            agent.system_instructions,
            "",
            "GOALS",
            *[f"- {g}" for g in agent.goals],
        ]

        if skill:
            parts += [
                "",
                "=" * 70,
                f"ACTIVE SKILL: {skill.id}",
                f"SKILL NAME: {skill.name}",
                f"SKILL PHASE: {skill.phase}",
                "",
                skill.system_instructions,
            ]
            if settings.include_skill_instructions and skill.instructions:
                parts += ["", "SKILL STEPS"] + [f"{i+1}. {s}" for i, s in enumerate(skill.instructions)]
            if skill.questions:
                parts += ["", "SKILL QUESTIONS"]
                for q in skill.questions:
                    line = f"[{q.id}/{q.type}] {q.prompt}"
                    if q.options:
                        line += f"  OPTIONS: {', '.join(q.options)}"
                    if q.condition:
                        line += f"  WHEN: {q.condition}"
                    parts.append(line)
            if skill.reference_materials:
                parts += ["", "REFERENCE MATERIALS"] + [
                    f"- {r.get('title')} ({r.get('url')})" for r in skill.reference_materials]
            holder_tools = skill.tools or agent.tools
        else:
            parts += ["", "YOUR SKILLS (invoke_skill targets)"]
            parts += [f"- {s.id} — {s.name}: {s.description}" for s in skills] or ["- none"]
            parts += ["", "AGENTS YOU MAY INVOKE (handoff targets)"]
            parts += [f"- {a}" for a in agent.invokes] or ["- none"]
            holder_tools = agent.tools

        parts += ["", "YOUR TOOLS"]
        if holder_tools:
            for t in holder_tools:
                fns = ", ".join(f.function for f in t.functions) or "—"
                parts.append(f"- {t.name} [{t.status}, {t.phase}] functions: {fns}")
        else:
            parts.append("- none")

        if self.state.values:
            parts += ["", "JOURNEY STATE (do not re-ask for these)"]
            parts += self.state.summary_lines()
        if self.state.open_items:
            parts += ["", "OPEN ITEMS"]
            parts += [f"- {i.what} (blocks: {i.blocks or 'nothing yet'})"
                      for i in self.state.open_items if not i.resolved]

        parts += ["", "=" * 70, ACTION_PROTOCOL]
        return "\n".join(parts)

    # --------------------------------------------------------------- model

    def _call_model(self, agent: Agent, skill: Skill | None, depth: int) -> dict:
        system = self._agent_prompt(agent, skill)
        messages = [Message("system", system)] + self.history[-16:]

        verdicts = self.contracts.run(Point.PRE_MODEL, Ctx(agent=agent, skill=skill,
                                                           state=self.state, messages=messages))
        self._record_contracts(verdicts, depth, agent, skill)
        if (blocked := self.contracts.blocking_failure(verdicts)):
            return {"action": "reply", "message": f"Blocked before model call: {blocked.detail}"}

        try:
            resp = self.llm.complete(messages)
        except LLMError as exc:
            self.trace.add("error", "model call failed", detail=str(exc), status="fail",
                           depth=depth, agent=agent.id, skill=skill.id if skill else "")
            return {"action": "reply",
                    "message": f"The model could not be reached: {exc}"}

        self.trace.add("model", f"{self.llm.name}:{self.llm.model}",
                       detail=(resp.text or "")[:400], depth=depth, agent=agent.id,
                       skill=skill.id if skill else "", ms=resp.latency_ms)

        action = parse_action(resp.text)
        is_opening = agent.id not in self._opened_agents and skill is None
        verdicts = self.contracts.run(Point.POST_MODEL, Ctx(
            agent=agent, skill=skill, state=self.state, response_text=resp.text,
            action=action, is_opening_message=is_opening))
        self._record_contracts(verdicts, depth, agent, skill)
        if (blocked := self.contracts.blocking_failure(verdicts)):
            self.history.append(Message(
                "user",
                f"[CONTRACT VIOLATION — {blocked.contract}"
                f"{' / ' + blocked.rule if blocked.rule else ''}] {blocked.detail} "
                "Correct this and respond again with a valid action."))
            return {"action": "__retry__", "detail": blocked.detail}

        if skill is None:
            self._opened_agents.add(agent.id)
        return action

    def _record_contracts(self, verdicts, depth, agent, skill) -> None:
        for v in verdicts:
            if v.passed:
                continue
            self.trace.add("contract", f"{v.contract}", detail=v.detail,
                           status="fail" if v.severity == "block" else "warn",
                           depth=depth, agent=getattr(agent, "id", ""),
                           skill=getattr(skill, "id", "") if skill else "",
                           rule=v.rule, data={"point": v.point.value})

    # ---------------------------------------------------------------- tools

    def _run_tool(self, agent: Agent, skill: Skill | None, action: dict, depth: int) -> dict:
        tool = action.get("tool", "")
        function = action.get("function", "")
        args = action.get("args", {}) or {}

        verdicts = self.contracts.run(Point.PRE_TOOL, Ctx(
            agent=agent, skill=skill, state=self.state,
            tool_name=tool, function_name=function, args=args))
        self._record_contracts(verdicts, depth, agent, skill)
        if (blocked := self.contracts.blocking_failure(verdicts)):
            self.history.append(Message(
                "user",
                f"[CONTRACT VIOLATION — {blocked.contract}"
                f"{' / ' + blocked.rule if blocked.rule else ''}] {blocked.detail} "
                "Do not retry the same call. Correct it or take a different action."))
            return {"blocked": True, "detail": blocked.detail}

        result, ms = self.tools.call(tool, function, args)
        self.trace.add("tool", f"{tool}.{function}",
                       detail=json.dumps(args)[:220],
                       status="ok" if result.get("ok") else "warn",
                       depth=depth, agent=agent.id, skill=skill.id if skill else "",
                       ms=ms, data={"result": _clip(result)})

        verdicts = self.contracts.run(Point.POST_TOOL, Ctx(
            agent=agent, skill=skill, state=self.state, tool_name=tool,
            function_name=function, args=args, result=result))
        self._record_contracts(verdicts, depth, agent, skill)

        self._harvest_state(tool, function, args, result, depth)
        self.history.append(Message("user", f"[TOOL RESULT {tool}.{function}] {json.dumps(_clip(result))}"))
        return {"blocked": False, "result": result}

    def _harvest_state(self, tool, function, args, result, depth) -> None:
        """Pull authoritative values out of tool results into journey state."""
        if not result.get("ok"):
            return
        if function == "get_issue":
            issue = result.get("issue", {})
            self.state.set("intakeKey", issue.get("key"), "system", "Jira MCP.get_issue")
            self.state.set("intakeStatus", issue.get("status"), "system", "Jira MCP.get_issue")
            cf = issue.get("customFields", {})
            if cf.get("allocatedScrumTeam"):
                self.state.set("allocatedScrumTeam", cf["allocatedScrumTeam"], "system", "Jira MCP.get_issue")
            if cf.get("scrumProjectKey"):
                self.state.set("scrumTeamProjectKey", cf["scrumProjectKey"], "system", "Jira MCP.get_issue")
            else:
                self.state.add_open_item("allocatedScrumTeam",
                                         "No scrum team allocated on the intake",
                                         blocks="Non-Prod and Production access", owner="LOB point of contact")
            for field_name in issue.get("unresolved", []):
                self.state.add_open_item(field_name, f"Intake field '{field_name}' is unresolved",
                                         blocks="downstream ticket completeness", owner="partner")
            self.trace.add("state", "intake harvested",
                           detail=f"scrum team: {cf.get('allocatedScrumTeam') or 'none'}",
                           depth=depth, data={"keys": ["intakeKey", "allocatedScrumTeam", "scrumTeamProjectKey"]})
        elif function == "create_issue":
            created = result.get("created", {})
            key = created.get("key", "")
            slot = "spliTicket" if "spli" in (created.get("summary", "").lower()) else "capacityPlanningTicket"
            self.state.set(slot, key, "system", "Jira MCP.create_issue")
            self.trace.add("state", f"{slot} = {key}", depth=depth, data={"url": created.get("url")})
        elif function == "build_collection":
            self.state.set("postmanCollection",
                           f"{result.get('requestCount', 0)} requests", "system", "Postman generator")

    # ----------------------------------------------------------------- turn

    def send(self, user_message: str) -> Turn:
        self.turn_count += 1
        since = self.trace.events[-1].id if self.trace.events else 0
        self.history.append(Message("user", user_message))
        self.trace.add("turn", f"turn {self.turn_count}", detail=user_message[:160])

        turn = Turn()
        depth = len(self.stack) - 1
        steps = 0
        retries = 0
        active_skill: Skill | None = None

        while steps < settings.max_steps_per_turn:
            steps += 1
            agent = self.package.agents[self.stack[-1]]
            action = self._call_model(agent, active_skill, depth)
            kind = action.get("action")

            if kind == "__retry__":
                retries += 1
                if retries > settings.max_retries_per_turn:
                    detail = action.get("detail", "repeated contract violation")
                    self.trace.add("error", "retry limit reached", detail=detail,
                                   status="fail", depth=depth, agent=agent.id)
                    turn.reply = (
                        "Stopped: the agent could not produce a compliant action after "
                        f"{retries} corrections. Last violation — {detail}")
                    break
                continue

            if kind == "reply":
                msg = action.get("message", "")
                self.history.append(Message("assistant", msg))
                turn.reply = msg
                break

            if kind == "invoke_skill":
                retries = 0
                sid = action.get("skill_id", "")
                skill = self.package.skills.get(sid)
                if not skill:
                    self.history.append(Message("user", f"[ERROR] No skill '{sid}' exists."))
                    continue
                active_skill = skill
                depth += 1
                self.trace.add("skill", skill.name, detail=skill.description[:180],
                               status="active", depth=depth, agent=agent.id, skill=skill.id,
                               phase=skill.phase, rule=",".join(skill.business_rules))
                continue

            if kind == "handoff":
                retries = 0
                target = action.get("agent_id", "")
                if target not in self.package.agents:
                    self.history.append(Message("user", f"[ERROR] No agent '{target}' exists."))
                    continue
                if len(self.stack) >= settings.max_handoff_depth:
                    self.trace.add("error", "handoff depth limit reached", status="fail", depth=depth)
                    turn.reply = "Handoff depth limit reached — stopping to avoid a loop."
                    break
                self.state.complete_agent(agent.id)
                active_skill = None
                self.stack.append(target)
                depth = len(self.stack) - 1
                self.trace.add("handoff", f"{agent.id} → {target}",
                               detail=action.get("reason", ""), depth=depth,
                               agent=target, phase=self.package.agents[target].phase)
                self.history.append(Message(
                    "user", f"[HANDOFF] You are now {target}. Reason: {action.get('reason','')}"))
                continue

            if kind == "tool_call":
                outcome = self._run_tool(agent, active_skill, action, depth)
                if outcome.get("blocked"):
                    # A blocked tool call counts against the retry budget, otherwise an
                    # agent that keeps retrying the same illegal call burns the whole turn.
                    retries += 1
                    if retries > settings.max_retries_per_turn:
                        detail = outcome.get("detail", "repeated contract violation")
                        self.trace.add("error", "retry limit reached", detail=detail,
                                       status="fail", depth=depth, agent=agent.id)
                        turn.reply = (
                            "Stopped: the agent could not produce a compliant tool call after "
                            f"{retries} corrections. Last violation — {detail}")
                        break
                continue

            if kind == "goal_met":
                msg = action.get("message", "")
                if active_skill:
                    self.trace.add("skill_end", f"{active_skill.name} complete",
                                   depth=depth, agent=agent.id, skill=active_skill.id)
                    active_skill = None
                    depth = len(self.stack) - 1
                    self.history.append(Message("user", f"[SKILL COMPLETE] {msg}"))
                    continue
                self.state.complete_agent(agent.id)
                self.trace.add("goal", f"{agent.name} goal met", detail=msg[:200],
                               depth=depth, agent=agent.id)
                self.history.append(Message("assistant", msg))
                turn.reply = msg
                if len(self.stack) > 1:
                    self.stack.pop()
                    depth = len(self.stack) - 1
                break

            self.history.append(Message("user", f"[ERROR] Unrecognised action '{kind}'."))

        if not turn.reply:
            turn.reply = ("Step limit reached for this turn. The orchestration tape shows where it stopped — "
                          "raise MAX_STEPS_PER_TURN if the flow legitimately needs more steps.")
            self.trace.add("error", "step limit reached", status="fail", depth=depth)

        turn.steps = steps
        turn.trace = self.trace.export(since=since)
        turn.stack = list(self.stack)
        turn.state = self.state.snapshot()
        turn.contract_failures = [e for e in turn.trace if e["kind"] == "contract"]
        return turn

    # ---------------------------------------------------------------- admin

    def reset(self) -> None:
        self.state = JourneyState()
        self.trace = Trace()
        self.history = []
        self.stack = [self.package.master.id]
        self.turn_count = 0
        self._opened_agents = set()

    def topology(self) -> dict:
        return {
            "platform": self.package.manifest.get("platform"),
            "runtime": self.package.manifest.get("runtime"),
            "release": self.package.manifest.get("release"),
            "master": self.package.master.id,
            "agents": [
                {
                    "id": a.id, "name": a.name, "type": a.type, "branch": a.branch,
                    "phase": a.phase, "goals": len(a.goals),
                    "skills": [{"id": s, "name": self.package.skills[s].name,
                                "phase": self.package.skills[s].phase,
                                "type": self.package.skills[s].skill_type}
                               for s in a.skill_ids if s in self.package.skills],
                    "invokes": a.invokes,
                    "tools": [t.name for t in a.tools],
                }
                for a in self.package.agents.values()
            ],
            "contracts": ContractEngine.registered(),
            "tools": self.tools.available(),
            "toolMode": self.tools.mode,
            "llm": {"provider": self.llm.name, "model": self.llm.model},
        }


def _clip(obj: Any, limit: int = 1200) -> Any:
    blob = json.dumps(obj, default=str)
    if len(blob) <= limit:
        return obj
    return {"_clipped": True, "preview": blob[:limit]}
