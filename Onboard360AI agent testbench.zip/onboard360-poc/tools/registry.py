"""
Tool layer.

TOOL_MODE=mock  (default) — deterministic fixtures, no network. Use this to test
                orchestration. Every mock returns the same shape a live call would.
TOOL_MODE=live  — routes to the real client where one is implemented; otherwise
                returns a phase-1 style instruction payload so the flow continues.

Adding a live tool: implement a handler and register it in LIVE_HANDLERS.
"""
from __future__ import annotations

import re
import time
import itertools
from typing import Any, Callable

from config.settings import settings

Handler = Callable[[str, dict], dict]

_ticket_seq = itertools.count(4041)


# ---------------------------------------------------------------- fixtures

INTAKES = {
    "LJKX-1234": {
        "key": "LJKX-1234",
        "summary": "ICMP onboarding — Payments Statement Archive",
        "status": "In Progress",
        "priority": "High",
        "reporter": "a.kumar",
        "assignee": "ecm.onboarding",
        "description": (
            "Onboard Payments Statement Archive to ICMP. Capabilities: ingestion, search, retrieval, "
            "document notifications. Repository: ICMP FileNet. Environments: Innovation, Non-Prod, Production. "
            "Allocated scrum team: Payments Content Services (project PAYSVC). Sprint 42. "
            "LOB prioritisation: confirmed."
        ),
        "labels": ["icmp-onboarding", "scrum-team:payments-content-services"],
        "components": ["ICMP"],
        "customFields": {"allocatedScrumTeam": "Payments Content Services", "scrumProjectKey": "PAYSVC"},
        "unresolved": ["ownershipContacts", "targetGoLiveDate"],
    },
    "LJKX-999": {
        "key": "LJKX-999",
        "summary": "ICMP onboarding — Trade Docs Pilot",
        "status": "Open",
        "priority": "Medium",
        "reporter": "s.nair",
        "assignee": None,
        "description": "Trade docs pilot. Repository: MARS. No scrum team allocated yet.",
        "labels": ["icmp-onboarding"],
        "components": ["ICMP"],
        "customFields": {"allocatedScrumTeam": None, "scrumProjectKey": None},
        "unresolved": ["allocatedScrumTeam", "lobPrioritisation", "targetEnvironments"],
    },
}

PROJECTS = {
    "LJKX": {"key": "LJKX", "name": "ECM Intake", "accessible": True},
    "PAYSVC": {"key": "PAYSVC", "name": "Payments Content Services", "accessible": True},
}

KB_PAGES = {
    "ECM Intake Process": "Raise an ECM intake in LJKX. Required: application system, LOB, capabilities, target environments, go-live date, ownership contacts.",
    "Scrum Team to Jira Project Key Mapping": "Payments Content Services → PAYSVC. Trade Services → TRDSVC. Wealth Content → WLTCNT.",
    "ICMP Capabilities Catalogue": "Ingestion, search, retrieval, download, export, request/document/package notifications, IVaaS viewer, retention, legal hold, retention events.",
    "ART Access Request Guide": "All service accounts, both environments. QAEnt human user access.",
    "AIMS LDAP Group Access Guide": "ADEnt human user access to LDAP groups. Each user applies for their own access.",
    "Venafi Certificate Request Guide": "Non-prod: CN = EREP, OU = TESTAPP, OU = EREP, OU = ECS, O = Wells Fargo, C = US. Production: OU = APP in place of OU = TESTAPP.",
}


# ---------------------------------------------------------------- mock impls

def _jira(function: str, args: dict) -> dict:
    if function == "get_issue":
        key = str(args.get("issueKey", "")).upper()
        if key in INTAKES:
            return {"ok": True, "issue": INTAKES[key]}
        return {
            "ok": False,
            "error": "ISSUE_NOT_FOUND",
            "diagnosis": (
                f"No issue {key} was returned. Either it does not exist, or you do not have access "
                "to it. Run get_project against the project key to tell the two apart."
            ),
        }

    if function == "get_project":
        key = str(args.get("projectKey", "")).upper()
        if key in PROJECTS:
            return {"ok": True, "project": PROJECTS[key]}
        return {
            "ok": False,
            "error": "PROJECT_NOT_FOUND",
            "diagnosis": (
                f"Project {key} returned nothing. The likely causes are that you lack access to it, "
                "or the project key is wrong. Do not proceed with ticket creation against it."
            ),
        }

    if function == "create_issue":
        project = str(args.get("projectKey", "")).upper()
        key = f"{project}-{next(_ticket_seq)}"
        return {
            "ok": True,
            "created": {
                "key": key,
                "url": f"https://jira.internal/browse/{key}",
                "project": project,
                "summary": args.get("summary", ""),
                "issueType": args.get("issueType", "Task"),
            },
        }

    return {"ok": False, "error": "UNKNOWN_FUNCTION",
            "diagnosis": f"Jira MCP has no function '{function}'."}


def _kb(function: str, args: dict) -> dict:
    topic = str(args.get("topic") or args.get("title") or "")
    hits = {k: v for k, v in KB_PAGES.items() if topic.lower() in k.lower()} or KB_PAGES
    if function == "return_links":
        return {"ok": True, "phase": "P1",
                "links": [{"title": k, "url": f"https://confluence.internal/{k.replace(' ', '+')}"}
                          for k in hits]}
    if function == "read_and_answer":
        return {"ok": True, "phase": "P2",
                "answers": [{"title": k, "extract": v} for k, v in hits.items()]}
    return {"ok": False, "error": "UNKNOWN_FUNCTION", "diagnosis": f"KB has no function '{function}'."}


def _postman(function: str, args: dict) -> dict:
    if function == "build_collection":
        scopes = args.get("scopes", []) or []
        env = args.get("environment", "Innovation")
        return {
            "ok": True,
            "collection": {
                "info": {"name": f"ICMP — {env}", "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"},
                "item": [{"name": s, "request": {"method": "POST" if "ingest" in s else "GET",
                                                 "url": "{{baseUrl}}/" + s.split(".")[-1]},
                          "description": f"Permitted by approved scope '{s}'."} for s in scopes],
            },
            "environment": {"name": env, "values": [
                {"key": "baseUrl", "value": args.get("baseUrl", "")},
                {"key": "serviceAccount", "value": args.get("serviceAccount", "")},
                {"key": "clientSecret", "value": "<FILL IN — placeholder, never embedded>"},
            ]},
            "requestCount": len(scopes),
        }
    if function == "emit_download":
        return {"ok": True, "download": {"filename": args.get("filename", "icmp-collection.json"),
                                         "bytes": 4096}}
    return {"ok": False, "error": "UNKNOWN_FUNCTION", "diagnosis": f"Postman generator has no '{function}'."}


def _local(function: str, args: dict) -> dict:
    if function == "validate_format":
        pattern = args.get("pattern", "")
        value = str(args.get("value", ""))
        ok = bool(re.fullmatch(pattern, value)) if pattern else False
        return {"ok": True, "valid": ok, "value": value, "pattern": pattern}
    if function == "assemble_payload":
        return {"ok": True, "payload": args.get("fields", {})}
    if function == "state_read_write":
        return {"ok": True, "note": "State is managed by the runtime; this is a no-op in mock mode."}
    return {"ok": False, "error": "UNKNOWN_FUNCTION", "diagnosis": f"Local tools have no '{function}'."}


def _icmp_apis(function: str, args: dict) -> dict:
    return {"ok": True, "function": function, "echo": args,
            "note": "Mock ICMP/iDocs API response. Point TOOL_MODE=live at the real gateway to exercise properly."}


def _instructions_only(tool: str) -> Handler:
    def handler(function: str, args: dict) -> dict:
        return {
            "ok": True,
            "phase": "P1",
            "mode": "instructions",
            "tool": tool,
            "guidance": (
                f"{tool} has no integration at this phase. Return the Confluence/KB links for this "
                "activity and tell the partner what they must do themselves."
            ),
        }
    return handler


MOCK_HANDLERS: dict[str, Handler] = {
    "Jira MCP": _jira,
    "Knowledge Base / Confluence": _kb,
    "Postman Collection Generator": _postman,
    "Local Tools": _local,
    "ICMP & iDocs APIs": _icmp_apis,
    "BAM — Business Application Management": _instructions_only("BAM"),
    "Venafi": _instructions_only("Venafi"),
    "ART — Access Request Tool": _instructions_only("ART"),
    "AIMS — Access and Identity Management System": _instructions_only("AIMS"),
    "Apigee API Marketplace": _instructions_only("Apigee API Marketplace"),
}

# Implement and register real clients here when moving off mocks.
LIVE_HANDLERS: dict[str, Handler] = {}


class ToolRegistry:
    def __init__(self, mode: str | None = None):
        self.mode = mode or settings.tool_mode
        self.calls: list[dict] = []

    def available(self) -> list[str]:
        return sorted(MOCK_HANDLERS)

    def call(self, tool: str, function: str, args: dict) -> tuple[dict, int]:
        started = time.time()
        handler = None
        if self.mode == "live":
            handler = LIVE_HANDLERS.get(tool)
        if handler is None:
            handler = MOCK_HANDLERS.get(tool)
        if handler is None:
            result = {"ok": False, "error": "UNKNOWN_TOOL",
                      "diagnosis": f"No handler registered for tool '{tool}'."}
        else:
            try:
                result = handler(function, args or {})
            except Exception as exc:  # a tool must never crash the runtime
                result = {"ok": False, "error": type(exc).__name__,
                          "diagnosis": f"{tool}.{function} raised: {exc}"}
        ms = int((time.time() - started) * 1000)
        self.calls.append({"tool": tool, "function": function, "args": args,
                           "result": result, "ms": ms, "mode": self.mode})
        return result, ms
