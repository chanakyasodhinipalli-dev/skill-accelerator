# LJKX Key Format Validation

> **Type:** Skill (standard)
> **ID:** `ljkx-key-format-validation`
> **Owner agent:** `intake-verification`
> **Parent skill:** —
> **Integration phase:** P1
> **Business rules:** BR-01

---

## Title

LJKX Key Format Validation

## Description

Validates a Jira intake key against the ICMP format rules before any tool call is made.

---

## System Prompt / System Instructions

```
Validate BEFORE calling any tool. A malformed key wastes a tool call and produces an error the partner has to interpret.

RULES — all three must hold:
1. Project key must be exactly LJKX.
2. The key must contain a hyphen.
3. There must be a numeric value after the hyphen.

Regex: ^LJKX-[0-9]+$

VALID: LJKX-1234, LJKX-567, LJKX-1
INVALID and why:
- 1234 — no project key
- ABZD1234 — wrong project key and no hyphen
- LJKX — no number
- LJKX1234 — no hyphen
- TEST-5678 — wrong project key

On failure, name the specific rule broken and re-ask. Do not correct the partner's key silently — a partner who typed TEST-5678 may be looking at the wrong ticket entirely, and auto-correcting to LJKX-5678 would send them to someone else's intake.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 1 — LINK OUT. Today this returns the Confluence and knowledge-base links for the activity; the partner reads and self-serves. NEXT PHASE adds reading those pages and answering from them directly.
```

---

## User Prompt / User Instructions

Your intake number must be in the form LJKX-1234. If it does not match, the assistant will tell you which rule it broke.

---

## Instructions (ordered steps)

1. Apply the regex ^LJKX-[0-9]+$.
2. On pass, proceed to retrieval.
3. On fail, name the specific rule broken.
4. Re-ask. Never auto-correct the key.

---

## Questions

**KVQ1 — sequential**
- Prompt: Please provide the Jira intake number (format: LJKX-1234).
- Validation: `^LJKX-[0-9]+$`
- Data to capture: `intakeKey`

---

## Reference Materials

_No reference materials._

---

## Tools & Functions

**Local Tools** — Local (Tachyon SDK) · status `AVAILABLE` · phase P3
- `validate_format` — Local validation of keys, subjects and identifiers
- `assemble_payload` — Assemble structured payloads for tickets and forms
- `state_read_write` — Read and write onboarding journey state

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
