# Scrum Team Project Key Resolution

> **Type:** Skill (standard)
> **ID:** `scrum-team-project-key-resolution`
> **Owner agent:** `intake-verification`
> **Parent skill:** —
> **Integration phase:** P3
> **Business rules:** —

---

## Title

Scrum Team Project Key Resolution

## Description

Resolves the allocated scrum team's Jira project key from the intake, for use in all downstream ticket creation.

---

## System Prompt / System Instructions

```
The Jira project key used for downstream ticket creation is NOT LJKX and is NOT fixed. LJKX is the intake project only. Capacity planning tickets and SPLI tickets are created in the ALLOCATED SCRUM TEAM'S OWN PROJECT, which differs per team.

RESOLUTION ORDER:
1. Journey state — if already resolved this session, reuse it.
2. The intake issue — read the allocated scrum team from the intake summary, then map team to project key. The mapping may appear directly on the intake (as a field, label, component, or linked issue), in which case use it.
3. Knowledge base — at phase 2, read the scrum team to project key mapping page.
4. Jira — at phase 3, call get_project against the candidate key to confirm it exists and is accessible before using it for creation.
5. The partner — ask only if 1 to 4 fail. Ask for the project key their scrum team uses for ICMP onboarding work, and confirm it with get_project before use.

NEVER GUESS A PROJECT KEY and never fall back to LJKX for ticket creation. A ticket created in the wrong project is invisible to the team that needs to action it, and the partner will believe it was raised.

If no scrum team is allocated on the intake, there is no project key to resolve. Say so, and note that this also means the partner is gated to Innovation only — hand that finding to Environment Progression.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 3 — DIRECT INTEGRATION. Today this reads from and writes to the target system directly via MCP or its API, and validates live. This is the highest phase; further work extends coverage, not mode.
```

---

## User Prompt / User Instructions

Capacity planning and load testing tickets are raised in your allocated scrum team's Jira project, not in LJKX. The assistant works out which project that is from your intake.

---

## Instructions (ordered steps)

1. Check journey state for an already-resolved key.
2. Read the allocated scrum team from the intake summary.
3. Resolve team to project key from the intake, then the knowledge base.
4. Confirm the candidate key with Jira get_project before use.
5. Ask the partner only as a last resort, and still confirm with get_project.
6. If no scrum team is allocated, report that and flag the Innovation-only gate.

---

## Questions

**SKQ1 — conditional**
- Condition: `project key not resolvable from intake or knowledge base`
- Prompt: I could not resolve your scrum team's Jira project key from the intake. Which project key does your scrum team use for ICMP onboarding work?
- Data to capture: `scrumTeamProjectKey`

---

## Reference Materials

- **Scrum Team to Jira Project Key Mapping** — `<CONFLUENCE_URL:SCRUM_TEAM_TO_JIRA_PROJECT_KEY_MAPPING>`
- **ICMP Onboarding Scrum Teams** — `<CONFLUENCE_URL:ICMP_ONBOARDING_SCRUM_TEAMS>`

---

## Tools & Functions

**Jira MCP** — MCP · status `AVAILABLE` · phase P3
- `get_issue` — Retrieve a Jira issue by key
    - `issueKey`: string — e.g. LJKX-1234
    - returns: issue summary, status, priority, reporter, assignee, description, labels, components, custom fields, links
- `get_project` — Retrieve a Jira project by key; used as secondary validation when get_issue fails
    - `projectKey`: string — e.g. LJKX
    - returns: project metadata, or empty when the project does not exist or the caller lacks access

---

## Future Implementation

Future implementation: resolve the scrum team to project key mapping directly from the source of record rather than a knowledge-base page, and validate the key with get_project automatically before any create_issue call, so the partner is never asked for it.
