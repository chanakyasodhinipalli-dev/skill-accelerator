# Special-Day & Growth Profiling

> **Type:** Skill (standard)
> **ID:** `special-day-growth-profiling`
> **Owner agent:** `volume-assessment`
> **Parent skill:** —
> **Integration phase:** P1
> **Business rules:** BR-19, BR-21

---

## Title

Special-Day & Growth Profiling

## Description

Captures recurring volume deviations and projected growth separately from the baseline.

---

## System Prompt / System Instructions

```
Baseline figures are insufficient on their own. Capacity fails on the peaks, and the peaks are often predictable.

CAPTURE RECURRING DEVIATIONS. Prompt with concrete examples so the partner recognises their own pattern:
- First day or first week of the month at 20-30% over average
- Annual closing periods
- Quarter end, month end, statement runs, regulatory filing dates
- Any other cyclical spike specific to the business

For each, capture: when it occurs, how much above baseline, and which operations it affects. A spike that only affects ingestion has different implications from one that affects retrieval.

CAPTURE PROJECTED GROWTH separately: the anticipated increase over the next twelve months, and its basis (business projection, planned migration, onboarding of additional upstream systems).

Growth figures feed directly into the volume-change obligation. A partner who declares 30% anticipated growth here has effectively pre-declared it; one who declares none must raise a new intake when it materialises.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 1 — LINK OUT. Today this returns the Confluence and knowledge-base links for the activity; the partner reads and self-serves. NEXT PHASE adds reading those pages and answering from them directly.
```

---

## User Prompt / User Instructions

Beyond your average volumes, tell the assistant about predictable spikes — month end, annual closing, statement runs — and the growth you expect over the next year.

---

## Instructions (ordered steps)

1. Prompt with concrete special-day examples.
2. For each deviation, capture timing, magnitude and affected operations.
3. Capture projected twelve-month growth and its basis.
4. Link declared growth to the volume-change obligation.

---

## Questions

**SGQ1 — sequential**
- Prompt: Are there predictable periods when your volume exceeds average — for example the first week of the month, quarter end, or annual closing?
- Data to capture: `specialDayScenarios`

**SGQ2 — sequential**
- Prompt: What volume growth do you anticipate over the next 12 months, and what is that based on?
- Data to capture: `projectedGrowth, growthBasis`

---

## Reference Materials

_No reference materials._

---

## Tools & Functions

_No tools bound._

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
