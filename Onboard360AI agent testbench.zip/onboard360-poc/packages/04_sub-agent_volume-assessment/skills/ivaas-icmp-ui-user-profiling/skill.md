# IIVaaS / ICMP UI User Profiling

> **Type:** Skill (standard)
> **ID:** `ivaas-icmp-ui-user-profiling`
> **Owner agent:** `volume-assessment`
> **Parent skill:** —
> **Integration phase:** P1
> **Business rules:** BR-19

---

## Title

IIVaaS / ICMP UI User Profiling

## Description

Collects user counts and concurrency where the ICMP Viewer service or UI is in use.

---

## System Prompt / System Instructions

```
Triggered when the partner's capability set includes ICMP Viewer (IVaaS) or ICMP UI usage. Skip entirely if neither applies — do not ask user concurrency questions of an API-only partner.

COLLECT:
- Number of NEW users being onboarded
- Concurrent users at MINIMUM, AVERAGE and PEAK

Concurrency is the figure that matters for the IVaaS Viewer service. A partner who reports two thousand named users but forty concurrent has a very different capacity profile from one reporting two hundred named users all active at 9am.

Prompt for the peak timing as well as the peak number — a peak concentrated in a fifteen-minute window is a different test case from one spread across a working day.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 1 — LINK OUT. Today this returns the Confluence and knowledge-base links for the activity; the partner reads and self-serves. NEXT PHASE adds reading those pages and answering from them directly.
```

---

## User Prompt / User Instructions

If you are using the ICMP IVaaS Viewer or UI, you will be asked how many users you are onboarding and how many will be using it at the same time.

---

## Instructions (ordered steps)

1. Check whether IVaaS or ICMP UI is in the capability set; skip if not.
2. Collect the number of new users being onboarded.
3. Collect minimum, average and peak concurrent users.
4. Capture when the peak occurs, not only its size.

---

## Questions

**UQ1 — conditional**
- Condition: `capabilitySet includes IVaaS or ICMP UI`
- Prompt: How many new users are being onboarded?
- Data to capture: `newUserCount`

**UQ2 — conditional**
- Condition: `capabilitySet includes IVaaS or ICMP UI`
- Prompt: What are your minimum, average and peak concurrent user counts, and when does the peak occur?
- Data to capture: `concurrentUsersMin, concurrentUsersAvg, concurrentUsersPeak, peakTiming`

---

## Reference Materials

_No reference materials._

---

## Tools & Functions

_No tools bound._

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
