# Onboard360AI — ICMP Partner Onboarding · **MVP 1**

**Package version 2.0-MVP1** · Platform: **iDocs Canvas** · Runtime: **Platform Specialist Agent on Tachyon SDK**

> **Hierarchy.** Onboard360AI is the **Master Onboarding Agent** over the eight ICMP onboarding sub-agents,
> and is **itself a sub-agent of the Platform Specialist Agent** inside iDocs Canvas.

> **MVP1 scope.** MVP1 is deliberately scoped. It is extensible with further skills and agents to make ICMP partner onboarding fully self-serviceable and workflow-driven. Author every agent and skill so that adding depth later is additive and does not change existing contracts.

> **Runtime disclosure rule.** Every agent and skill states in its opening message what is integrated today and
> what the next phase adds, so the partner always knows whether they are being linked to documentation, guided
> through it, or transacted for.

Import package containing fully defined agent and skill configurations for direct copy-paste into the
iDocs Canvas Agent Admin UI, or programmatic import.

---

## What is in here

| Item | Count |
|---|---|
| Master agent | 1 |
| Sub-agents | 8 |
| Skills | 59 |
| Business rules | 22 |
| Glossary terms | 21 |

Every agent folder contains `agent.json` and `agent.md`.
Every skill folder contains `skill.json` and `skill.md`.
JSON is for import; Markdown is for copy-paste into the Admin UI fields and for review.

---

## Folder structure

```
Onboard360AI/
├── _manifest.json              package index, environments, routing matrix, cert subjects
├── _shared/
│   ├── tools.json              tool and function catalogue with status and phase
│   ├── business-rules.json     22 rules with owning agent
│   └── glossary.json           term expansions
├── 00_master-agent_onboard360ai/
│   ├── agent.json / agent.md
│   └── skills/<skill-id>/skill.json + skill.md
└── NN_sub-agent_<id>/
    ├── agent.json / agent.md
    └── skills/<skill-id>/skill.json + skill.md
```

---

## Agent registry

| # | Sub-agent | Branch | Skills | Phase | Folder |
|---|---|---|---|---|---|
| 00 | Onboard360AI (master) | ALL | 4 | P1 | `00_master-agent_onboard360ai/` |
| 01 | POC Assistance | POC | 6 | P1 | `01_sub-agent_poc-assistance/` |
| 02 | Intake Verification | IMPLEMENTATION | 6 | P3 | `02_sub-agent_intake-verification/` |
| 03 | Foundational Setup | BOTH | 19 | P1 | `03_sub-agent_foundational-setup/` |
| 04 | Volume Assessment | IMPLEMENTATION | 6 | P3 | `04_sub-agent_volume-assessment/` |
| 05 | Load Testing (SPLI) | IMPLEMENTATION | 4 | P3 | `05_sub-agent_load-testing-spli/` |
| 06 | Apigee Subscription | BOTH | 7 | P1 | `06_sub-agent_apigee-subscription/` |
| 07 | Postman Collection Generation | BOTH | 3 | P3 | `07_sub-agent_postman-collection-generation/` |
| 08 | Environment Progression | IMPLEMENTATION | 4 | P2 | `08_sub-agent_environment-progression/` |

---

## Field mapping to the Agent Admin UI

**Sub-agent definition**

| Admin UI field | Source in `agent.json` |
|---|---|
| Agent name | `name` |
| Description | `description` |
| System instruction | `systemInstructions` |
| User instruction | `userInstructions` |
| Goals | `goals[]` |
| Tools / functions | `tools[].name` and `tools[].functions[].function` |
| Questions (sequential / conditional) | `questions[]` — `type` field distinguishes them |

**Skill definition**

| Admin UI field | Source in `skill.json` |
|---|---|
| Skill name | `name` |
| Description | `description` |
| System instruction | `systemInstructions` |
| User instruction | `userInstructions` |
| Reference materials (.md) | `referenceMaterials[]` — replace `<CONFLUENCE_URL:...>` placeholders |
| Questions (sequential / conditional) | `questions[]` |

---

## Before importing — required substitutions

1. **Confluence URLs.** Every `referenceMaterials[].url` is a placeholder of the form
   `<CONFLUENCE_URL:PAGE_NAME>`. Replace with live page URLs. Search for `<CONFLUENCE_URL` to find all.
2. **Scrum team project keys.** Ticket creation uses the allocated scrum team's project key, resolved at
   runtime from the intake. Populate the mapping page referenced by
   `scrum-team-project-key-resolution` before enabling ticket creation.
3. **Certificate subject.** Confirm `CN = EREP` is literal rather than an application placeholder before
   the Venafi skill goes live.
4. **Jira MCP server binding.** `jira_mcp_read` and `jira_mcp_write` reference `get_issue`, `get_project`
   and `create_issue`. Bind to the live MCP server name in your environment.

---

## Integration phases

| Phase | Mode | Behaviour |
|---|---|---|
| P1 | Link out | Skill returns Confluence and KB links; partner self-serves |
| P2 | Read and guide | Agent reads the linked pages and answers from them, step by step |
| P3 | Direct integration | MCP or system-native API; reads, writes, validates live |

Every skill is authored so the instruction body and the eventual tool call are swappable — advancing a
phase is a configuration change, not a rewrite. Each `skill.json` carries a `futureImplementation` field
describing how that skill acquires its details automatically as phases advance.

---

## Key rules encoded in this package

- **Agent vs skill:** goal-bearing → sub-agent; knowledge or procedure → skill.
- **Jira:** intakes go to `LJKX` (fixed). Capacity planning and SPLI tickets go to the **allocated scrum
  team's project key**, resolved from the intake — never `LJKX`, never guessed.
- **Access routing:** all service accounts → ART, both environments. Human user access → ART for QAEnt,
  AIMS for ADEnt.
- **Environments:** Innovation and Non-Prod use the QAEnt service account; Production uses the production
  account. ProdFix is ICMP-internal and never offered to partners.
- **Progression:** Innovation → sign-off → Non-Prod → Production. No skipping. No scrum team → Innovation only.
- **SPLI:** System Performance Load Ingestion Testing, performed end to end, not ICMP-only.
- **IVaaS:** ICMP Viewer as a Service. Triggers user-concurrency collection at Volume Assessment.
- **Runtime disclosure:** every agent and skill opens by stating current integration state and the next phase.
