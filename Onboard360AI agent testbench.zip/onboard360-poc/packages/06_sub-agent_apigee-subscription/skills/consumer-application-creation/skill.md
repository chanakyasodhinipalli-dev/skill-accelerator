# Consumer Application Creation / Modification

> **Type:** Skill (standard)
> **ID:** `consumer-application-creation`
> **Owner agent:** `apigee-subscription`
> **Parent skill:** —
> **Integration phase:** P1
> **Business rules:** BR-04, BR-05

---

## Title

Consumer Application Creation / Modification

## Description

Creating a new consumer application in NGDC, or correctly modifying an existing one.

---

## System Prompt / System Instructions

```
The partner either creates a NEW consumer application or modifies an EXISTING one in the Apigee marketplace. Establish which before giving any guidance — the paths differ.

NGDC RULE — state this BEFORE the partner creates anything:
ALL NEW consumer applications MUST be created in NGDC (Next Generation Data Center). Existing and legacy applications sit in the HERITAGE data center; new applications must NOT go there. A consumer application created in the wrong data center has to be recreated, and the subscription with it.

REQUIRED: the BAM App ID and Remedy ID. The Remedy ID threads through consumer application registration, application ownership identification, access provisioning, subscription management and operational support. If the partner does not have it, hand to BAM Lookup before proceeding.

SOURCE OF TRUTH: the marketplace documentation, which changes over time. At phase 2, read the current page rather than reciting a remembered procedure.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 1 — LINK OUT. Today this returns the Confluence and knowledge-base links for the activity; the partner reads and self-serves. NEXT PHASE adds reading those pages and answering from them directly.
```

---

## User Prompt / User Instructions

How to create or modify your consumer application in the Apigee marketplace. New applications must be created in NGDC — not the Heritage data center.

---

## Instructions (ordered steps)

1. Establish whether this is a new or existing consumer application.
2. State the NGDC rule before any creation step.
3. Confirm BAM App ID and Remedy ID are available; hand to BAM Lookup if not.
4. Read the current marketplace documentation and guide from it.
5. Capture the consumer application identifier into journey state.

---

## Questions

**CAQ1 — sequential**
- Prompt: Are you creating a new consumer application or modifying an existing one?
- Options: New — will be created in NGDC · Existing — modifying
- Data to capture: `consumerAppMode`

---

## Reference Materials

- **Apigee Consumer Application Guide** — `<CONFLUENCE_URL:APIGEE_CONSUMER_APPLICATION_GUIDE>`
- **NGDC Application Standards** — `<CONFLUENCE_URL:NGDC_APPLICATION_STANDARDS>`

---

## Tools & Functions

**Apigee API Marketplace** — Not integrated — instructions only · status `PLANNED` · phase P1 now, P3 target
- `(future) list_apis` — Enumerate ICMP APIs and scopes available to the partner
- `(future) create_subscription` — Submit the subscription request
- `(future) get_subscription_status` — Poll approval status

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
