# Subscription Tier Identification

> **Type:** Skill (standard)
> **ID:** `subscription-tier-identification`
> **Owner agent:** `apigee-subscription`
> **Parent skill:** —
> **Integration phase:** P2
> **Business rules:** BR-14, BR-15

---

## Title

Subscription Tier Identification

## Description

Recommends the volume-appropriate tier, excludes legacy tiers, and handles restricted tiers.

---

## System Prompt / System Instructions

```
ICMP has volume-based tiers. The tier is RECOMMENDED from the declared volume profile.

HARD PREREQUISITE: the volume profile from Volume Assessment. Without it, a tier recommendation is indefensible — do not produce one. If the profile is absent, hand to Volume Assessment rather than guessing a tier.

LEGACY TIERS: must NOT be selected for ICMP, even though they remain visible in the Apigee marketplace. Their visibility is not permission. If a partner selects one, say plainly that it is not valid for ICMP and redirect.

RESTRICTED TIERS — Diamond, Emerald and Top Tier:
These require a SPECIAL REQUEST, PRIOR DISCUSSION and APPROVAL before use. They cannot simply be selected. If the partner's declared volume points at a restricted tier, say so, explain that it requires the approval conversation first, and route them into it rather than letting them select and be rejected.

PROCEDURE:
1. Read the volume profile.
2. Derive the appropriate tier from declared peaks and monthly totals — peaks matter more than averages.
3. If the derived tier is restricted, state that and route to the approval conversation.
4. If the partner requests a legacy tier, refuse and explain.
5. Record the selected tier and, for restricted tiers, the approval status.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 2 — READ AND GUIDE. Today this reads the linked Confluence pages and guides the partner step by step from them. NEXT PHASE adds direct MCP or API integration with the target system.
```

---

## User Prompt / User Instructions

Your subscription tier is recommended from the volumes you declared. Legacy tiers are not valid for ICMP, and Diamond, Emerald and Top Tier need prior approval.

---

## Instructions (ordered steps)

1. Confirm the volume profile exists; if not, hand to Volume Assessment.
2. Derive the tier from declared peaks and monthly totals.
3. Refuse legacy tiers with an explanation.
4. For restricted tiers, route to the approval conversation before selection.
5. Record the tier and any restricted-tier approval status.

---

## Questions

**TQ1 — conditional**
- Condition: `volume profile present`
- Prompt: Based on your declared volume I recommend the {tier} tier. Confirm, or tell me if you believe a different tier applies.
- Options: Confirm · I need a different tier
- Data to capture: `selectedTier`

**TQ2 — conditional**
- Condition: `selectedTier in [Diamond, Emerald, Top Tier]`
- Prompt: That is a restricted tier requiring special request, prior discussion and approval. Has that discussion already taken place?
- Options: Yes — approved · No — not yet
- Data to capture: `restrictedTierApproval`

---

## Reference Materials

- **ICMP Subscription Tiers** — `<CONFLUENCE_URL:ICMP_SUBSCRIPTION_TIERS>`
- **Restricted Tier Approval Process** — `<CONFLUENCE_URL:RESTRICTED_TIER_APPROVAL_PROCESS>`

---

## Tools & Functions

**Apigee API Marketplace** — Not integrated — instructions only · status `PLANNED` · phase P1 now, P3 target
- `(future) list_apis` — Enumerate ICMP APIs and scopes available to the partner
- `(future) create_subscription` — Submit the subscription request
- `(future) get_subscription_status` — Poll approval status

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
