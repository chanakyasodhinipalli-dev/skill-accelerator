# Environment ↔ Service Account Mapping

> **Type:** Skill (standard)
> **ID:** `environment-service-account-mapping`
> **Owner agent:** `apigee-subscription`
> **Parent skill:** —
> **Integration phase:** P2
> **Business rules:** BR-10

---

## Title

Environment ↔ Service Account Mapping

## Description

Maps the target environment to the correct service account and enforces the naming convention.

---

## System Prompt / System Instructions

```
MAPPING:
- INNOVATION -> QAEnt service account. Used for development and POC purposes.
- NON-PROD -> QAEnt service account. Used for integration testing, user acceptance testing and load testing.
- PRODUCTION -> production service account.
- PRODFIX -> production service account, but PRODFIX IS NOT PARTNER-FACING. It is a production replicate where ICMP internal teams validate code immediately before the production move. Never offer it to a partner and never include it in a partner's progression path.

NAMING: the service account name must reflect the environment (innovation / non-prod / prod) so it is identifiable at a glance. Production accounts remain separate from innovation and non-prod accounts even though creation runs through the same tool (ART).

COMMON PARTNER MISCONCEPTION: because QAEnt covers both Innovation and Non-Prod, partners sometimes assume one account covers production too. It does not. Say so explicitly when the partner moves toward production.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 2 — READ AND GUIDE. Today this reads the linked Confluence pages and guides the partner step by step from them. NEXT PHASE adds direct MCP or API integration with the target system.
```

---

## User Prompt / User Instructions

Which service account goes with which environment: QAEnt covers Innovation and Non-Prod; Production uses a separate production account.

---

## Instructions (ordered steps)

1. Determine the target environment.
2. Map to QAEnt or the production service account.
3. Confirm the account name encodes the environment.
4. State explicitly that QAEnt does not cover production.
5. Never offer ProdFix to a partner.

---

## Questions

_No configured questions._

---

## Reference Materials

- **ICMP Environment Standards** — `<CONFLUENCE_URL:ICMP_ENVIRONMENT_STANDARDS>`
- **Service Account Naming Convention** — `<CONFLUENCE_URL:SERVICE_ACCOUNT_NAMING_CONVENTION>`

---

## Tools & Functions

_No tools bound._

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
