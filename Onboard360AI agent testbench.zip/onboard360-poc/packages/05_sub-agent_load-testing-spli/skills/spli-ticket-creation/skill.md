# SPLI Ticket Creation

> **Type:** Skill (standard)
> **ID:** `spli-ticket-creation`
> **Owner agent:** `load-testing-spli`
> **Parent skill:** —
> **Integration phase:** P3
> **Business rules:** BR-22

---

## Title

SPLI Ticket Creation

## Description

Raises the SPLI load testing ticket in the allocated scrum team's Jira project with the full requirement package.

---

## System Prompt / System Instructions

```
Raise the SPLI ticket for the load testing team.

PROJECT KEY — the same rule as capacity planning. NOT LJKX, NOT fixed. Use the ALLOCATED SCRUM TEAM'S project key resolved by the Scrum Team Project Key Resolution skill and held in journey state. If absent, hand back to Intake Verification. Never guess and never default to LJKX.

TICKET CONTENT: the complete SPLI requirement package, plus a link to the originating LJKX intake and a link to the capacity planning ticket so the two are traceable to each other.

PROCEDURE: call Jira MCP create_issue with the resolved project key. Read back with get_issue to confirm creation. Report the ticket key and URL to the partner. Do not report success unless the read-back confirms it.

AFTER CREATION: tell the partner what happens next — the load testing team picks it up, and SPLI completion is a prerequisite for production progression. A partner who does not know this waits passively at the wrong step.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 3 — DIRECT INTEGRATION. Today this reads from and writes to the target system directly via MCP or its API, and validates live. This is the highest phase; further work extends coverage, not mode.
```

---

## User Prompt / User Instructions

The assistant raises your SPLI load testing ticket and links it to your intake and capacity planning ticket, then tells you what happens next.

---

## Instructions (ordered steps)

1. Retrieve the resolved scrum team project key from journey state.
2. If absent, hand back to Intake Verification.
3. Assemble the full SPLI requirement package as the ticket payload.
4. Link to the LJKX intake and the capacity planning ticket.
5. Call Jira MCP create_issue with the resolved project key.
6. Read back with get_issue to confirm.
7. Report the ticket key and state that SPLI completion gates production progression.

---

## Questions

_No configured questions._

---

## Reference Materials

- **SPLI Ticket Template** — `<CONFLUENCE_URL:SPLI_TICKET_TEMPLATE>`
- **Scrum Team to Jira Project Key Mapping** — `<CONFLUENCE_URL:SCRUM_TEAM_TO_JIRA_PROJECT_KEY_MAPPING>`

---

## Tools & Functions

**Jira MCP** — MCP · status `AVAILABLE` · phase P3
- `create_issue` — Create a Jira issue in the scrum team's project
    - `projectKey`: string — RESOLVED PER SCRUM TEAM, not hardcoded. Obtained from the Scrum Team Project Key Resolution skill.
    - `issueType`: string
    - `summary`: string
    - `description`: string — structured payload
    - `priority`: string (optional)
    - `labels`: array<string> (optional)
    - `customFields`: object (optional)
    - returns: created issue key and URL
- `get_issue` — Read back the created issue to confirm and report the key to the partner
    - `issueKey`: string
    - returns: issue payload

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
