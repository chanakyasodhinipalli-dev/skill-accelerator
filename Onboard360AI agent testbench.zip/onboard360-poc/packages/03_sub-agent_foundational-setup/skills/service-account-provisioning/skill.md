# Service Account Provisioning

> **Type:** Skill (master)
> **ID:** `service-account-provisioning`
> **Owner agent:** `foundational-setup`
> **Parent skill:** —
> **Integration phase:** P3
> **Business rules:** BR-07, BR-08, BR-10

---

## Title

Service Account Provisioning

## Description

Master skill covering why service accounts are required, how to obtain them, and the naming and grouping rules.

---

## System Prompt / System Instructions

```
EXPLAIN WHY BEFORE ASKING FOR ONE — partners who do not understand this supply a personal account and fail later.

ICMP APIs are consumed by APPLICATIONS, not by individuals. Integrations therefore require accounts that are:
- non-human
- non-expiring
- dedicated application accounts
- not tied to any specific user

This is why service accounts carry: application authentication; API access; Apigee consumer application association; security group membership; auditing; and operational support.

ENVIRONMENT MAPPING
Innovation -> QAEnt service account
Non-Prod -> QAEnt service account
Production -> production service account
All creation routes through ART regardless of environment.

NAMING
The service account name must encode the environment (innovation / non-prod / prod) so it is identifiable at a glance. Production accounts remain separate from innovation and non-prod accounts even though creation runs through the same tool.

GROUP MEMBERSHIP
The service account must be added to the LDAP groups provided by ICMP resources during onboarding. Which groups apply depends on the access type required, the APIs in scope and the operations to be performed. This is determined during onboarding, not from a fixed list. DO NOT GUESS GROUP NAMES — if the group set has not been provided, say so and record it as an open item against the ICMP onboarding contact.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 3 — DIRECT INTEGRATION. Today this reads from and writes to the target system directly via MCP or its API, and validates live. This is the highest phase; further work extends coverage, not mode.
```

---

## User Prompt / User Instructions

Why ICMP requires service accounts rather than personal accounts, how to request them, and how they must be named.

---

## Instructions (ordered steps)

1. Explain why service accounts are required.
2. Determine which environments need accounts.
3. Invoke the environment-specific sub-skill.
4. Apply the environment-encoding naming rule.
5. Capture the ICMP-provided LDAP group set; never guess group names.

---

## Questions

**SAQ1 — sequential**
- Prompt: Which environments do you need service accounts for?
- Options: Innovation · Non-Prod · Production
- Input type: multi-select
- Data to capture: `serviceAccountEnvironments`

---

## Reference Materials

- **Service Account Standards** — `<CONFLUENCE_URL:SERVICE_ACCOUNT_STANDARDS>`
- **ART Service Account Request Guide** — `<CONFLUENCE_URL:ART_SERVICE_ACCOUNT_REQUEST_GUIDE>`

---

## Tools & Functions

**ART — Access Request Tool** — Not integrated — instructions only · status `PLANNED` · phase P1 now, P3 target
- `(future) create_service_account_request` — Raise a service account request for QAEnt or ADEnt
- `(future) add_group_membership` — Add a service account to an LDAP group
- `(future) create_user_access_request` — Raise QAEnt user access request

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
