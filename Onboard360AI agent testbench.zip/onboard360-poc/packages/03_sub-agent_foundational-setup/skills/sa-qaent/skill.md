# QAEnt Service Account Creation

> **Type:** Skill (sub)
> **ID:** `sa-qaent`
> **Owner agent:** `foundational-setup`
> **Parent skill:** `service-account-provisioning`
> **Integration phase:** P3
> **Business rules:** BR-08, BR-10

---

## Title

QAEnt Service Account Creation

## Description

Non-production service account creation via ART, serving Innovation and Non-Prod.

---

## System Prompt / System Instructions

```
The QAEnt service account serves BOTH Innovation and Non-Prod. Partners frequently assume they need one per environment; clarify that QAEnt covers both, but that the naming should still make the intended usage clear.

Creation routes through ART (Access Request Tool). Walk through the request fields, the BAM App ID and Remedy ID that must be supplied, and the approval path.

Once created, the account must be added to the ICMP-provided LDAP groups — also through ART.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 3 — DIRECT INTEGRATION. Today this reads from and writes to the target system directly via MCP or its API, and validates live. This is the highest phase; further work extends coverage, not mode.
```

---

## User Prompt / User Instructions

How to request a QAEnt service account through ART. This one account covers both Innovation and Non-Prod.

---

## Instructions (ordered steps)

1. Confirm QAEnt covers both Innovation and Non-Prod.
2. Apply the environment-encoding naming rule.
3. Walk through the ART service account request.
4. Supply BAM App ID and Remedy ID.
5. Request the ICMP-provided LDAP group memberships through ART.

---

## Questions

_No configured questions._

---

## Reference Materials

- **ART Service Account Request Guide** — `<CONFLUENCE_URL:ART_SERVICE_ACCOUNT_REQUEST_GUIDE>`
- **QAEnt Naming Standards** — `<CONFLUENCE_URL:QAENT_NAMING_STANDARDS>`

---

## Tools & Functions

**ART — Access Request Tool** — Not integrated — instructions only · status `PLANNED` · phase P1 now, P3 target
- `(future) create_service_account_request` — Raise a service account request for QAEnt or ADEnt
- `(future) add_group_membership` — Add a service account to an LDAP group
- `(future) create_user_access_request` — Raise QAEnt user access request

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
