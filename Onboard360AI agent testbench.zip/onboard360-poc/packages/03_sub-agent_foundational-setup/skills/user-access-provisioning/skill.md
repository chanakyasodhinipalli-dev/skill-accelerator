# User Access Provisioning

> **Type:** Skill (master)
> **ID:** `user-access-provisioning`
> **Owner agent:** `foundational-setup`
> **Parent skill:** —
> **Integration phase:** P3
> **Business rules:** BR-09

---

## Title

User Access Provisioning

## Description

Master skill covering human user access to environments and LDAP groups.

---

## System Prompt / System Instructions

```
This covers HUMAN USER access, which is a different path from service account access. Establish which the partner is asking about before routing — the two are routinely conflated and sending a partner to the wrong tool costs them a full request cycle.

ROUTING: invoke the ART/AIMS Routing Boundary skill and follow its determination. Do not restate the routing rule from memory.

Determine which environments the users need access to, which LDAP groups, and how many users. If the partner is requesting UI or IVaaS access at any scale, note that user concurrency figures will be required at Volume Assessment.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 3 — DIRECT INTEGRATION. Today this reads from and writes to the target system directly via MCP or its API, and validates live. This is the highest phase; further work extends coverage, not mode.
```

---

## User Prompt / User Instructions

How your people get access to ICMP environments and LDAP groups. This is a different process from service accounts.

---

## Instructions (ordered steps)

1. Confirm this is human user access, not service account access.
2. Invoke the ART/AIMS Routing Boundary skill.
3. Determine environments, groups and user count.
4. Invoke the environment-specific sub-skill.
5. Flag the concurrency requirement where UI or IVaaS is in scope.

---

## Questions

_No configured questions._

---

## Reference Materials

- **ICMP User Access Guide** — `<CONFLUENCE_URL:ICMP_USER_ACCESS_GUIDE>`

---

## Tools & Functions

**ART — Access Request Tool** — Not integrated — instructions only · status `PLANNED` · phase P1 now, P3 target
- `(future) create_service_account_request` — Raise a service account request for QAEnt or ADEnt
- `(future) add_group_membership` — Add a service account to an LDAP group
- `(future) create_user_access_request` — Raise QAEnt user access request

**AIMS — Access and Identity Management System** — Not integrated — instructions only · status `PLANNED` · phase P1 now, P3 target
- `(future) request_ldap_group_access` — Request ADEnt user access to an LDAP group

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
