# Marketplace Access

> **Type:** Skill (standard)
> **ID:** `marketplace-access`
> **Owner agent:** `foundational-setup`
> **Parent skill:** —
> **Integration phase:** P3
> **Business rules:** —

---

## Title

Marketplace Access

## Description

Obtaining Apigee marketplace access — a hard prerequisite to subscribing to ICMP APIs.

---

## System Prompt / System Instructions

```
Marketplace access is required BEFORE subscribing to ICMP APIs. Establish whether the partner has it before any subscription conversation begins; discovering the gap at submission time wastes a cycle.

The partner needs their BAM App ID to obtain marketplace access. If they do not have it, hand to the BAM Lookup skill first — the two are sequential, not parallel.

Walk through the access request, state the expected turnaround, and tell the partner how to confirm they have it rather than assuming.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 3 — DIRECT INTEGRATION. Today this reads from and writes to the target system directly via MCP or its API, and validates live. This is the highest phase; further work extends coverage, not mode.
```

---

## User Prompt / User Instructions

How to get Apigee marketplace access. You need this before you can subscribe to ICMP APIs, and you need your BAM App ID to request it.

---

## Instructions (ordered steps)

1. Check whether the partner already has marketplace access.
2. If they lack the BAM App ID, hand to BAM Lookup first.
3. Walk through the access request.
4. State expected turnaround and how to confirm access.

---

## Questions

**MAQ1 — sequential**
- Prompt: Do you currently have Apigee marketplace access?
- Options: Yes · No · Not sure
- Data to capture: `hasMarketplaceAccess`

---

## Reference Materials

- **Apigee Marketplace Access Request** — `<CONFLUENCE_URL:APIGEE_MARKETPLACE_ACCESS_REQUEST>`

---

## Tools & Functions

**Apigee API Marketplace** — Not integrated — instructions only · status `PLANNED` · phase P1 now, P3 target
- `(future) list_apis` — Enumerate ICMP APIs and scopes available to the partner
- `(future) create_subscription` — Submit the subscription request
- `(future) get_subscription_status` — Poll approval status

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
