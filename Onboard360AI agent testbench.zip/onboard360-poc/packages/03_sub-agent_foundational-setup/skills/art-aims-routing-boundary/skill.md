# ART / AIMS Routing Boundary

> **Type:** Skill (standard)
> **ID:** `art-aims-routing-boundary`
> **Owner agent:** `foundational-setup`
> **Parent skill:** —
> **Integration phase:** P1
> **Business rules:** BR-08, BR-09

---

## Title

ART / AIMS Routing Boundary

## Description

Determines authoritatively whether a given access request goes to ART or to AIMS. Invoked by every access-related skill.

---

## System Prompt / System Instructions

```
This skill exists because sending a partner to the wrong access tool costs them a full request cycle, and the two tools are routinely conflated. Every access-related skill invokes this one rather than restating the rule.

THE BOUNDARY IS BY REQUEST TYPE, NOT BY ENVIRONMENT.

+---------------------------------------+---------------------+---------------------+
| Request type                          | ADEnt (production)  | QAEnt (non-prod)    |
+---------------------------------------+---------------------+---------------------+
| Service account creation              | ART                 | ART                 |
| Service account group membership      | ART                 | ART                 |
| Human user access                     | AIMS                | ART                 |
| Human user LDAP group access          | AIMS                | ART                 |
+---------------------------------------+---------------------+---------------------+

RULES IN WORDS:
1. ALL service accounts — creation and group addition — route through ART, in BOTH environments, without exception.
2. Human USER access routes through ART for QAEnt.
3. Human USER access to LDAP groups in ADEnt routes through AIMS. This is the only AIMS case.

DETERMINATION PROCEDURE — ask two questions and the answer follows:
Q1: Is the subject a service account or a human user?
    - Service account -> ART. Stop. The environment does not matter.
    - Human user -> continue to Q2.
Q2: Which environment?
    - QAEnt (Innovation or Non-Prod) -> ART.
    - ADEnt (Production) -> AIMS.

EDGE CASES:
- A human user needing access to a service account's credentials or ownership is a service-account-ownership request, not user access -> ART.
- A functional or shared mailbox account is a non-human account -> ART.
- A partner asking for "access to production" without specifying subject: ask Q1 before answering. Do not guess.

NEVER send a partner to both tools for the same request, and never leave the tool ambiguous. State the tool, the reason, and what they will need before they start.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 1 — LINK OUT. Today this returns the Confluence and knowledge-base links for the activity; the partner reads and self-serves. NEXT PHASE adds reading those pages and answering from them directly.
```

---

## User Prompt / User Instructions

Which tool to use for which access request: ART or AIMS. Ask the assistant and it will tell you definitively, along with what you need before you start.

---

## Instructions (ordered steps)

1. Ask whether the subject is a service account or a human user.
2. If service account -> ART, regardless of environment. Stop.
3. If human user -> determine the environment.
4. QAEnt -> ART. ADEnt -> AIMS.
5. State the tool, the reason, and the prerequisites for that request.
6. Resolve edge cases (service account ownership, functional accounts) to ART.

---

## Questions

**RBQ1 — sequential**
- Prompt: Is this access request for a service account or a human user?
- Options: Service account · Human user · Not sure
- Data to capture: `accessSubjectType`

**RBQ2 — conditional**
- Condition: `RBQ1 == 'Human user'`
- Prompt: Which environment does the user need access to?
- Options: Innovation (QAEnt) · Non-Prod (QAEnt) · Production (ADEnt)
- Data to capture: `accessEnvironment`

**RBQ3 — conditional**
- Condition: `RBQ1 == 'Not sure'`
- Prompt: Will a person log in with these credentials, or will an application authenticate with them?
- Options: A person logs in · An application authenticates
- Data to capture: `accessSubjectType`

---

## Reference Materials

- **ART Access Request Guide** — `<CONFLUENCE_URL:ART_ACCESS_REQUEST_GUIDE>`
- **AIMS LDAP Group Access Guide** — `<CONFLUENCE_URL:AIMS_LDAP_GROUP_ACCESS_GUIDE>`
- **ICMP Access Routing Matrix** — `<CONFLUENCE_URL:ICMP_ACCESS_ROUTING_MATRIX>`

---

## Tools & Functions

**ART — Access Request Tool** — Not integrated — instructions only · status `PLANNED` · phase P1 now, P3 target
- `(future) create_service_account_request` — Raise a service account request for QAEnt or ADEnt
- `(future) add_group_membership` — Add a service account to an LDAP group
- `(future) create_user_access_request` — Raise QAEnt user access request

**AIMS — Access and Identity Management System** — Not integrated — instructions only · status `PLANNED` · phase P1 now, P3 target
- `(future) request_ldap_group_access` — Request ADEnt user access to an LDAP group

---

## Future Implementation

Future implementation: at phase 3, submit the request directly to the determined tool via its API and return the request reference to the partner, rather than instructing them to raise it themselves.
