# Environment Variable Seeding

> **Type:** Skill (standard)
> **ID:** `environment-variable-seeding`
> **Owner agent:** `postman-collection-generation`
> **Parent skill:** —
> **Integration phase:** P3
> **Business rules:** —

---

## Title

Environment Variable Seeding

## Description

Seeds the collection with the correct environment, service account and endpoint values.

---

## System Prompt / System Instructions

```
Seed a Postman environment alongside the collection.

SEED: target environment name (Innovation / Non-Prod / Production); base URL for that environment; service account (QAEnt for Innovation and Non-Prod, production account for Production); App Identifier; and any required standard headers.

NEVER EMBED SECRETS. Credentials, tokens, private keys and certificate material are named placeholders only. State clearly which placeholders the partner must fill in themselves and where each value comes from.

Where the capability set includes streaming or notification APIs, include the certificate configuration as a documented placeholder and point to the Venafi Certificates skill for how to obtain it.

Name the environment file so the target environment is obvious. A partner running a Non-Prod collection against production values is a real and avoidable incident.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 3 — DIRECT INTEGRATION. Today this reads from and writes to the target system directly via MCP or its API, and validates live. This is the highest phase; further work extends coverage, not mode.
```

---

## User Prompt / User Instructions

The collection comes with an environment file pre-filled with your service account and endpoint details. Credentials are left as placeholders for you to complete.

---

## Instructions (ordered steps)

1. Seed environment name, base URL, service account, App Identifier and standard headers.
2. Leave all secrets as named placeholders.
3. State which placeholders the partner must complete and where each value comes from.
4. Include certificate placeholders where streaming or notifications are in scope.
5. Name files so the target environment is unambiguous.

---

## Questions

_No configured questions._

---

## Reference Materials

_No reference materials._

---

## Tools & Functions

**Postman Collection Generator** — Local tool · status `AVAILABLE` · phase P3
- `build_collection` — Build a Postman v2.1 collection from the approved scope set
    - `scopes`: array<string>
    - `environment`: Innovation|Non-Prod|Production
    - `serviceAccount`: string
    - `baseUrl`: string
    - returns: collection JSON
- `emit_download` — Deliver the collection to the partner as a downloadable file
    - `collection`: object
    - `filename`: string
    - returns: download reference

**ICMP & iDocs APIs** — Direct API · status `AVAILABLE` · phase P3
- `icmp_ingest` — Ingest or archive a document into ICMP
- `icmp_search` — Search documents by metadata
- `icmp_retrieve` — Retrieve or stream document content
- `icmp_notifications` — Manage request, document and package notification subscriptions
- `idocs_document_services` — iDocs Canvas document intelligence operations

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
