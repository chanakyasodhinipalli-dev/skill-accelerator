# Scope-Driven Collection Build

> **Type:** Skill (standard)
> **ID:** `scope-driven-collection-build`
> **Owner agent:** `postman-collection-generation`
> **Parent skill:** —
> **Integration phase:** P3
> **Business rules:** BR-13

---

## Title

Scope-Driven Collection Build

## Description

Builds the Postman collection from the approved scope set so it contains only permitted requests.

---

## System Prompt / System Instructions

```
Build from the APPROVED scope set, not the requested one. If the subscription is not yet approved, say so and wait — a collection built on an unapproved scope teaches the partner to call things they will be denied, and they will believe the denial is a defect.

INCLUDE EXACTLY what the approved scope permits. Do NOT add convenience examples outside the approved scope, however helpful they look: a partner who finds a request in their collection reasonably assumes they are entitled to call it, and discovers otherwise at runtime.

STRUCTURE the collection by operation — ingestion, search, retrieval, notifications — matching the partner's capability set. Include realistic example payloads consistent with their repository's metadata model.

For each request, include a short description stating which scope permits it. This makes the enforcement model visible in the artifact the partner actually uses.

Emit as a Postman v2.1 collection.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 3 — DIRECT INTEGRATION. Today this reads from and writes to the target system directly via MCP or its API, and validates live. This is the highest phase; further work extends coverage, not mode.
```

---

## User Prompt / User Instructions

The generated collection contains exactly the requests your approved scope permits — nothing more, so you are not led into calls that will be denied.

---

## Instructions (ordered steps)

1. Confirm the subscription is approved and read the approved scope set.
2. Include only requests the approved scope permits.
3. Structure by operation, matching the capability set.
4. Include example payloads consistent with the repository metadata model.
5. Annotate each request with the scope that permits it.
6. Emit as Postman v2.1.

---

## Questions

_No configured questions._

---

## Reference Materials

_No reference materials._

---

## Tools & Functions

**Postman Collection Generator** — Local tool · status `AVAILABLE` · phase P3
- `build_collection` — Build a Postman v2.1 collection from the approved scope set
    - `scopes`: array<string>
    - `environment`: Innovation|Non-Prod|Production
    - `serviceAccount`: string
    - `baseUrl`: string
    - returns: collection JSON
- `emit_download` — Deliver the collection to the partner as a downloadable file
    - `collection`: object
    - `filename`: string
    - returns: download reference

**ICMP & iDocs APIs** — Direct API · status `AVAILABLE` · phase P3
- `icmp_ingest` — Ingest or archive a document into ICMP
- `icmp_search` — Search documents by metadata
- `icmp_retrieve` — Retrieve or stream document content
- `icmp_notifications` — Manage request, document and package notification subscriptions
- `idocs_document_services` — iDocs Canvas document intelligence operations

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
