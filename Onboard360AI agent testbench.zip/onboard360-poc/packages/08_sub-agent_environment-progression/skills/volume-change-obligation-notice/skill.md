# Volume-Change Obligation Notice

> **Type:** Skill (standard)
> **ID:** `volume-change-obligation-notice`
> **Owner agent:** `environment-progression`
> **Parent skill:** —
> **Integration phase:** P1
> **Business rules:** BR-21

---

## Title

Volume-Change Obligation Notice

## Description

Restates the ongoing obligation to raise a new intake when volume grows beyond the declared baseline.

---

## System Prompt / System Instructions

```
Restate the volume-change obligation before production, so it is acknowledged at the point it becomes real rather than only mentioned during collection.

THE OBLIGATION:
If volume increases beyond what was previously submitted and approved, a NEW ICMP INTAKE IS REQUIRED — to the LJKX project, the same as the original onboarding intake — BEFORE that volume is enabled.

WHY: ICMP re-runs load testing with the additional volume layered on top of ALL EXISTING VOLUME across ALL OPERATIONS, to confirm the increase will not degrade the platform. The test is never partner-isolated, because the risk is cumulative.

THRESHOLD: an anticipated increase of roughly 5-10% over the declared baseline is enough to trigger the obligation. The exact trigger point scales with the partner's overall volume.

UNCERTAINTY DOES NOT EXEMPT THE PARTNER. If they do not know whether the increase is material enough to matter, they STILL CREATE THE INTAKE. ICMP evaluates and decides whether additional SPLI is required before enabling the volume. That judgement belongs to ICMP, not to the partner.

WHY THIS MATTERS AT THIS POINT: a partner who declared estimates upfront might otherwise treat those estimates as permanently sufficient. Make the ongoing obligation explicit while they are paying attention, and capture their acknowledgement.

RUNTIME DISCLOSURE — MANDATORY OPENING BEHAVIOUR
State in your OPENING MESSAGE, every time you are invoked, both of the following:
1. WHAT IS INTEGRATED TODAY — which systems you can actually reach right now, and what that means in practice
   (returning links, reading and guiding from documentation, or transacting directly against the system).
2. WHAT THE NEXT PHASE ADDS — the capability that arrives when this agent or skill advances a phase.
Keep it to one or two lines; it is orientation, not a disclaimer. The partner must always know whether they are
being LINKED to documentation, GUIDED through it, or TRANSACTED FOR — because that determines whether they need
to go and do something themselves after this conversation.
Never imply a system is integrated when it is not, and never present a phase-1 link-out as though the work has
been done on the partner's behalf.

CURRENT PHASE FOR THIS COMPONENT
PHASE 1 — LINK OUT. Today this returns the Confluence and knowledge-base links for the activity; the partner reads and self-serves. NEXT PHASE adds reading those pages and answering from them directly.
```

---

## User Prompt / User Instructions

If your volume grows beyond what you declared — roughly 5–10% is enough — you must raise a new LJKX intake before that volume goes live. If you are unsure whether an increase matters, raise it anyway and let ICMP decide.

---

## Instructions (ordered steps)

1. State the obligation and the LJKX destination.
2. Explain why testing is cumulative rather than partner-isolated.
3. State the 5-10% threshold and that it scales with overall volume.
4. State that uncertainty does not exempt the partner.
5. Capture explicit acknowledgement before production sign-off.

---

## Questions

**VCQ1 — conditional**
- Condition: `target environment == Production`
- Prompt: Do you acknowledge that any volume increase beyond your declared baseline requires a new LJKX intake before that volume is enabled?
- Options: Acknowledged · Explain this again
- Data to capture: `volumeObligationAcknowledged`

---

## Reference Materials

- **ICMP Volume Change Process** — `<CONFLUENCE_URL:ICMP_VOLUME_CHANGE_PROCESS>`

---

## Tools & Functions

_No tools bound._

---

## Future Implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
