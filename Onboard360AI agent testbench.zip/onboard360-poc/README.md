# Onboard360AI — Agent-to-Agent Test Bench

A POC harness for testing whether the ICMP partner onboarding agents and skills
actually interact the way the architecture says they do.

It loads the **exact same JSON package** that the architecture build produces —
9 agents, 59 skills, 22 business rules — and executes it. Nothing is
re-implemented by hand, so what you test here is what you authored.

> This is a test bench, not a product. Single session per process, in-memory
> state, no persistence, no auth. It exists to answer one question: *do the
> agents and skills hand off, activate and enforce as expected?*

---

## What it gives you

| | |
|---|---|
| **Platform Specialist Agent** | Composes agents and skills from configuration at runtime, owns the tool surface, enforces contracts |
| **Agent-to-agent handoff** | Validated against each agent's declared `invokes` — an agent cannot hand off to an agent it does not declare |
| **Skill activation** | Validated against each agent's declared `skills` |
| **Real-time contracts** | 12 contracts across four interception points: pre-model, post-model, pre-tool, post-tool |
| **Tool layer** | Mock fixtures by default (no network); Jira MCP, KB, Postman generator, ICMP/iDocs APIs, local tools, plus instruction-only stubs for BAM, Venafi, ART, AIMS, Apigee |
| **Journey state** | With provenance per value — you can see whether a figure came from a system, the knowledge base, or the partner |
| **Orchestration tape** | Live UI panel recording every handoff, skill, tool call and contract check with depth and timing |
| **Enterprise LLM slot** | One file to edit; nothing else in the codebase imports a provider |

---

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env

python run.py --check     # validate package, contracts, LLM
python run.py --flow      # scripted end-to-end run, prints the tape
python run.py             # web bench at http://127.0.0.1:8000
```

The default provider is `scripted` — a deterministic test double with **no
network and no model**. Use it to verify orchestration mechanics first, so that
when you connect the real LLM you know any new failure is the model's, not the
framework's.

---

## Connecting your enterprise LLM

**One file: `llm/providers/enterprise.py`.** Nothing else needs to change.

1. Fill in `.env`:

   ```
   LLM_PROVIDER=enterprise
   LLM_ENDPOINT=https://<your-gateway>/v1/chat/completions
   LLM_MODEL=<your-model-id>
   LLM_API_KEY=<token>
   ```

2. Shape two methods to match your gateway:

   - `_build_request()` — three worked shapes are included (OpenAI-compatible,
     Anthropic-style with hoisted system, single flattened prompt). Keep one.
   - `_parse_response()` — tries the common shapes in order and raises with the
     actual payload keys if none match, so a mismatch is obvious rather than silent.

3. Verify in isolation before touching the agents:

   ```bash
   python -m scripts.check_llm
   ```

Auth patterns already handled via `.env`: static bearer, custom header name and
prefix, arbitrary extra headers, mTLS client certificate, private CA bundle,
corporate proxy. OAuth2 client credentials has a marked stub —
`_fetch_oauth_token()` — with the flow written out in the docstring.

**The runtime does not require native tool or function calling.** Agent actions
travel in a JSON envelope inside the model's text, so any endpoint that returns
a string will work.

You can also switch providers at runtime without restarting:
`POST /api/provider {"provider": "enterprise"}`.

---

## The action protocol

Each agent turn returns exactly one action:

```json
{"thought": "...", "action": "reply",        "message": "..."}
{"thought": "...", "action": "invoke_skill", "skill_id": "..."}
{"thought": "...", "action": "handoff",      "agent_id": "...", "reason": "..."}
{"thought": "...", "action": "tool_call",    "tool": "...", "function": "...", "args": {}}
{"thought": "...", "action": "goal_met",     "message": "..."}
```

The parser is tolerant: fenced JSON, bare JSON, or plain prose (coerced to a
reply so a chatty model does not break the flow).

---

## Contracts

| Point | Contract | Enforces |
|---|---|---|
| pre-model | `no_secrets_outbound` | No key material, tokens or PAN-shaped values reach the model |
| pre-model | `agent_identity_present` | The runtime always tells the model which agent it is |
| post-model | `parseable_action` | The response is a usable action |
| post-model | `runtime_disclosure` | **BR-23** — opening message states what is integrated today and what the next phase adds |
| post-model | `declared_handoff_target` | An agent can only hand off to an agent it declares |
| post-model | `declared_skill` | An agent can only invoke skills it owns |
| pre-tool | `tool_in_scope` | Only declared tools; skill tools add to the agent's surface, they do not restrict it |
| pre-tool | `ljkx_key_format` | **BR-01** — `LJKX-\d+` validated before the Jira call is made |
| pre-tool | `ticket_project_key_not_ljkx` | **BR-21** — capacity and SPLI tickets go to the scrum team's project, never LJKX, never blank |
| pre-tool | `no_secrets_to_tools` | No credential material in tool arguments |
| post-tool | `tool_result_shape` | A tool returned something |
| post-tool | `no_raw_error_passthrough` | Tool errors carry a plain-language diagnosis, not a raw payload |

`CONTRACT_MODE=block` stops the action and feeds the violation back to the agent
as a correction. `warn` records it and continues — useful when you want to see
how far a flow gets rather than stopping at the first violation.

### Probing them

Four trigger phrases force specific violations. They are buttons in the UI and
work in the CLI:

| Phrase | Fires |
|---|---|
| `force-nodisclose hello` | BR-23 — opening without runtime disclosure |
| `force-badkey LJKX-1234` | BR-01 — malformed intake key reaches the tool boundary |
| `force-undeclared` | `tool_in_scope` — agent calls Venafi without declaring it |
| `force-ljkx` | BR-21 — ticket creation aimed at LJKX |

---

## The UI

Two panels. Left is the conversation with an agent-stack breadcrumb
(`Platform Specialist Agent ▸ onboard360ai ▸ intake-verification`). Right is the
**orchestration tape**: a vertical rail where every event is a typed, colour-coded
token, indented by call depth, with timings. Colours match the architecture
diagram — amber P1, teal P2, indigo P3.

Two more tabs on the tape:

- **State** — every captured value with its provenance badge (system / knowledge
  base / partner / context / derived), open items with owners, and any conflicts
  the runtime surfaced rather than silently overwriting.
- **Topology** — all agents with skill counts, declared handoff targets, tool
  bindings, and the registered contracts per interception point.

---

## Layout

```
config/settings.py         environment-driven configuration
llm/
  base.py                  LLMClient interface
  registry.py              provider resolution
  providers/
    enterprise.py          ← THE FILE YOU EDIT
    openai_compatible.py   generic /v1/chat/completions
    scripted.py            deterministic test double, no network
core/
  models.py                typed views over the package JSON
  loader.py                loads + integrity-checks the package
  state.py                 journey state with provenance and conflict surfacing
  contracts.py             12 contracts across 4 interception points
  runtime.py               SpecialistAgent, action protocol, handoffs, skills
  trace.py                 execution trace
tools/registry.py          mock + live tool handlers
ui/app.py                  FastAPI
ui/static/index.html       chat + orchestration tape
packages/Onboard360AI/     the agent/skill package under test
tests/test_flow.py         18 regression tests
run.py                     serve | --cli | --flow | --check
scripts/check_llm.py       verify the gateway in isolation
```

---

## Testing a different package

`PACKAGE_PATH` points anywhere. Export a revised package from the architecture
build, point the bench at it, and `python run.py --check` will report integrity
problems — missing skills, unknown handoff targets, orphaned parents — before you
run a single turn.

---

## Known limits

- One session per process. Restart or `POST /api/reset` between runs.
- State is in memory only.
- `TOOL_MODE=live` has no registered handlers yet; add them to `LIVE_HANDLERS`
  in `tools/registry.py`. Until then every tool resolves to its mock.
- The scripted provider follows the documented happy path plus four failure
  paths. It does not reason — it is there to prove the wiring, not the prompts.
