#!/usr/bin/env python3
"""Entrypoint.

    python run.py               start the web bench on http://127.0.0.1:8000
    python run.py --cli         terminal session, same runtime
    python run.py --flow        run the scripted end-to-end flow and print the tape
    python run.py --check       validate package + LLM + contracts, then exit
"""
from __future__ import annotations

import argparse
import sys


def cmd_serve():
    import uvicorn
    from config.settings import settings
    print(f"Onboard360AI test bench → http://{settings.host}:{settings.port}")
    print(f"  llm provider : {settings.llm_provider}")
    print(f"  tool mode    : {settings.tool_mode}")
    print(f"  contracts    : {'on/' + settings.contract_mode if settings.enforce_contracts else 'off'}")
    uvicorn.run("ui.app:app", host=settings.host, port=settings.port, reload=False)


def cmd_cli():
    from core.runtime import SpecialistAgent
    bench = SpecialistAgent()
    print("Onboard360AI CLI. Ctrl-C to exit. Commands: /state /trace /topology /reset\n")
    while True:
        try:
            msg = input("you › ").strip()
        except (EOFError, KeyboardInterrupt):
            print(); return
        if not msg:
            continue
        if msg == "/reset":
            bench.reset(); print("· session reset\n"); continue
        if msg == "/state":
            for line in bench.state.summary_lines() or ["· empty"]:
                print("   ", line)
            print(); continue
        if msg == "/trace":
            for e in bench.trace.events[-30:]:
                print(f"    [{e.kind:9}] {e.label[:60]:60} {e.status}")
            print(); continue
        if msg == "/topology":
            t = bench.topology()
            for a in t["agents"]:
                print(f"    {a['id']:32} skills={len(a['skills']):2} → {', '.join(a['invokes']) or 'terminal'}")
            print(); continue

        turn = bench.send(msg)
        for e in turn.trace:
            if e["kind"] in ("handoff", "skill", "skill_end", "tool", "contract", "goal", "state", "error"):
                mark = {"fail": "✗", "warn": "!", "active": "▸"}.get(e["status"], "·")
                print(f"    {mark} [{e['kind']:9}] {e['label'][:58]}")
        print(f"\nbot › {turn.reply}\n")


def cmd_flow():
    from core.runtime import SpecialistAgent
    bench = SpecialistAgent()
    script = ["hello", "actual project implementation", "LJKX-1234",
              "continue", "continue", "continue"]
    for msg in script:
        turn = bench.send(msg)
        print("=" * 78)
        print(f"USER  {msg}   [steps {turn.steps}]")
        print(f"STACK {' ▸ '.join(turn.stack)}")
        for e in turn.trace:
            if e["kind"] in ("handoff", "skill", "skill_end", "tool", "contract", "goal", "state", "error"):
                mark = {"fail": "✗", "warn": "!", "active": "▸"}.get(e["status"], "·")
                print(f"   {mark} [{e['kind']:9}] {e['label'][:60]}")
        print(f"BOT   {(turn.reply or '')[:150]}")
    print("\n" + "=" * 78)
    print("FINAL JOURNEY STATE")
    for line in bench.state.summary_lines():
        print("   ", line)
    print("\nOPEN ITEMS")
    for i in bench.state.open_items:
        print(f"    - {i.what} (blocks: {i.blocks})")
    print("\nEVENT COUNTS:", bench.trace.counts())


def cmd_check():
    from config.settings import settings
    from core.contracts import ContractEngine
    from core.loader import load_package
    from llm.registry import get_client

    ok = True
    pkg = load_package()
    problems = pkg.validate()
    print(f"package   {settings.package_path}")
    print(f"          {len(pkg.agents)} agents · {len(pkg.skills)} skills · "
          f"{len(pkg.business_rules)} rules · {len(pkg.tools)} tools")
    if problems:
        ok = False
        print("          INTEGRITY PROBLEMS:")
        for p in problems:
            print(f"            - {p}")
    else:
        print("          integrity: clean")

    print(f"\ncontracts {'enabled/' + settings.contract_mode if settings.enforce_contracts else 'disabled'}")
    for point, names in ContractEngine.registered().items():
        print(f"          {point:11} {', '.join(names)}")

    print(f"\nllm       provider={settings.llm_provider} model={settings.llm_model}")
    try:
        h = get_client().health()
        print(f"          status={h.get('status')} {h.get('detail','') or h.get('note','')}")
        if h.get("status") == "error":
            ok = False
    except Exception as exc:
        ok = False
        print(f"          could not initialise: {exc}")

    print("\n" + ("ALL CHECKS PASSED" if ok else "CHECKS FAILED — see above"))
    return 0 if ok else 1


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Onboard360AI agent test bench")
    p.add_argument("--cli", action="store_true", help="terminal session")
    p.add_argument("--flow", action="store_true", help="run the scripted end-to-end flow")
    p.add_argument("--check", action="store_true", help="validate package, contracts and LLM")
    args = p.parse_args()
    if args.check:
        sys.exit(cmd_check())
    elif args.flow:
        cmd_flow()
    elif args.cli:
        cmd_cli()
    else:
        cmd_serve()
