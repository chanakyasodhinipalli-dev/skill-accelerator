# Migration Map

Every component of the original decomposed package, and where it lives now.

## Agents

| Was | Now |
|---|---|
| Platform Specialist Agent | **The only agent** — `agent/platform-specialist-agent.json` |
| `onboard360ai` (master agent) | **The only skill** — `skill/onboard360ai.json` |
| `poc-assistance` (sub-agent) | **Use-case playbook reference** — `references/01-00_usecase-poc-assistance.md` |
| `intake-verification` (sub-agent) | **Use-case playbook reference** — `references/02-00_usecase-intake-verification.md` |
| `foundational-setup` (sub-agent) | **Use-case playbook reference** — `references/03-00_usecase-foundational-setup.md` |
| `volume-assessment` (sub-agent) | **Use-case playbook reference** — `references/04-00_usecase-volume-assessment.md` |
| `load-testing-spli` (sub-agent) | **Use-case playbook reference** — `references/05-00_usecase-load-testing-spli.md` |
| `apigee-subscription` (sub-agent) | **Use-case playbook reference** — `references/06-00_usecase-apigee-subscription.md` |
| `postman-collection-generation` (sub-agent) | **Use-case playbook reference** — `references/07-00_usecase-postman-collection-generation.md` |
| `environment-progression` (sub-agent) | **Use-case playbook reference** — `references/08-00_usecase-environment-progression.md` |

## Skills

| Was (skill) | Now |
|---|---|
| `welcome-scope-framing` | folded into the skill's key instructions |
| `eligibility-determination` | folded into the skill's key instructions |
| `routing-logic` | folded into the skill's key instructions |
| `onboarding-journey-state-tracker` | folded into the skill's key instructions |
| `intake-free-activity-catalogue` | `references/01-01_intake-free-activity-catalogue.md` |
| `apigee-innovation-api-connectivity` | `references/01-02_apigee-innovation-api-connectivity.md` |
| `document-ingestion-poc` | `references/01-03_document-ingestion-poc.md` |
| `search-read-documents` | `references/01-04_search-read-documents.md` |
| `icmp-ui-access-guidance` | `references/01-05_icmp-ui-access-guidance.md` |
| `documentation-pointers` | `references/01-06_documentation-pointers.md` |
| `ljkx-key-format-validation` | `references/02-01_ljkx-key-format-validation.md` |
| `duplicate-intake-prevention` | `references/02-02_duplicate-intake-prevention.md` |
| `ecm-intake-creation-walkthrough` | `references/02-03_ecm-intake-creation-walkthrough.md` |
| `intake-summarisation-scope-interpretation` | `references/02-04_intake-summarisation-scope-interpretation.md` |
| `scrum-team-project-key-resolution` | `references/02-05_scrum-team-project-key-resolution.md` |
| `unresolved-unlinked-field-handling` | `references/02-06_unresolved-unlinked-field-handling.md` |
| `icmp-foundations` | `references/03-01_icmp-foundations.md` |
| `icmp-capabilities-catalogue` | `references/03-02_icmp-capabilities-catalogue.md` |
| `repository-support` | `references/03-03_repository-support.md` |
| `repo-icmp-filenet` | `references/03-04_repo-icmp-filenet.md` |
| `repo-documentum` | `references/03-05_repo-documentum.md` |
| `repo-dms` | `references/03-06_repo-dms.md` |
| `repo-mars` | `references/03-07_repo-mars.md` |
| `repo-legacy` | `references/03-08_repo-legacy.md` |
| `marketplace-access` | `references/03-09_marketplace-access.md` |
| `service-account-provisioning` | `references/03-10_service-account-provisioning.md` |
| `sa-qaent` | `references/03-11_sa-qaent.md` |
| `sa-adent` | `references/03-12_sa-adent.md` |
| `user-access-provisioning` | `references/03-13_user-access-provisioning.md` |
| `ua-qaent` | `references/03-14_ua-qaent.md` |
| `ua-adent` | `references/03-15_ua-adent.md` |
| `art-aims-routing-boundary` | `references/03-16_art-aims-routing-boundary.md` |
| `bam-lookup` | `references/03-17_bam-lookup.md` |
| `venafi-certificates` | `references/03-18_venafi-certificates.md` |
| `ownership-support-assessment` | `references/03-19_ownership-support-assessment.md` |
| `volume-rationale-stakes` | `references/04-01_volume-rationale-stakes.md` |
| `per-operation-volume-collection` | `references/04-02_per-operation-volume-collection.md` |
| `special-day-growth-profiling` | `references/04-03_special-day-growth-profiling.md` |
| `ivaas-icmp-ui-user-profiling` | `references/04-04_ivaas-icmp-ui-user-profiling.md` |
| `estimation-buffer-guidance` | `references/04-05_estimation-buffer-guidance.md` |
| `capacity-planning-ticket-creation` | `references/04-06_capacity-planning-ticket-creation.md` |
| `test-case-derivation` | `references/05-01_test-case-derivation.md` |
| `load-test-template-mapping` | `references/05-02_load-test-template-mapping.md` |
| `spli-requirement-package` | `references/05-03_spli-requirement-package.md` |
| `spli-ticket-creation` | `references/05-04_spli-ticket-creation.md` |
| `consumer-application-creation` | `references/06-01_consumer-application-creation.md` |
| `app-identifier-validation` | `references/06-02_app-identifier-validation.md` |
| `environment-service-account-mapping` | `references/06-03_environment-service-account-mapping.md` |
| `scope-selection-permissions` | `references/06-04_scope-selection-permissions.md` |
| `subscription-tier-identification` | `references/06-05_subscription-tier-identification.md` |
| `subscription-form-submission` | `references/06-06_subscription-form-submission.md` |
| `approval-evidence-package` | `references/06-07_approval-evidence-package.md` |
| `scope-driven-collection-build` | `references/07-01_scope-driven-collection-build.md` |
| `environment-variable-seeding` | `references/07-02_environment-variable-seeding.md` |
| `download-delivery` | `references/07-03_download-delivery.md` |
| `progression-gating-rules` | `references/08-01_progression-gating-rules.md` |
| `per-environment-signoff-capture` | `references/08-02_per-environment-signoff-capture.md` |
| `scrum-team-dependency-check` | `references/08-03_scrum-team-dependency-check.md` |
| `volume-change-obligation-notice` | `references/08-04_volume-change-obligation-notice.md` |

## Shared registers

| Was | Now |
|---|---|
| `_shared/business-rules.json` | `references/00-01_business-rules.md` (+ retained as JSON) |
| scattered reference values | `references/00-02_reference-data.md` |
| `_shared/tools.json` | `references/00-03_tools-and-phases.md` (+ retained as JSON) |
| `_shared/glossary.json` | `references/00-04_glossary.md` (+ retained as JSON) |
| journey state (runtime-held) | `references/00-05_journey-state.md` |