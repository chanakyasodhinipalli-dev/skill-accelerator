# Onboard360AI — ICMP Partner Onboarding · MVP 1
## One agent. One skill. Everything else is a reference.

Rebuilt to the iDocs Canvas structure:

- **Platform Specialist Agent** is the **only agent**.
- **Onboard360AI** is the **only skill**.
- All detail is attached to that one skill as **references**.

| | Original | Now |
|---|---:|---:|
| Agents | 9 | **1** (platform-owned) |
| Sub-agents | 8 | **0** |
| Skills | 59 | **1** |
| References | 69 source pages | **137** |

Nothing was dropped — see `MIGRATION_MAP.md`.

## Reference set (137)

| Prefix | Kind | Count | Purpose |
|---|---|---:|---|
| `00-*` | Core | 5 | Always applicable: business rules, reference data, tools and phases, glossary, journey state |
| `NN-00` | Use-case playbook | 8 | The use case: goal, key instructions, procedure index |
| `NN-mm` | Procedure | 55 | Detail for one step, read before performing it |
| — | Source documentation | 69 | Confluence / KB pages (URL placeholders) |

The numeric prefix carries the structure, so a flat upload still reads in order.

## Structure

```
Onboard360AI_MVP1/
├── _manifest.json
├── MIGRATION_MAP.md
├── agent/
│   ├── platform-specialist-agent.json   the only agent + recommended contract bindings
│   └── platform-specialist-agent.md
├── skill/
│   ├── onboard360ai.json                THE skill — key instructions + reference register
│   ├── onboard360ai.md                  review / copy-paste copy
│   └── references/                      all 68 reference files
└── _shared/                             registers retained as JSON
```

## Use cases

| # | Use case | Branch | Playbook | Procedures |
|---|---|---|---|---:|
| 1 | POC Assistance | POC | `01-00_usecase-poc-assistance.md` | 6 |
| 2 | Intake Verification | IMPLEMENTATION | `02-00_usecase-intake-verification.md` | 6 |
| 3 | Foundational Setup | BOTH | `03-00_usecase-foundational-setup.md` | 19 |
| 4 | Volume Assessment | IMPLEMENTATION | `04-00_usecase-volume-assessment.md` | 6 |
| 5 | Load Testing (SPLI) | IMPLEMENTATION | `05-00_usecase-load-testing-spli.md` | 4 |
| 6 | Apigee Subscription | BOTH | `06-00_usecase-apigee-subscription.md` | 7 |
| 7 | Postman Collection Generation | BOTH | `07-00_usecase-postman-collection-generation.md` | 3 |
| 8 | Environment Progression | IMPLEMENTATION | `08-00_usecase-environment-progression.md` | 4 |

## Field mapping to the Agent Admin UI

**Skill** — there is only one.

| Admin UI field | Source |
|---|---|
| Skill name | `skill/onboard360ai.json` → `name` |
| Description | → `description` |
| System instruction | → `systemInstructions` (18,316 chars) |
| User instruction | → `userInstructions` |
| Reference materials (.md) | upload **every file** in `skill/references/` |
| Questions | → `questions[]` (74 merged, each tagged with its source) |

## How the skill is written

The skill holds **key instructions only**. Its shape:

```
Identity and position — a skill under the Platform Specialist Agent
Reference protocol    — what 00-/NN-00/NN-mm mean and when to read each
Use cases             — 8 playbooks with goal, procedure count and next step
Branch order          — POC and implementation paths, hard prerequisites
Your own behaviour    — welcome, eligibility, routing, journey state
Runtime disclosure    — BR-23, plus current integration state per system
Guardrails
MVP 1 scope           — BR-24
Tone
```

The reference protocol is explicit: **read the reference before performing its step; do not
work from memory of it, and do not paraphrase a procedure you have not read.** That instruction
is what makes the reference set load-bearing rather than decorative — worth testing early.

## Before importing

1. **Upload every reference.** The skill without its references has instructions but no detail.
2. **Confluence URLs** — source-page references are `<CONFLUENCE_URL:...>` placeholders.
3. **Scrum team → project key mapping page** must exist before ticket creation is enabled.
4. **Jira MCP binding** — `get_issue`, `get_project`, `create_issue`.

## Enforcement — the one thing to decide

With no sub-agents and no skill tree, the component boundaries that contracts fired at are gone.
`BR-01` (key format) and `BR-21` (never LJKX) are now instructions the model should follow rather
than gates it cannot pass.

`agent/platform-specialist-agent.json` carries a `recommendedContractBindings` block proposing
where to re-attach them on the Specialist Agent's own `pre_tool` and `post_model` interception
points. That keeps them as gates without reintroducing sub-agents.
