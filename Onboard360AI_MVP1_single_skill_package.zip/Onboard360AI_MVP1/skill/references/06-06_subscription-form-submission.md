# Subscription Form Completion & Submission

> **Use case 6:** Apigee Subscription
> **Reference id:** `subscription-form-submission` · **Phase:** P1
> **Business rules:** BR-05, BR-06

---

## Purpose

Answers the subscription question set, completes the form and submits it.

---

## Instructions

```
Walk the partner through the subscription form question by question. The form asks a number of questions and requires the partner to select the exact functions and APIs within scope — the selection itself is handled by the Scope Selection skill; this skill handles everything else on the form.

BEFORE SUBMITTING, VERIFY:
- Marketplace access present
- Consumer application exists, in NGDC if newly created
- App Identifier populated with the correct service account for the target environment
- Scope set selected and each scope maps to a declared capability
- Tier selected, not legacy, and any restricted-tier approval obtained
- Target environment permitted by Environment Progression
- BAM App ID and Remedy ID available

Any failure here is cheaper to fix now than after rejection. Walk the checklist explicitly rather than assuming.

SOURCE OF TRUTH: the marketplace documentation, which changes. At phase 2, read the current form guidance rather than reciting remembered fields.

There is currently no marketplace integration; the partner submits. In future the submission will be made directly.
```

---

## Ordered steps

1. Walk the form question by question.
2. Run the pre-submission checklist explicitly.
3. Confirm environment eligibility with Environment Progression.
4. Read the current marketplace form guidance rather than reciting from memory.
5. Record the submission reference.

---

## Business rules enforced here

- **BR-05** [Consumer app] Marketplace documentation is the source of truth; skills must reflect the currently published version
- **BR-06** [App Identifier] Mandatory for ICMP though the marketplace presents it as optional; must hold the service account and be populated before submission

---

## Source documentation

- **Apigee Subscription Form Guide** — `<CONFLUENCE_URL:APIGEE_SUBSCRIPTION_FORM_GUIDE>`

---

## Tools

- **Apigee API Marketplace** [PLANNED · P1 now, P3 target] — (future) list_apis, (future) create_subscription, (future) get_subscription_status

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
