# Use Case 6 — Apigee Subscription

> **Playbook reference** · branch: BOTH · phase: P1
> **Procedure references:** 7

---

## Goal — this use case is not complete until every line is true

1. Subscription created and approved for the target environment.
2. Consumer application created in NGDC, or an existing one correctly modified.
3. App Identifier populated with the correct service account before submission.
4. Correct scope set selected and understood as permissions, not metadata.
5. Correct, non-legacy tier selected on the basis of the declared volume profile.
6. Approval evidence package assembled and submitted.

---

## When this use case runs

Branch: **BOTH**. Next: **postman-collection-generation, environment-progression**.

---

## Key instructions

```
You are working the Apigee Subscription use case for ICMP partner onboarding. Your goal is a subscription created AND approved — submission alone does not satisfy the goal.

PREREQUISITES — verify before starting, do not assume
- Marketplace access. Required before subscribing to ICMP APIs. If absent, hand to Foundational Setup.
- Consumer application, created new or modified from an existing one in the Apigee marketplace.
- BAM App ID and Remedy ID. The Remedy ID threads through consumer application registration, ownership identification, access provisioning, subscription management and operational support.
- Service account for the target environment.
- Volume profile from Volume Assessment — required before tier identification. A tier recommendation without a volume profile is indefensible; do not produce one.

NGDC RULE
All NEW consumer applications must be created in NGDC (Next Generation Data Center). Existing and legacy applications sit in the Heritage data center; new applications must not go there. State this before the partner creates anything.

SOURCE OF TRUTH
Marketplace documentation is the source of truth and changes over time. Always reflect the currently published documentation rather than hardcoded steps. At phase 2, read the marketplace pages before answering rather than relying on cached wording.

APP IDENTIFIER — the rule partners get wrong most often
The marketplace presents App Identifier as OPTIONAL. For ICMP it is MANDATORY. It must hold the SERVICE ACCOUNT that will invoke the APIs, and must be populated correctly BEFORE the subscription is submitted for approval. Other applications may use a different convention for this field; ICMP does not. Say this explicitly every time.

ENVIRONMENT AND SERVICE ACCOUNT MAPPING
Innovation -> QAEnt service account (development, POC).
Non-Prod -> QAEnt service account (integration testing, UAT, load testing).
Production -> production service account.
ProdFix is a production replicate for ICMP-internal validation of code immediately before the production move. It is NOT open to partners; never offer it.
Service account names must encode the environment so they are identifiable at a glance.

SCOPE SELECTION — mandatory and consequential
Wrong, unauthorised or unapproved scope selection leads to rejected subscriptions. ICMP enforces security validation against the approved scope at runtime; a partner cannot select one scope and use another later.
Failure modes to state plainly: operation checks fail, API access denied, subscription approval rejected.
Explain the reason, not just the rule: SCOPES ARE NOT METADATA — THEY ARE PERMISSIONS GRANTED TO THE CONSUMER APPLICATION.

TIERS
Recommend on the basis of the declared volume profile. Legacy tiers must NOT be selected for ICMP even though they remain visible in the marketplace. Diamond, Emerald and Top Tier are RESTRICTED: they require special request, prior discussion and approval before use. If a partner's volume points at a restricted tier, say so and route them to the approval conversation rather than letting them select it.

APPROVAL EVIDENCE
Two screenshots are required: (1) subscription details showing the App Identifier field with the QAEnt or ADEnt App ID value; (2) selected scopes and the subscription configuration. Explain why: the onboarding and support partners granting approval have no visibility into these details themselves, so the screenshots are the only evidence available. The partner reviews them before submitting.

ENVIRONMENT GATING
Check with Environment Progression before allowing a subscription request in any environment. Without a dedicated scrum team, the partner may subscribe in Innovation only.
```

---

## Use-case questions

**AQ1** — sequential
- Prompt: Which environment are you subscribing for?
- Options: Innovation · Non-Prod · Production
- Capture: `targetEnvironment`

**AQ2** — sequential
- Prompt: Are you creating a new consumer application, or modifying an existing one?
- Options: New — will be created in NGDC · Existing — modifying
- Capture: `consumerAppMode`

**AQ3** — sequential
- Prompt: What is the service account that will invoke the APIs? This goes in the App Identifier field.
- Capture: `appIdentifierServiceAccount`

**AQ4** — sequential
- Prompt: Which ICMP APIs and functions do you need? These become your approved scopes and are enforced at runtime.
- Capture: `requestedScopes`

**AQ5** — conditional
- Prompt: Based on your declared volume I recommend the {tier} tier. Confirm, or tell me if you need a different tier.
- Options: Confirm · I need a different tier
- Condition: `volumeProfile present in journey state`
- Capture: `selectedTier`

**AQ6** — conditional
- Prompt: That is a restricted tier requiring special request, prior discussion and approval. Have you already had that discussion?
- Options: Yes — approved · No — not yet
- Condition: `selectedTier in [Diamond, Emerald, Top Tier]`
- Capture: `restrictedTierApproval`

**AQ7** — sequential
- Prompt: For approval, please attach two screenshots: (1) subscription details showing the App Identifier field with the QAEnt/ADEnt App ID value, (2) selected scopes and subscription configuration.
- Capture: `approvalEvidence`

---

## Procedure references for this use case

Read the reference before performing its step.

| Reference file | Procedure | Phase | Rules |
|---|---|---|---|
| `06-01_consumer-application-creation.md` | Consumer Application Creation / Modification | P1 | BR-04, BR-05 |
| `06-02_app-identifier-validation.md` | App Identifier Population & Validation | P1 | BR-06, BR-10 |
| `06-03_environment-service-account-mapping.md` | Environment ↔ Service Account Mapping | P2 | BR-10 |
| `06-04_scope-selection-permissions.md` | Scope Selection & Permission Explanation | P2 | BR-13 |
| `06-05_subscription-tier-identification.md` | Subscription Tier Identification | P2 | BR-14, BR-15 |
| `06-06_subscription-form-submission.md` | Subscription Form Completion & Submission | P1 | BR-05, BR-06 |
| `06-07_approval-evidence-package.md` | Approval Evidence Package | P1 | BR-16 |

---

## Business rules enforced in this use case

- **BR-04** [Consumer app] All new consumer applications must be created in NGDC, not the Heritage data center
- **BR-05** [Consumer app] Marketplace documentation is the source of truth; skills must reflect the currently published version
- **BR-06** [App Identifier] Mandatory for ICMP though the marketplace presents it as optional; must hold the service account and be populated before submission
- **BR-10** [Service accounts] Service account names must encode the environment (innovation / non-prod / prod)
- **BR-13** [Scope] Scope selection is mandatory. ICMP performs runtime security validation against the approved scope; a scope cannot be selected then exceeded.
- **BR-14** [Tiers] Legacy tiers must not be selected for ICMP even though they remain visible in the marketplace
- **BR-15** [Tiers] Diamond, Emerald and Top Tier are restricted and require special request, prior discussion and approval
- **BR-16** [Approval] Two screenshots required — App Identifier with the QAEnt/ADEnt App ID value, and selected scopes with subscription configuration

---

## Tools

- **Apigee API Marketplace** [PLANNED · P1 now, P3 target] — (future) list_apis, (future) create_subscription, (future) get_subscription_status
- **Knowledge Base / Confluence** [PHASED · P1 now, P2 target] — return_links, read_and_answer