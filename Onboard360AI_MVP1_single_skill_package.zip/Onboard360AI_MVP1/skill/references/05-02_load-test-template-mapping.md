# Load Test Template Mapping

> **Use case 5:** Load Testing (SPLI)
> **Reference id:** `load-test-template-mapping` · **Phase:** P2
> **Business rules:** —

---

## Purpose

Maps derived test cases into the load testing team's existing templates and defined use cases.

---

## Instructions

```
Map the derived cases into the load testing team's EXISTING templates and defined use cases. The team has a format; a well-reasoned test case in the wrong format still gets returned.

At phase 2, READ the template documentation and populate against the current version rather than a remembered structure — templates change and stale mappings cause rework.

DO NOT INVENT TEMPLATE FIELDS. If the template requires a field that cannot be derived from journey state or the knowledge base, list it as an open item on the ticket rather than filling it with a plausible value. A fabricated field is worse than a blank one because nobody knows to question it.

Where an existing defined use case matches a derived case, reference the use case rather than restating it. The load testing team's use case library exists to avoid re-specifying the same test.
```

---

## Ordered steps

1. Read the current template documentation.
2. Map each derived case into the template structure.
3. Reference existing defined use cases where they match.
4. List underivable required fields as open items.
5. Never fabricate a template field value.

---

## Source documentation

- **SPLI Load Test Template** — `<CONFLUENCE_URL:SPLI_LOAD_TEST_TEMPLATE>`
- **SPLI Defined Use Case Library** — `<CONFLUENCE_URL:SPLI_DEFINED_USE_CASE_LIBRARY>`

---

## Future implementation

Future implementation: integrate the load testing team's template and use case library directly so the mapping reads the live template definition rather than a documentation page.
