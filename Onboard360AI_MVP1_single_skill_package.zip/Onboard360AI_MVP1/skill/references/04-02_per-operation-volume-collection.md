# Per-Operation Volume Collection

> **Use case 4:** Volume Assessment
> **Reference id:** `per-operation-volume-collection` · **Phase:** P1
> **Business rules:** BR-19

---

## Purpose

Master skill collecting the volume profile separately for each operation rather than as a single aggregate.

---

## Instructions

```
Collect PER OPERATION, never as a single aggregate. An aggregate figure cannot be turned into test cases and hides the operation that will actually break.

OPERATIONS: ingestion, search, retrieval, and any other operation in the partner's capability set.

PER OPERATION, COLLECT:
- Document volume per hour
- Documents per request
- Document size — minimum, maximum, average (KB or MB)
- Pages per document — minimum, maximum, average
- Peak volume — hourly AND daily
- Concurrent users — upstream system application, or ICMP UI
- Traffic pattern — batch/periodic versus live/synchronous
- Monthly total volume

Work through one operation at a time and confirm the set back before moving to the next. A partner asked for twenty-four figures at once supplies poor ones.

Where a figure is derived rather than measured, record it as an estimate with its basis. Downstream, Load Testing marks estimate-derived test cases so the load testing team knows the confidence level.
```

---

## Ordered steps

1. Determine which operations are in scope from the capability set.
2. Collect the full field set for one operation at a time.
3. Confirm each operation's set back before moving on.
4. Record provenance — measured versus estimated — for every figure.
5. Assemble the complete volume profile into journey state.

---

## Business rules enforced here

- **BR-19** [Volume] Volume must be declared per operation; 'we do not know' is not accepted — an educated estimate plus a 20-30% buffer is required

---

## Source documentation

- **ICMP Volume Collection Template** — `<CONFLUENCE_URL:ICMP_VOLUME_COLLECTION_TEMPLATE>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
