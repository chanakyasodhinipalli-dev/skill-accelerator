# Duplicate Intake Prevention

> **Use case 2:** Intake Verification
> **Reference id:** `duplicate-intake-prevention` · **Phase:** P2
> **Business rules:** BR-02

---

## Purpose

Guides an unsure partner to verify no intake already exists before creating one.

---

## Instructions

```
Triggered when the partner does not know whether an intake exists.

State the reason first: duplicate onboarding requests cause real delay — they split the ICMP team's attention across two tickets, produce conflicting prioritisation, and often result in both being deprioritised while the duplication is resolved.

Instruct the partner to verify with, in this order: themselves (their own Jira), their team, and the ICMP team. Ask for the Jira intake number if the check finds one.

Only if the check finds nothing should the partner be routed into the ECM intake creation process. Do not shortcut to creation because the partner is impatient; the check takes minutes and the duplicate costs weeks.

At phase 3, offer to search Jira on the partner's behalf using the application system name rather than relying on their manual check.
```

---

## Ordered steps

1. State why duplicates are costly.
2. Instruct the partner to check their own Jira, then their team, then the ICMP team.
3. Capture the intake number if one is found.
4. Route to intake creation only when the check finds nothing.

---

## Questions

**DIQ1** — sequential
- Prompt: Have you checked with your team and the ICMP team whether an intake already exists?
- Options: Checked — none exists · Checked — found one · Not checked yet
- Capture: `duplicateCheckOutcome`

---

## Business rules enforced here

- **BR-02** [Intake] Partners unsure whether an intake exists must verify before creating one, to avoid duplicate onboarding requests

---

## Source documentation

- **ECM Intake Process** — `<CONFLUENCE_URL:ECM_INTAKE_PROCESS>`

---

## Tools

- **Jira MCP** [AVAILABLE · P3] — get_issue, get_project

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
