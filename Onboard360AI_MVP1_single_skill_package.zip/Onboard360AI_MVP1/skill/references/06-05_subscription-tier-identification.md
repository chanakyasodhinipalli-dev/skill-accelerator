# Subscription Tier Identification

> **Use case 6:** Apigee Subscription
> **Reference id:** `subscription-tier-identification` · **Phase:** P2
> **Business rules:** BR-14, BR-15

---

## Purpose

Recommends the volume-appropriate tier, excludes legacy tiers, and handles restricted tiers.

---

## Instructions

```
ICMP has volume-based tiers. The tier is RECOMMENDED from the declared volume profile.

HARD PREREQUISITE: the volume profile from Volume Assessment. Without it, a tier recommendation is indefensible — do not produce one. If the profile is absent, hand to Volume Assessment rather than guessing a tier.

LEGACY TIERS: must NOT be selected for ICMP, even though they remain visible in the Apigee marketplace. Their visibility is not permission. If a partner selects one, say plainly that it is not valid for ICMP and redirect.

RESTRICTED TIERS — Diamond, Emerald and Top Tier:
These require a SPECIAL REQUEST, PRIOR DISCUSSION and APPROVAL before use. They cannot simply be selected. If the partner's declared volume points at a restricted tier, say so, explain that it requires the approval conversation first, and route them into it rather than letting them select and be rejected.

PROCEDURE:
1. Read the volume profile.
2. Derive the appropriate tier from declared peaks and monthly totals — peaks matter more than averages.
3. If the derived tier is restricted, state that and route to the approval conversation.
4. If the partner requests a legacy tier, refuse and explain.
5. Record the selected tier and, for restricted tiers, the approval status.
```

---

## Ordered steps

1. Confirm the volume profile exists; if not, hand to Volume Assessment.
2. Derive the tier from declared peaks and monthly totals.
3. Refuse legacy tiers with an explanation.
4. For restricted tiers, route to the approval conversation before selection.
5. Record the tier and any restricted-tier approval status.

---

## Questions

**TQ1** — conditional
- Prompt: Based on your declared volume I recommend the {tier} tier. Confirm, or tell me if you believe a different tier applies.
- Options: Confirm · I need a different tier
- Condition: `volume profile present`
- Capture: `selectedTier`

**TQ2** — conditional
- Prompt: That is a restricted tier requiring special request, prior discussion and approval. Has that discussion already taken place?
- Options: Yes — approved · No — not yet
- Condition: `selectedTier in [Diamond, Emerald, Top Tier]`
- Capture: `restrictedTierApproval`

---

## Business rules enforced here

- **BR-14** [Tiers] Legacy tiers must not be selected for ICMP even though they remain visible in the marketplace
- **BR-15** [Tiers] Diamond, Emerald and Top Tier are restricted and require special request, prior discussion and approval

---

## Source documentation

- **ICMP Subscription Tiers** — `<CONFLUENCE_URL:ICMP_SUBSCRIPTION_TIERS>`
- **Restricted Tier Approval Process** — `<CONFLUENCE_URL:RESTRICTED_TIER_APPROVAL_PROCESS>`

---

## Tools

- **Apigee API Marketplace** [PLANNED · P1 now, P3 target] — (future) list_apis, (future) create_subscription, (future) get_subscription_status

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
