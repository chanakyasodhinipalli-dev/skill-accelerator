# ART / AIMS Routing Boundary

> **Use case 3:** Foundational Setup
> **Reference id:** `art-aims-routing-boundary` · **Phase:** P1
> **Business rules:** BR-08, BR-09

---

## Purpose

Determines authoritatively whether a given access request goes to ART or to AIMS. Invoked by every access-related skill.

---

## Instructions

```
This skill exists because sending a partner to the wrong access tool costs them a full request cycle, and the two tools are routinely conflated. Every access-related skill invokes this one rather than restating the rule.

THE BOUNDARY IS BY REQUEST TYPE, NOT BY ENVIRONMENT.

+---------------------------------------+---------------------+---------------------+
| Request type                          | ADEnt (production)  | QAEnt (non-prod)    |
+---------------------------------------+---------------------+---------------------+
| Service account creation              | ART                 | ART                 |
| Service account group membership      | ART                 | ART                 |
| Human user access                     | AIMS                | ART                 |
| Human user LDAP group access          | AIMS                | ART                 |
+---------------------------------------+---------------------+---------------------+

RULES IN WORDS:
1. ALL service accounts — creation and group addition — route through ART, in BOTH environments, without exception.
2. Human USER access routes through ART for QAEnt.
3. Human USER access to LDAP groups in ADEnt routes through AIMS. This is the only AIMS case.

DETERMINATION PROCEDURE — ask two questions and the answer follows:
Q1: Is the subject a service account or a human user?
    - Service account -> ART. Stop. The environment does not matter.
    - Human user -> continue to Q2.
Q2: Which environment?
    - QAEnt (Innovation or Non-Prod) -> ART.
    - ADEnt (Production) -> AIMS.

EDGE CASES:
- A human user needing access to a service account's credentials or ownership is a service-account-ownership request, not user access -> ART.
- A functional or shared mailbox account is a non-human account -> ART.
- A partner asking for "access to production" without specifying subject: ask Q1 before answering. Do not guess.

NEVER send a partner to both tools for the same request, and never leave the tool ambiguous. State the tool, the reason, and what they will need before they start.
```

---

## Ordered steps

1. Ask whether the subject is a service account or a human user.
2. If service account -> ART, regardless of environment. Stop.
3. If human user -> determine the environment.
4. QAEnt -> ART. ADEnt -> AIMS.
5. State the tool, the reason, and the prerequisites for that request.
6. Resolve edge cases (service account ownership, functional accounts) to ART.

---

## Questions

**RBQ1** — sequential
- Prompt: Is this access request for a service account or a human user?
- Options: Service account · Human user · Not sure
- Capture: `accessSubjectType`

**RBQ2** — conditional
- Prompt: Which environment does the user need access to?
- Options: Innovation (QAEnt) · Non-Prod (QAEnt) · Production (ADEnt)
- Condition: `RBQ1 == 'Human user'`
- Capture: `accessEnvironment`

**RBQ3** — conditional
- Prompt: Will a person log in with these credentials, or will an application authenticate with them?
- Options: A person logs in · An application authenticates
- Condition: `RBQ1 == 'Not sure'`
- Capture: `accessSubjectType`

---

## Business rules enforced here

- **BR-08** [Service accounts] All service account creation and group addition routes through ART, for both ADEnt and QAEnt
- **BR-09** [User access] ADEnt user access to LDAP groups routes through AIMS; QAEnt user access routes through ART

---

## Source documentation

- **ART Access Request Guide** — `<CONFLUENCE_URL:ART_ACCESS_REQUEST_GUIDE>`
- **AIMS LDAP Group Access Guide** — `<CONFLUENCE_URL:AIMS_LDAP_GROUP_ACCESS_GUIDE>`
- **ICMP Access Routing Matrix** — `<CONFLUENCE_URL:ICMP_ACCESS_ROUTING_MATRIX>`

---

## Tools

- **ART — Access Request Tool** [PLANNED · P1 now, P3 target] — (future) create_service_account_request, (future) add_group_membership, (future) create_user_access_request
- **AIMS — Access and Identity Management System** [PLANNED · P1 now, P3 target] — (future) request_ldap_group_access

---

## Future implementation

Future implementation: at phase 3, submit the request directly to the determined tool via its API and return the request reference to the partner, rather than instructing them to raise it themselves.
