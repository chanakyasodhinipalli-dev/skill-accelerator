# Estimation & Buffer Guidance

> **Use case 4:** Volume Assessment
> **Reference id:** `estimation-buffer-guidance` · **Phase:** P1
> **Business rules:** BR-19, BR-22

---

## Purpose

Drives an educated estimate plus buffer where the partner has no concrete figures.

---

## Instructions

```
"WE DON'T KNOW OUR VOLUME" IS NOT A TERMINAL ANSWER. Never accept it and move on. A blank produces no test case, and no test case produces an untested integration in production.

PROCEDURE:
1. Build an educated estimate. Anchor it on something: a comparable system already in production, the business projection for transaction counts, the number of upstream users or branches, the document count in the source system today, or the volume of the manual process being replaced.
2. ADD A 20-30% BUFFER on top of the estimate.
3. Confirm that load testing will be performed END TO END, not ICMP-only.

This applies EQUALLY to net-new businesses with no historical data. An estimate with a buffer is always preferable to a blank — it gives the load testing team something to test against and gives the partner a declared baseline to measure against.

RECORD IT AS AN ESTIMATE. Do not let an estimate be carried downstream as if it were measured. Load Testing marks estimate-derived test cases accordingly, and the partner should know their declared baseline is an estimate when the volume-change obligation is explained.

If the partner genuinely cannot anchor an estimate on anything, say plainly that ICMP will size conservatively and that the subscription may be tiered lower than they eventually need — which is itself an argument for producing a number.
```

---

## Ordered steps

1. Refuse to accept 'unknown' as final.
2. Anchor an estimate on a comparable system, business projection or source-system count.
3. Add a 20-30% buffer.
4. Confirm end-to-end load testing coverage.
5. Record the figure as an estimate with its basis and carry that provenance downstream.

---

## Questions

**EBQ1** — conditional
- Prompt: What can we base an estimate on — a comparable system, a business projection, or the volume of the process this replaces?
- Condition: `partner answers unknown to any volume field`
- Capture: `estimateBasis`

**EBQ2** — conditional
- Prompt: I'll add a 20-30% buffer on top of that estimate. Confirm?
- Options: Confirm 20% · Confirm 30% · Discuss
- Condition: `EBQ1 answered`
- Capture: `bufferApplied`

---

## Business rules enforced here

- **BR-19** [Volume] Volume must be declared per operation; 'we do not know' is not accepted — an educated estimate plus a 20-30% buffer is required
- **BR-22** [Volume] Load testing (SPLI) must be performed end to end, not ICMP-only

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
