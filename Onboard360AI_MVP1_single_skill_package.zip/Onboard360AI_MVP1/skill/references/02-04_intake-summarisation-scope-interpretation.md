# Intake Summarisation & Scope Interpretation

> **Use case 2:** Intake Verification
> **Reference id:** `intake-summarisation-scope-interpretation` · **Phase:** P3
> **Business rules:** —

---

## Purpose

Interprets the retrieved intake to identify the actual onboarding scope, prioritisation, priority, sprint and allocated scrum team.

---

## Instructions

```
This skill INTERPRETS the intake. It does not reformat it. A field-by-field dump is not a summary.

Produce the onboarding intake summary containing: intake number, summary, status, reporter, assignee, priority, description, and any unresolved element information.

Then interpret. You must know what an onboarding scope actually looks like and how to identify the real scope from the ticket text, which varies in structure and completeness between intakes. Identify:
- The actual onboarding scope — which ICMP capabilities, which repository, which environments, which operations
- Prioritisation status — whether the LOB point of contact has prioritised it
- Priority level as recorded
- Sprint number, where assigned
- ALLOCATED SCRUM TEAM — this is the single most consequential field, because it governs whether the partner can go beyond Innovation

These signals appear in different places across intakes: sometimes as structured fields, sometimes in the description, sometimes in linked issues or labels. Read all of them. Where a signal is absent, say it is absent rather than inferring it.

Distinguish clearly between what the intake states and what you inferred. A partner acting on an inferred scope will build the wrong thing.
```

---

## Ordered steps

1. Retrieve the issue via Jira MCP get_issue.
2. Produce the factual summary block.
3. Interpret the actual onboarding scope from all available fields, description and links.
4. Identify prioritisation, priority, sprint and allocated scrum team.
5. State explicitly which signals are absent.
6. Distinguish stated facts from inferences.

---

## Source documentation

- **ICMP Onboarding Scope Definition** — `<CONFLUENCE_URL:ICMP_ONBOARDING_SCOPE_DEFINITION>`
- **ECM Intake Field Reference** — `<CONFLUENCE_URL:ECM_INTAKE_FIELD_REFERENCE>`

---

## Tools

- **Jira MCP** [AVAILABLE · P3] — get_issue, get_project

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
