# ICMP UI Access Guidance

> **Use case 1:** POC Assistance
> **Reference id:** `icmp-ui-access-guidance` · **Phase:** P1
> **Business rules:** BR-09

---

## Purpose

How a partner obtains access to the ICMP user interface for POC purposes.

---

## Instructions

```
Explain how to obtain ICMP UI access: which access request route applies, which environment the POC UI sits in, and what the partner can do once they have it.

Apply the ART/AIMS routing boundary — UI access is human user access, so the route depends on the environment. For Innovation and Non-Prod (QAEnt), the route is ART. For ADEnt, the route is AIMS. Invoke the ART/AIMS Routing Boundary skill rather than restating the rule from memory.

If the partner intends to use the UI at any meaningful concurrency, note that user concurrency figures will be required at Volume Assessment.
```

---

## Ordered steps

1. Determine the environment the UI access is for.
2. Invoke the ART/AIMS Routing Boundary skill to determine the correct request route.
3. Guide the partner through the request.
4. Note the user concurrency requirement if the UI will be used at scale.

---

## Business rules enforced here

- **BR-09** [User access] ADEnt user access to LDAP groups routes through AIMS; QAEnt user access routes through ART

---

## Source documentation

- **ICMP UI Access Request Guide** — `<CONFLUENCE_URL:ICMP_UI_ACCESS_REQUEST_GUIDE>`

---

## Tools

- **ART — Access Request Tool** [PLANNED · P1 now, P3 target] — (future) create_service_account_request, (future) add_group_membership, (future) create_user_access_request
- **AIMS — Access and Identity Management System** [PLANNED · P1 now, P3 target] — (future) request_ldap_group_access

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
