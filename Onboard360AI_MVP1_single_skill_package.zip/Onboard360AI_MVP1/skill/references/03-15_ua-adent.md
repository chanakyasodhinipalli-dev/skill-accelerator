# ADEnt User Access (AIMS)

> **Use case 3:** Foundational Setup
> **Reference id:** `ua-adent` · **Phase:** P3
> **Business rules:** BR-09

---

## Purpose

Production user access to LDAP groups — requested through AIMS.

---

## Instructions

```
User access to LDAP groups in ADEnt (production) is requested through AIMS — Access and Identity Management System. This is the ONE case where the route is AIMS rather than ART.

The user applies for the access themselves in AIMS; it is not raised on their behalf the way a service account request is. Make that explicit, because a partner expecting to request access for their whole team through one ticket will be surprised.

Walk through the AIMS request: identifying the correct LDAP group from the ICMP-provided set, the business justification, and the approval path. Set expectations on turnaround.
```

---

## Ordered steps

1. Confirm the environment is ADEnt and the request is for a human user.
2. State that each user applies for their own access in AIMS.
3. Identify the correct LDAP group from the ICMP-provided set.
4. Walk through the AIMS request and approval path.
5. Set expectations on turnaround.

---

## Business rules enforced here

- **BR-09** [User access] ADEnt user access to LDAP groups routes through AIMS; QAEnt user access routes through ART

---

## Source documentation

- **AIMS LDAP Group Access Guide** — `<CONFLUENCE_URL:AIMS_LDAP_GROUP_ACCESS_GUIDE>`
- **ICMP ADEnt LDAP Groups** — `<CONFLUENCE_URL:ICMP_ADENT_LDAP_GROUPS>`

---

## Tools

- **AIMS — Access and Identity Management System** [PLANNED · P1 now, P3 target] — (future) request_ldap_group_access

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
