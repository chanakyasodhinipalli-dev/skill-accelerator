# SPLI Requirement Package

> **Use case 5:** Load Testing (SPLI)
> **Reference id:** `spli-requirement-package` · **Phase:** P2
> **Business rules:** BR-22

---

## Purpose

Assembles the complete package beyond the volume profile that the load testing team requires.

---

## Instructions

```
Assemble everything the load testing team needs beyond the volume figures.

INCLUDE:
- The derived and template-mapped test cases
- Capability set and repository, so the team knows which ICMP services are exercised
- Environment and service account for the test environment (Non-Prod uses the QAEnt service account)
- Certificate status where notification or streaming operations are in scope
- Approved API scope, so the test does not attempt calls the subscription forbids
- Test lead, executing team and target completion date
- Confirmation that testing is END TO END across the partner's upstream systems, not ICMP-only
- Ownership and support contacts from the Ownership & Support Assessment
- All open items with owners

STATE THE END-TO-END REQUIREMENT EXPLICITLY. A test exercising ICMP in isolation does not prove the integration, and a partner who tests only ICMP will discover their own upstream bottleneck in production.
```

---

## Ordered steps

1. Assemble test cases, capability set and repository.
2. Include environment, service account, certificate and approved scope details.
3. Capture test lead, executing team and target date.
4. Confirm and state the end-to-end testing requirement.
5. Attach ownership contacts and all open items.

---

## Business rules enforced here

- **BR-22** [Volume] Load testing (SPLI) must be performed end to end, not ICMP-only

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
