# Venafi Certificates

> **Use case 3:** Foundational Setup
> **Reference id:** `venafi-certificates` · **Phase:** P1
> **Business rules:** BR-11, BR-12

---

## Purpose

Obtaining application certificates for non-production and production, where the capability set requires them.

---

## Instructions

```
WHY CERTIFICATES: to establish trust between partner applications and ECM / ICMP services.

BUSINESS RULE — certificates are REQUIRED when the partner needs any of:
- Kafka notification subscriptions — applications connecting to Kafka topics to consume ICMP request notifications or document notifications
- ICMP streaming services — for example document staging or document retrieval
- Any API involving streaming

If none of these apply, say so explicitly and do NOT send the partner on an unnecessary Venafi request. Check the capability set captured by the Capabilities Catalogue skill before asking.

TWO SETS REQUIRED where applicable — one for non-production, one for production.

CERTIFICATE SUBJECTS:
NON-PROD:    CN = EREP, OU = TESTAPP, OU = EREP, OU = ECS, O = Wells Fargo, C = US
PRODUCTION:  CN = EREP, OU = APP, OU = EREP, OU = ECS, O = Wells Fargo, C = US

The ONLY differentiator is the second element: OU = TESTAPP for non-production, OU = APP for production. Everything else in the chain is identical.

THE FULL CERTIFICATE SUBJECT MUST BE RETAINED — no truncation. A truncated subject fails at request time and the failure is not obvious to the partner.

COLLECT BOTH IN A SINGLE PROMPT. Each accepts NOT AVAILABLE as a legitimate answer. NOT AVAILABLE is not a blocker — it becomes a tracked open item and the Venafi request becomes a downstream action, so the partner continues rather than stalling here.

There is currently no Venafi integration. Guidance is instruction-based; in future the request will be raised directly.
```

---

## Ordered steps

1. Check the captured capability set for notification or streaming requirements.
2. If none apply, state that certificates are not required and skip.
3. If required, explain why and present both certificate subjects.
4. Collect both non-prod and production certificate information in a single prompt.
5. Accept NOT AVAILABLE and record it as a tracked open item.
6. Guide the Venafi request where the partner needs to raise one.

---

## Questions

**VCQ1** — conditional
- Prompt: Please provide your application certificate information. The full certificate subject must be retained.

NON-PROD CERTIFICATE
Example:
CN = EREP,OU = TESTAPP,OU = EREP,OU = ECS,O = Wells Fargo,C = US
If unavailable: NOT AVAILABLE

PRODUCTION CERTIFICATE
Example:
CN = EREP,OU = APP,OU = EREP,OU = ECS,O = Wells Fargo,C = US
If unavailable: NOT AVAILABLE
- Condition: `capabilitySet includes notifications or streaming`
- Capture: `nonProdCertificateSubject, prodCertificateSubject`

---

## Business rules enforced here

- **BR-11** [Certificates] Required when the partner needs Kafka notification subscriptions, ICMP streaming services, or any streaming API
- **BR-12** [Certificates] Two sets required — non-prod and production. The full certificate subject must be retained.

---

## Source documentation

- **Venafi Certificate Request Guide** — `<CONFLUENCE_URL:VENAFI_CERTIFICATE_REQUEST_GUIDE>`
- **ICMP Kafka Notification Setup** — `<CONFLUENCE_URL:ICMP_KAFKA_NOTIFICATION_SETUP>`
- **ICMP Streaming Services Guide** — `<CONFLUENCE_URL:ICMP_STREAMING_SERVICES_GUIDE>`

---

## Tools

- **Venafi** [PLANNED · P1 now, P3 target] — (future) request_certificate, (future) get_certificate_status

---

## Future implementation

Future implementation: raise the Venafi certificate request directly via API, poll issuance status, and report the certificate back to the partner without them leaving the assistant.
