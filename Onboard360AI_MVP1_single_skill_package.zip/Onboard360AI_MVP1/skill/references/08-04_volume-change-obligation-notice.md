# Volume-Change Obligation Notice

> **Use case 8:** Environment Progression
> **Reference id:** `volume-change-obligation-notice` · **Phase:** P1
> **Business rules:** BR-21

---

## Purpose

Restates the ongoing obligation to raise a new intake when volume grows beyond the declared baseline.

---

## Instructions

```
Restate the volume-change obligation before production, so it is acknowledged at the point it becomes real rather than only mentioned during collection.

THE OBLIGATION:
If volume increases beyond what was previously submitted and approved, a NEW ICMP INTAKE IS REQUIRED — to the LJKX project, the same as the original onboarding intake — BEFORE that volume is enabled.

WHY: ICMP re-runs load testing with the additional volume layered on top of ALL EXISTING VOLUME across ALL OPERATIONS, to confirm the increase will not degrade the platform. The test is never partner-isolated, because the risk is cumulative.

THRESHOLD: an anticipated increase of roughly 5-10% over the declared baseline is enough to trigger the obligation. The exact trigger point scales with the partner's overall volume.

UNCERTAINTY DOES NOT EXEMPT THE PARTNER. If they do not know whether the increase is material enough to matter, they STILL CREATE THE INTAKE. ICMP evaluates and decides whether additional SPLI is required before enabling the volume. That judgement belongs to ICMP, not to the partner.

WHY THIS MATTERS AT THIS POINT: a partner who declared estimates upfront might otherwise treat those estimates as permanently sufficient. Make the ongoing obligation explicit while they are paying attention, and capture their acknowledgement.
```

---

## Ordered steps

1. State the obligation and the LJKX destination.
2. Explain why testing is cumulative rather than partner-isolated.
3. State the 5-10% threshold and that it scales with overall volume.
4. State that uncertainty does not exempt the partner.
5. Capture explicit acknowledgement before production sign-off.

---

## Questions

**VCQ1** — conditional
- Prompt: Do you acknowledge that any volume increase beyond your declared baseline requires a new LJKX intake before that volume is enabled?
- Options: Acknowledged · Explain this again
- Condition: `target environment == Production`
- Capture: `volumeObligationAcknowledged`

---

## Business rules enforced here

- **BR-21** [Volume] Anticipated growth of roughly 5-10% over the declared baseline requires a new LJKX intake before the volume is enabled; uncertainty does not exempt the partner

---

## Source documentation

- **ICMP Volume Change Process** — `<CONFLUENCE_URL:ICMP_VOLUME_CHANGE_PROCESS>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
