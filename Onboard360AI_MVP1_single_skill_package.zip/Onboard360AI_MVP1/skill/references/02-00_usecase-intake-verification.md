# Use Case 2 — Intake Verification

> **Playbook reference** · branch: IMPLEMENTATION · phase: P3
> **Procedure references:** 6

---

## Goal — this use case is not complete until every line is true

1. Valid LJKX intake confirmed, or partner routed into ECM intake creation.
2. Onboarding intake summary produced with the actual onboarding scope identified.
3. Allocated scrum team and that team's Jira project key resolved for downstream ticket creation.
4. No duplicate onboarding request created.

---

## When this use case runs

Branch: **IMPLEMENTATION**. Next: **foundational-setup**.

---

## Key instructions

```
You are working the Intake Verification use case for ICMP partner onboarding. Your goal is a confirmed, valid LJKX intake — or the partner correctly routed into creating one.

STEP 0 — DETERMINE INTAKE STATUS
Ask whether an intake has already been submitted. Three paths:
- NO INTAKE: refer to the ECM intake creation documentation and walk the partner through it. Do not attempt any Jira call.
- UNSURE: warn against creating duplicate onboarding requests. Instruct the partner to verify whether they, their team, or the ICMP team has already submitted one. Ask for the Jira intake number. If none exists after checking, route into the new ECM intake process.
- HAS INTAKE: ask for the intake number and proceed to step 1.

STEP 1 — VALIDATE THE KEY FORMAT BEFORE ANY TOOL CALL
Rules: project key must be exactly LJKX; the key must contain a hyphen; there must be a numeric value after the hyphen.
VALID: LJKX-1234, LJKX-567, LJKX-1
INVALID: 1234 (no project key), ABZD1234 (wrong key, no hyphen), LJKX (no number), LJKX1234 (no hyphen), TEST-5678 (wrong project key)
If the key fails validation, explain which rule it broke and ask again. Do not call the tool with a malformed key.

STEP 2 — RETRIEVE
Call Jira MCP get_issue with the validated key.

STEP 3 — ON SUCCESS, SUMMARISE
Produce the onboarding intake summary containing: intake number, summary, status, reporter, assignee, priority, description, and any unresolved element information. Then invoke the intake summarisation skill to interpret the actual onboarding scope — this is interpretation, not reformatting. Identify prioritisation, priority, sprint number and allocated scrum team, all of which vary per intake.

STEP 4 — RESOLVE THE SCRUM TEAM PROJECT KEY
The Jira project key used for downstream ticket creation is NOT LJKX and is NOT fixed — it differs per scrum team. Invoke the Scrum Team Project Key Resolution skill to derive it from the intake issue. Record it in journey state. Volume Assessment and Load Testing both depend on it; without it neither can create its ticket.

STEP 5 — ON ERROR, DIAGNOSE
If get_issue fails, perform secondary validation: call Jira MCP get_project with the project key. If the project returns nothing, the likely causes are (a) the partner lacks access to that project, or (b) the project key is wrong. Report the diagnosis in plain language and tell the partner what to do about each cause. Never surface a raw error payload.

STEP 6 — CLOSE
Present the consolidated summary: intake details, interpreted scope, scrum team, resolved project key, and any unresolved or unlinked fields flagged for follow-up.
```

---

## Use-case questions

**IQ1** — sequential
- Prompt: Has an ECM onboarding intake already been submitted for this application system?
- Options: Yes — I have the Jira number · No — not yet · I'm not sure
- Capture: `intakeStatus`

**IQ2** — conditional
- Prompt: Please provide the Jira intake number (format: LJKX-1234).
- Condition: `IQ1 == 'Yes — I have the Jira number'`
- Capture: `intakeKey`

**IQ3** — conditional
- Prompt: Before we create anything: have you checked with your team and the ICMP team whether an intake already exists? Duplicate onboarding requests cause delay.
- Options: Checked — none exists · Checked — one exists and I have the number · Not checked yet
- Condition: `IQ1 == "I'm not sure"`
- Capture: `duplicateCheckOutcome`

**IQ4** — conditional
- Prompt: I'll walk you through creating a new ECM intake. Ready?
- Options: Yes · Send me the documentation instead
- Condition: `IQ1 == 'No — not yet'`
- Capture: `intakeCreationMode`

---

## Procedure references for this use case

Read the reference before performing its step.

| Reference file | Procedure | Phase | Rules |
|---|---|---|---|
| `02-01_ljkx-key-format-validation.md` | LJKX Key Format Validation | P1 | BR-01 |
| `02-02_duplicate-intake-prevention.md` | Duplicate Intake Prevention | P2 | BR-02 |
| `02-03_ecm-intake-creation-walkthrough.md` | ECM Intake Creation Walkthrough | P2 | — |
| `02-04_intake-summarisation-scope-interpretation.md` | Intake Summarisation & Scope Interpretation | P3 | — |
| `02-05_scrum-team-project-key-resolution.md` | Scrum Team Project Key Resolution | P3 | — |
| `02-06_unresolved-unlinked-field-handling.md` | Unresolved & Unlinked Field Handling | P3 | — |

---

## Business rules enforced in this use case

- **BR-01** [Intake] Jira intake key must be exactly LJKX, contain a hyphen, and have a numeric value after the hyphen
- **BR-02** [Intake] Partners unsure whether an intake exists must verify before creating one, to avoid duplicate onboarding requests

---

## Tools

- **Jira MCP** [AVAILABLE · P3] — get_issue, get_project
- **Knowledge Base / Confluence** [PHASED · P1 now, P2 target] — return_links, read_and_answer