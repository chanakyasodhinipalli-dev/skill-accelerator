# QAEnt Service Account Creation

> **Use case 3:** Foundational Setup
> **Reference id:** `sa-qaent` · **Phase:** P3
> **Business rules:** BR-08, BR-10

---

## Purpose

Non-production service account creation via ART, serving Innovation and Non-Prod.

---

## Instructions

```
The QAEnt service account serves BOTH Innovation and Non-Prod. Partners frequently assume they need one per environment; clarify that QAEnt covers both, but that the naming should still make the intended usage clear.

Creation routes through ART (Access Request Tool). Walk through the request fields, the BAM App ID and Remedy ID that must be supplied, and the approval path.

Once created, the account must be added to the ICMP-provided LDAP groups — also through ART.
```

---

## Ordered steps

1. Confirm QAEnt covers both Innovation and Non-Prod.
2. Apply the environment-encoding naming rule.
3. Walk through the ART service account request.
4. Supply BAM App ID and Remedy ID.
5. Request the ICMP-provided LDAP group memberships through ART.

---

## Business rules enforced here

- **BR-08** [Service accounts] All service account creation and group addition routes through ART, for both ADEnt and QAEnt
- **BR-10** [Service accounts] Service account names must encode the environment (innovation / non-prod / prod)

---

## Source documentation

- **ART Service Account Request Guide** — `<CONFLUENCE_URL:ART_SERVICE_ACCOUNT_REQUEST_GUIDE>`
- **QAEnt Naming Standards** — `<CONFLUENCE_URL:QAENT_NAMING_STANDARDS>`

---

## Tools

- **ART — Access Request Tool** [PLANNED · P1 now, P3 target] — (future) create_service_account_request, (future) add_group_membership, (future) create_user_access_request

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
