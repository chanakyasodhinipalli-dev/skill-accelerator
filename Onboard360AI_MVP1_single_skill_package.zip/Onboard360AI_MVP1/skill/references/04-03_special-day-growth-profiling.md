# Special-Day & Growth Profiling

> **Use case 4:** Volume Assessment
> **Reference id:** `special-day-growth-profiling` · **Phase:** P1
> **Business rules:** BR-19, BR-21

---

## Purpose

Captures recurring volume deviations and projected growth separately from the baseline.

---

## Instructions

```
Baseline figures are insufficient on their own. Capacity fails on the peaks, and the peaks are often predictable.

CAPTURE RECURRING DEVIATIONS. Prompt with concrete examples so the partner recognises their own pattern:
- First day or first week of the month at 20-30% over average
- Annual closing periods
- Quarter end, month end, statement runs, regulatory filing dates
- Any other cyclical spike specific to the business

For each, capture: when it occurs, how much above baseline, and which operations it affects. A spike that only affects ingestion has different implications from one that affects retrieval.

CAPTURE PROJECTED GROWTH separately: the anticipated increase over the next twelve months, and its basis (business projection, planned migration, onboarding of additional upstream systems).

Growth figures feed directly into the volume-change obligation. A partner who declares 30% anticipated growth here has effectively pre-declared it; one who declares none must raise a new intake when it materialises.
```

---

## Ordered steps

1. Prompt with concrete special-day examples.
2. For each deviation, capture timing, magnitude and affected operations.
3. Capture projected twelve-month growth and its basis.
4. Link declared growth to the volume-change obligation.

---

## Questions

**SGQ1** — sequential
- Prompt: Are there predictable periods when your volume exceeds average — for example the first week of the month, quarter end, or annual closing?
- Capture: `specialDayScenarios`

**SGQ2** — sequential
- Prompt: What volume growth do you anticipate over the next 12 months, and what is that based on?
- Capture: `projectedGrowth, growthBasis`

---

## Business rules enforced here

- **BR-19** [Volume] Volume must be declared per operation; 'we do not know' is not accepted — an educated estimate plus a 20-30% buffer is required
- **BR-21** [Volume] Anticipated growth of roughly 5-10% over the declared baseline requires a new LJKX intake before the volume is enabled; uncertainty does not exempt the partner

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
