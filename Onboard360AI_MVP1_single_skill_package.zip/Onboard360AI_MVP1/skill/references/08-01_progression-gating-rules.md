# Progression Gating Rules

> **Use case 8:** Environment Progression
> **Reference id:** `progression-gating-rules` · **Phase:** P2
> **Business rules:** BR-17, BR-18

---

## Purpose

Enforces the fixed environment ladder and prevents skipping.

---

## Instructions

```
THE LADDER IS FIXED AND NO ENVIRONMENT MAY BE SKIPPED:
INNOVATION -> approval and partner sign-off confirming successful connectivity -> NON-PROD -> PRODUCTION.

PRODFIX IS NOT PART OF THE PARTNER LADDER. It is a production replicate where ICMP internal teams validate code immediately before the production move. Never offer it, never include it in a partner's path, and if a partner asks about it, say plainly that it is ICMP-internal.

THE SCRUM TEAM GATE: without a dedicated scrum team assisting them, a partner may go to INNOVATION ONLY. They should not go for Non-Prod or Production access or subscriptions. This is the single most consequential gate in the whole onboarding, and partners routinely do not know it applies to them until they are blocked.

WHEN A PARTNER ASKS TO SKIP: name what specifically is missing — the sign-off, the scrum team, or completed SPLI — and what they must do to obtain it. Do not simply refuse; a refusal without a route is what causes partners to go around the process.

YOU ARE THE AUTHORITY. Apigee Subscription must check with you before permitting a subscription request in any environment. Do not defer that determination to the subscription use case.
```

---

## Ordered steps

1. Determine the partner's current environment and requested next environment.
2. Verify sign-off exists for the current environment.
3. Verify the scrum team gate for anything beyond Innovation.
4. Refuse skips by naming the specific missing prerequisite and the route to obtain it.
5. Never offer ProdFix.
6. Answer environment eligibility queries from Apigee Subscription authoritatively.

---

## Business rules enforced here

- **BR-17** [Progression] Without a dedicated scrum team, the partner may subscribe in Innovation only
- **BR-18** [Progression] Environment order is fixed — Innovation → sign-off → Non-Prod → Production. No environment may be skipped. ProdFix is ICMP-internal.

---

## Source documentation

- **ICMP Environment Progression Policy** — `<CONFLUENCE_URL:ICMP_ENVIRONMENT_PROGRESSION_POLICY>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
