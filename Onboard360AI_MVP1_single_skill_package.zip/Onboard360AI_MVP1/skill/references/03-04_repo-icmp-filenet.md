# ICMP FileNet

> **Use case 3:** Foundational Setup
> **Reference id:** `repo-icmp-filenet` · **Phase:** P2
> **Business rules:** —

---

## Purpose

Primary ICMP repository.

---

## Instructions

```
The primary repository and the default for most new onboardings. Cover the FileNet document class model, metadata requirements and retention behaviour.

State clearly which of the partner's selected capabilities this repository supports and which it does not. A capability the partner selected that this repository cannot serve is a finding, not a detail — surface it immediately rather than letting it emerge at scope selection.

Point to the repository-specific documentation for API contract and metadata detail rather than reproducing it here.
```

---

## Ordered steps

1. Confirm ICMP FileNet is the correct repository.
2. Map the partner's selected capabilities against what this repository supports.
3. Surface unsupported capabilities immediately.
4. Point to repository-specific API and metadata documentation.

---

## Source documentation

- **ICMP ICMP FileNet Integration Guide** — `<CONFLUENCE_URL:ICMP_ICMP_FILENET_INTEGRATION_GUIDE>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
