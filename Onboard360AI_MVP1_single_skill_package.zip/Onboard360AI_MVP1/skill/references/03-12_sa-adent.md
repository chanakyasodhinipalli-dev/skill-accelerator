# ADEnt Service Account Creation

> **Use case 3:** Foundational Setup
> **Reference id:** `sa-adent` · **Phase:** P3
> **Business rules:** BR-08, BR-10

---

## Purpose

Production service account creation via ART.

---

## Instructions

```
The ADEnt (production) service account is used for Production APIs. It is SEPARATE from the QAEnt account even though creation runs through the same tool.

Creation routes through ART. Note that ProdFix also uses the production service account, but ProdFix is ICMP-internal and not partner-facing — do not raise it with the partner.

Production service account requests carry a longer approval path than QAEnt. Set that expectation so the partner requests it early rather than discovering the lead time when they are ready to go live.

Group membership is also requested through ART, using the ICMP-provided group set.
```

---

## Ordered steps

1. Confirm the production account is separate from QAEnt.
2. Apply the environment-encoding naming rule.
3. Walk through the ART service account request.
4. Set expectations on the production approval lead time.
5. Request the ICMP-provided LDAP group memberships through ART.

---

## Business rules enforced here

- **BR-08** [Service accounts] All service account creation and group addition routes through ART, for both ADEnt and QAEnt
- **BR-10** [Service accounts] Service account names must encode the environment (innovation / non-prod / prod)

---

## Source documentation

- **ART Service Account Request Guide** — `<CONFLUENCE_URL:ART_SERVICE_ACCOUNT_REQUEST_GUIDE>`
- **ADEnt Naming Standards** — `<CONFLUENCE_URL:ADENT_NAMING_STANDARDS>`

---

## Tools

- **ART — Access Request Tool** [PLANNED · P1 now, P3 target] — (future) create_service_account_request, (future) add_group_membership, (future) create_user_access_request

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
