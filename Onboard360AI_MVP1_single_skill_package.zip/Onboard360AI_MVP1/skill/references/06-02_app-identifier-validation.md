# App Identifier Population & Validation

> **Use case 6:** Apigee Subscription
> **Reference id:** `app-identifier-validation` · **Phase:** P1
> **Business rules:** BR-06, BR-10

---

## Purpose

Ensures the App Identifier holds the correct service account before the subscription is submitted.

---

## Instructions

```
THIS IS THE RULE PARTNERS GET WRONG MOST OFTEN. State it explicitly every time, do not assume it has been read.

The API marketplace presents App Identifier as OPTIONAL. FOR ICMP IT IS MANDATORY.

The App Identifier must hold the SERVICE ACCOUNT that will invoke the ICMP APIs. It must be populated CORRECTLY BEFORE the subscription is submitted for approval — not corrected afterwards, because the approver is checking exactly this field against exactly this expectation.

Other applications may follow a different App Identifier convention. ICMP does not: for ICMP it is ALWAYS the service account being used.

VALIDATE before submission:
- Is the field populated at all?
- Does it hold a service account, not a personal account, not the application name, not the App ID?
- Does the service account match the TARGET ENVIRONMENT? Innovation and Non-Prod use the QAEnt service account; Production uses the production service account.
- Does the service account name encode its environment, per the naming rule?

If the partner supplies something that is not a service account, do not correct it silently — explain what the field expects and why, then re-ask.
```

---

## Ordered steps

1. State that App Identifier is mandatory for ICMP despite appearing optional.
2. Confirm the value is a service account, not a personal account or application name.
3. Confirm the service account matches the target environment.
4. Confirm the naming encodes the environment.
5. Re-ask with an explanation if the value is wrong; never correct silently.

---

## Questions

**AIQ1** — sequential
- Prompt: Which service account will invoke the ICMP APIs? This value goes in the App Identifier field.
- Capture: `appIdentifierServiceAccount`

---

## Business rules enforced here

- **BR-06** [App Identifier] Mandatory for ICMP though the marketplace presents it as optional; must hold the service account and be populated before submission
- **BR-10** [Service accounts] Service account names must encode the environment (innovation / non-prod / prod)

---

## Source documentation

- **Apigee Subscription Field Guide** — `<CONFLUENCE_URL:APIGEE_SUBSCRIPTION_FIELD_GUIDE>`
- **ICMP App Identifier Standard** — `<CONFLUENCE_URL:ICMP_APP_IDENTIFIER_STANDARD>`

---

## Tools

- **Apigee API Marketplace** [PLANNED · P1 now, P3 target] — (future) list_apis, (future) create_subscription, (future) get_subscription_status

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
