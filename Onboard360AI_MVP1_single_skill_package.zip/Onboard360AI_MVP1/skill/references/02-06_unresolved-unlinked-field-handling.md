# Unresolved & Unlinked Field Handling

> **Use case 2:** Intake Verification
> **Reference id:** `unresolved-unlinked-field-handling` · **Phase:** P3
> **Business rules:** —

---

## Purpose

Handles intake fields that are missing, incomplete or unlinked, and converts them into tracked open items.

---

## Instructions

```
Identify fields on the intake that are missing, incomplete, or reference something not linked. Common cases: no allocated scrum team; no LOB prioritisation; capability list absent or vague; target environments unstated; linked issues referenced in text but not actually linked; ownership contacts missing.

For each, do three things: state what is missing, state what it blocks downstream, and state who resolves it. "Scrum team not allocated" on its own is not actionable; "scrum team not allocated, which gates you to Innovation only until the LOB point of contact allocates one" is.

Convert each into a tracked open item in journey state with an owner. Do not let unresolved fields disappear into a summary paragraph the partner skims.

Do not block the whole flow on unresolved fields unless the field is a hard prerequisite for the immediate next step. Continue, carry the open item forward, and surface it again when it becomes blocking.
```

---

## Ordered steps

1. Scan the retrieved intake for missing, incomplete and unlinked fields.
2. For each, state what is missing, what it blocks, and who resolves it.
3. Record each as a tracked open item with an owner.
4. Continue the flow unless the field blocks the immediate next step.
5. Re-surface each open item when it becomes blocking.

---

## Tools

- **Jira MCP** [AVAILABLE · P3] — get_issue, get_project

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
