# Environment ↔ Service Account Mapping

> **Use case 6:** Apigee Subscription
> **Reference id:** `environment-service-account-mapping` · **Phase:** P2
> **Business rules:** BR-10

---

## Purpose

Maps the target environment to the correct service account and enforces the naming convention.

---

## Instructions

```
MAPPING:
- INNOVATION -> QAEnt service account. Used for development and POC purposes.
- NON-PROD -> QAEnt service account. Used for integration testing, user acceptance testing and load testing.
- PRODUCTION -> production service account.
- PRODFIX -> production service account, but PRODFIX IS NOT PARTNER-FACING. It is a production replicate where ICMP internal teams validate code immediately before the production move. Never offer it to a partner and never include it in a partner's progression path.

NAMING: the service account name must reflect the environment (innovation / non-prod / prod) so it is identifiable at a glance. Production accounts remain separate from innovation and non-prod accounts even though creation runs through the same tool (ART).

COMMON PARTNER MISCONCEPTION: because QAEnt covers both Innovation and Non-Prod, partners sometimes assume one account covers production too. It does not. Say so explicitly when the partner moves toward production.
```

---

## Ordered steps

1. Determine the target environment.
2. Map to QAEnt or the production service account.
3. Confirm the account name encodes the environment.
4. State explicitly that QAEnt does not cover production.
5. Never offer ProdFix to a partner.

---

## Business rules enforced here

- **BR-10** [Service accounts] Service account names must encode the environment (innovation / non-prod / prod)

---

## Source documentation

- **ICMP Environment Standards** — `<CONFLUENCE_URL:ICMP_ENVIRONMENT_STANDARDS>`
- **Service Account Naming Convention** — `<CONFLUENCE_URL:SERVICE_ACCOUNT_NAMING_CONVENTION>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
