# Capacity Planning Ticket Creation

> **Use case 4:** Volume Assessment
> **Reference id:** `capacity-planning-ticket-creation` · **Phase:** P3
> **Business rules:** BR-19, BR-21

---

## Purpose

Populates and raises the capacity planning ticket in the allocated scrum team's Jira project.

---

## Instructions

```
Raise the capacity planning ticket for the assigned ICMP scrum member working on the onboarding.

PROJECT KEY — the most important rule in this skill. The project key is NOT LJKX and is NOT fixed. It is the ALLOCATED SCRUM TEAM'S project key, resolved by the Scrum Team Project Key Resolution skill and held in journey state. If it is absent, hand back to Intake Verification. NEVER guess a project key and never default to LJKX: a ticket raised in the wrong project is invisible to the team that must action it, while the partner believes it was raised.

TICKET CONTENT:
- Link to the originating LJKX intake
- Application system name, LOB, BAM App ID and Remedy ID
- Capability set and repository
- Full per-operation volume profile, with each figure marked measured or estimated
- Special-day scenarios and projected growth
- IVaaS/UI user counts and concurrency where applicable
- Traffic pattern per operation
- Target environments and intended go-live timeline
- RESTATE THE VOLUME-CHANGE OBLIGATION in the ticket body so it is on the record, not only in conversation
- All open items with owners

PROCEDURE: call Jira MCP create_issue with the resolved project key. Read the created issue back with get_issue to confirm, then report the ticket key and URL to the partner. Do not report success unless the read-back confirms it.
```

---

## Ordered steps

1. Retrieve the resolved scrum team project key from journey state.
2. If absent, hand back to Intake Verification rather than guessing.
3. Assemble the full ticket payload including provenance for every figure.
4. Restate the volume-change obligation in the ticket body.
5. Call Jira MCP create_issue with the resolved project key.
6. Read back with get_issue to confirm.
7. Report the ticket key and URL to the partner.

---

## Business rules enforced here

- **BR-19** [Volume] Volume must be declared per operation; 'we do not know' is not accepted — an educated estimate plus a 20-30% buffer is required
- **BR-21** [Volume] Anticipated growth of roughly 5-10% over the declared baseline requires a new LJKX intake before the volume is enabled; uncertainty does not exempt the partner

---

## Source documentation

- **Capacity Planning Ticket Template** — `<CONFLUENCE_URL:CAPACITY_PLANNING_TICKET_TEMPLATE>`
- **Scrum Team to Jira Project Key Mapping** — `<CONFLUENCE_URL:SCRUM_TEAM_TO_JIRA_PROJECT_KEY_MAPPING>`

---

## Tools

- **Jira MCP** [AVAILABLE · P3] — create_issue, get_issue

---

## Future implementation

Future implementation: attach the generated volume profile as a structured artifact on the ticket and populate scrum-team-specific custom fields read from the project's field configuration.
