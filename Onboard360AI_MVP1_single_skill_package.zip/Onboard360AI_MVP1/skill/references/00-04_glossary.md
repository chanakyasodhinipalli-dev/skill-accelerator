# Glossary

> Core reference

| Term | Expansion | Role |
|---|---|---|
| **ICMP** | Imaging Content Management Platform | The platform partners onboard to |
| **iDocs Canvas** | — | Enterprise document intelligence platform hosting the agent architecture |
| **Tachyon SDK** | — | Enterprise-internal SDK the Platform Specialist Agent is built on |
| **SSAT** | Strategic Services & Advanced Technology | Team receiving an intake for non-POC engagements |
| **LJKX** | — | Jira project key for all ICMP onboarding and volume-change intakes |
| **Apigee** | — | Google Cloud enterprise API management platform; hosts the API marketplace |
| **BAM** | Business Application Management | Source of application name, Remedy ID and App ID |
| **Venafi** | — | Certificate management — issues application certificates |
| **ART** | Access Request Tool | Service account creation and group addition, both environments; QAEnt user access |
| **AIMS** | Access and Identity Management System | User access to LDAP groups in ADEnt |
| **ADEnt** | — | Production environment |
| **QAEnt** | — | Non-production / QA environment, covering Innovation and Non-Prod |
| **ProdFix** | — | Production replicate for ICMP-internal pre-production validation; not partner-facing |
| **NGDC** | Next Generation Data Center | Where all new consumer applications must be created |
| **Heritage DC** | — | Legacy data center; new applications must not be created there |
| **IVaaS** | ICMP Viewer as a Service | ICMP Viewer integration offered as a service; triggers user-concurrency collection |
| **SPLI** | System Performance Load Ingestion Testing | Load testing performed before production go-live; never SPLT |
| **MVP 1** | — | Current release scope; extensible with further skills and agents |
| **DAU** | — | Existing document population referenced in retention operations |
| **MARS** | — | One of the downstream repositories ICMP supports |
| **LOB** | Line of Business | Prioritisation and impact boundary |