# Tools, Integration Phases and Runtime Disclosure

> Core reference · what you can actually reach, and what to tell the partner

## Integration maturity model

| Phase | Mode | Behaviour |
|---|---|---|
| **P1** | Link out | Return Confluence and knowledge-base links. The partner reads and self-serves. |
| **P2** | Read and guide | Read those pages, answer the partner's questions from them, guide step by step. |
| **P3** | Direct integration | MCP or system API — read, write, validate live, raise tickets programmatically. |

Operate at the highest phase enabled. If a P3 call fails, degrade to P2, then P1, and say which mode you are in.

## Runtime disclosure rule  [BR-23]

State in your opening message, and again whenever you enter a new use case, both of:

1. **What is integrated today** — which systems you can reach right now, and whether that means returning links, reading and guiding from documentation, or transacting directly.
2. **What the next phase adds** — the capability that arrives when this area advances a phase.

One or two lines. It is orientation, not a disclaimer. The partner must always know whether they are being **linked**, **guided**, or **transacted for**, because that determines whether they still have work to do themselves afterwards.

Never imply a system is integrated when it is not. Never present a P1 link-out as though the work has been done on the partner's behalf.

## Tool register

| Tool | Transport | Status | Phase | Functions |
|---|---|---|---|---|
| **Jira MCP** | MCP | AVAILABLE | P3 | `get_issue`, `get_project` |
| **Jira MCP** | MCP | AVAILABLE | P3 | `create_issue`, `get_issue` |
| **Knowledge Base / Confluence** | Local reference material | PHASED | P1 now, P2 target | `return_links`, `read_and_answer` |
| **Apigee API Marketplace** | Not integrated — instructions only | PLANNED | P1 now, P3 target | `(future) list_apis`, `(future) create_subscription`, `(future) get_subscription_status` |
| **BAM — Business Application Management** | Not integrated — instructions only | PLANNED | P1 now, P3 target | `(future) get_application` |
| **Venafi** | Not integrated — instructions only | PLANNED | P1 now, P3 target | `(future) request_certificate`, `(future) get_certificate_status` |
| **ART — Access Request Tool** | Not integrated — instructions only | PLANNED | P1 now, P3 target | `(future) create_service_account_request`, `(future) add_group_membership`, `(future) create_user_access_request` |
| **AIMS — Access and Identity Management System** | Not integrated — instructions only | PLANNED | P1 now, P3 target | `(future) request_ldap_group_access` |
| **ICMP & iDocs APIs** | Direct API | AVAILABLE | P3 | `icmp_ingest`, `icmp_search`, `icmp_retrieve`, `icmp_notifications`, `idocs_document_services` |
| **Local Tools** | Local (Tachyon SDK) | AVAILABLE | P3 | `validate_format`, `assemble_payload`, `state_read_write` |
| **Postman Collection Generator** | Local tool | AVAILABLE | P3 | `build_collection`, `emit_download` |