# Approval Evidence Package

> **Use case 6:** Apigee Subscription
> **Reference id:** `approval-evidence-package` · **Phase:** P1
> **Business rules:** BR-16

---

## Purpose

Assembles the screenshot evidence required for subscription approval.

---

## Instructions

```
Subscription approval requires evidence the partner must supply, because the approvers cannot see it themselves.

TWO SCREENSHOTS REQUIRED:
1. Subscription details showing the APP IDENTIFIER FIELD with the QAEnt or ADEnt App ID value
2. SELECTED SCOPES and the subscription configuration

EXPLAIN WHY — partners resist screenshot requests until they understand the reason:
The onboarding and support partners who grant approval DO NOT HAVE THE ACCESS OR VISIBILITY to see these details on the partner's subscription. The screenshots are the only evidence available to them. Without both, approval will not be granted.

TELL THE PARTNER TO REVIEW THE SCREENSHOTS BEFORE SUBMITTING. They are checking their own work: is the App Identifier the right service account for the environment, and is the scope set the one they intended? An approver looking at a screenshot of a wrong value will reject it, costing a full cycle.

Approval is currently a manual process. Guidance is instruction-based; in future the approval status will be retrieved directly.
```

---

## Ordered steps

1. State both required screenshots precisely.
2. Explain that approvers have no visibility into these details themselves.
3. Instruct the partner to review both before submitting.
4. Confirm the App Identifier matches the target environment's service account.
5. Confirm the scope set matches what was intended.

---

## Questions

**AEQ1** — sequential
- Prompt: Please attach two screenshots: (1) subscription details showing the App Identifier field with the QAEnt/ADEnt App ID value, (2) selected scopes and subscription configuration.
- Capture: `approvalEvidence`

---

## Business rules enforced here

- **BR-16** [Approval] Two screenshots required — App Identifier with the QAEnt/ADEnt App ID value, and selected scopes with subscription configuration

---

## Source documentation

- **Subscription Approval Process** — `<CONFLUENCE_URL:SUBSCRIPTION_APPROVAL_PROCESS>`

---

## Future implementation

Future implementation: retrieve subscription details and scope configuration directly from Apigee and generate the evidence package automatically, removing the screenshot requirement entirely.
