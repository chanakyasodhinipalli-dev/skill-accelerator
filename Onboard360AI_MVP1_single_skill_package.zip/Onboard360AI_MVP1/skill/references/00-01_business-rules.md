# Business Rules Register

> Core reference · applies across every use case

| ID | Area | Rule | Enforced in |
|---|---|---|---|
| **BR-01** | Intake | Jira intake key must be exactly LJKX, contain a hyphen, and have a numeric value after the hyphen | intake-verification |
| **BR-02** | Intake | Partners unsure whether an intake exists must verify before creating one, to avoid duplicate onboarding requests | intake-verification |
| **BR-03** | POC | POC requires no intake, no LOB prioritisation and no scrum team; it is entirely self-service and Innovation-only | poc-assistance |
| **BR-04** | Consumer app | All new consumer applications must be created in NGDC, not the Heritage data center | apigee-subscription |
| **BR-05** | Consumer app | Marketplace documentation is the source of truth; skills must reflect the currently published version | apigee-subscription |
| **BR-06** | App Identifier | Mandatory for ICMP though the marketplace presents it as optional; must hold the service account and be populated before submission | apigee-subscription |
| **BR-07** | Service accounts | ICMP APIs are consumed by applications, not individuals — accounts must be non-human, non-expiring, dedicated and not tied to a user | foundational-setup |
| **BR-08** | Service accounts | All service account creation and group addition routes through ART, for both ADEnt and QAEnt | foundational-setup |
| **BR-09** | User access | ADEnt user access to LDAP groups routes through AIMS; QAEnt user access routes through ART | foundational-setup |
| **BR-10** | Service accounts | Service account names must encode the environment (innovation / non-prod / prod) | foundational-setup |
| **BR-11** | Certificates | Required when the partner needs Kafka notification subscriptions, ICMP streaming services, or any streaming API | foundational-setup |
| **BR-12** | Certificates | Two sets required — non-prod and production. The full certificate subject must be retained. | foundational-setup |
| **BR-13** | Scope | Scope selection is mandatory. ICMP performs runtime security validation against the approved scope; a scope cannot be selected then exceeded. | apigee-subscription |
| **BR-14** | Tiers | Legacy tiers must not be selected for ICMP even though they remain visible in the marketplace | apigee-subscription |
| **BR-15** | Tiers | Diamond, Emerald and Top Tier are restricted and require special request, prior discussion and approval | apigee-subscription |
| **BR-16** | Approval | Two screenshots required — App Identifier with the QAEnt/ADEnt App ID value, and selected scopes with subscription configuration | apigee-subscription |
| **BR-17** | Progression | Without a dedicated scrum team, the partner may subscribe in Innovation only | environment-progression |
| **BR-18** | Progression | Environment order is fixed — Innovation → sign-off → Non-Prod → Production. No environment may be skipped. ProdFix is ICMP-internal. | environment-progression |
| **BR-19** | Volume | Volume must be declared per operation; 'we do not know' is not accepted — an educated estimate plus a 20-30% buffer is required | volume-assessment |
| **BR-20** | Volume | Exceeding approved and declared volume allows the ICMP platform support team to disable the subscription | volume-assessment |
| **BR-21** | Volume | Anticipated growth of roughly 5-10% over the declared baseline requires a new LJKX intake before the volume is enabled; uncertainty does not exempt the partner | volume-assessment |
| **BR-22** | Volume | Load testing (SPLI) must be performed end to end, not ICMP-only | load-testing-spli |
| **BR-23** | Disclosure | Every agent and skill states in its opening message what is integrated today and what the next phase adds | all agents and skills |
| **BR-24** | Scope | MVP 1 is extensible; requests beyond current scope are named as not yet covered, with today's alternative given, rather than worked around | onboard360ai |