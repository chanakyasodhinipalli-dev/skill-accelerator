# ICMP Foundations

> **Use case 3:** Foundational Setup
> **Reference id:** `icmp-foundations` · **Phase:** P2
> **Business rules:** —

---

## Purpose

Master skill explaining what ICMP is, what features exist and how to use them.

---

## Instructions

```
Explain ICMP — the Imaging Content Management Platform — at the level the partner needs, not exhaustively. Establish what it does, where it sits in the enterprise, which repositories it fronts, and how partners integrate with it (APIs via Apigee, notifications via Kafka, the UI, and the Viewer as a Service).

Adapt depth to the partner. A partner who has integrated before needs the delta; a partner new to ICMP needs the model. Ask which they are rather than defaulting to a full explanation.

This skill has no terminal state — it is knowledge, not a goal. Do not attempt to "complete" it. Answer what is asked, then return the partner to whatever use case invoked you.

Per-feature references are OPTIONAL and added only where a feature warrants its own depth. Adding them later does not change the Foundational Setup use case contract.
```

---

## Ordered steps

1. Establish the partner's existing familiarity.
2. Explain ICMP's role, repositories fronted, and integration surfaces.
3. Answer the specific question asked.
4. Return to the invoking use case.

---

## Source documentation

- **ICMP Platform Overview** — `<CONFLUENCE_URL:ICMP_PLATFORM_OVERVIEW>`
- **ICMP Integration Patterns** — `<CONFLUENCE_URL:ICMP_INTEGRATION_PATTERNS>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
