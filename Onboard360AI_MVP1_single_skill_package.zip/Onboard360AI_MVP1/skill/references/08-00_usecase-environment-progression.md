# Use Case 8 — Environment Progression

> **Playbook reference** · branch: IMPLEMENTATION · phase: P2
> **Procedure references:** 4

---

## Goal — this use case is not complete until every line is true

1. Partner advanced through Innovation, Non-Prod and Production in order, with no environment skipped.
2. Sign-off captured for each environment before the next is unlocked.
3. Scrum team dependency determined and enforced.
4. Volume-change obligation acknowledged before production.

---

## When this use case runs

Branch: **IMPLEMENTATION**. Next: **apigee-subscription**.

---

## Key instructions

```
You are working the Environment Progression use case for ICMP partner onboarding. Your goal is the partner advanced through the ladder with sign-offs, in order.

THE LADDER — fixed, no skipping
Innovation -> approval and partner sign-off confirming successful connectivity -> Non-Prod -> Production.
ProdFix is NOT part of the partner ladder. It is a production replicate where ICMP internal teams validate code immediately before the production move. Never offer it to a partner.

SCRUM TEAM DEPENDENCY — the gate that governs everything
Without a dedicated scrum team assigned, the partner may subscribe in INNOVATION ONLY — not Non-Prod, not Production. Determine the scrum team allocation from the intake summary produced by Intake Verification. If no scrum team is allocated, say so plainly and explain what the partner must do to get one, rather than leaving them to discover the block at subscription time.

SIGN-OFF
Before unlocking the next environment, capture explicit partner sign-off that they have connected successfully in the current one. Sign-off is a statement about verified connectivity, not an intention. If the partner has not actually connected, do not record sign-off.

WHAT YOU GATE
Apigee Subscription must check with you before allowing a subscription request in any environment. You are the authority on what is unlocked; the subscription use case is not.

BEFORE PRODUCTION
Confirm that load testing (SPLI) is complete and that the partner has acknowledged the volume-change obligation: if volume grows beyond the declared baseline by roughly 5-10%, a new LJKX intake is required before that volume is enabled, and uncertainty does not exempt them.
```

---

## Use-case questions

**EQ1** — sequential
- Prompt: Which environment are you currently working in?
- Options: Innovation · Non-Prod · Production
- Capture: `currentEnvironment`

**EQ2** — sequential
- Prompt: Has a dedicated scrum team been allocated to your onboarding?
- Options: Yes · No · Not sure — check the intake
- Capture: `scrumTeamAllocated`

**EQ3** — conditional
- Prompt: Confirm that you have connected successfully in {currentEnvironment} and are signing off on it.
- Options: Confirmed — signing off · Not yet connected successfully
- Condition: `requesting progression to next environment`
- Capture: `signOff[{env}]`

**EQ4** — conditional
- Prompt: Before production: is SPLI load testing complete, and do you acknowledge that any volume increase beyond your declared baseline requires a new LJKX intake before it is enabled?
- Options: Both confirmed · SPLI not complete · Need to understand the volume obligation
- Condition: `target environment == Production`
- Capture: `productionReadiness`

---

## Procedure references for this use case

Read the reference before performing its step.

| Reference file | Procedure | Phase | Rules |
|---|---|---|---|
| `08-01_progression-gating-rules.md` | Progression Gating Rules | P2 | BR-17, BR-18 |
| `08-02_per-environment-signoff-capture.md` | Per-Environment Sign-Off Capture | P3 | BR-18 |
| `08-03_scrum-team-dependency-check.md` | Scrum Team Dependency Check | P3 | BR-17 |
| `08-04_volume-change-obligation-notice.md` | Volume-Change Obligation Notice | P1 | BR-21 |

---

## Business rules enforced in this use case

- **BR-17** [Progression] Without a dedicated scrum team, the partner may subscribe in Innovation only
- **BR-18** [Progression] Environment order is fixed — Innovation → sign-off → Non-Prod → Production. No environment may be skipped. ProdFix is ICMP-internal.
- **BR-21** [Volume] Anticipated growth of roughly 5-10% over the declared baseline requires a new LJKX intake before the volume is enabled; uncertainty does not exempt the partner

---

## Tools

- **Jira MCP** [AVAILABLE · P3] — get_issue, get_project
- **Knowledge Base / Confluence** [PHASED · P1 now, P2 target] — return_links, read_and_answer