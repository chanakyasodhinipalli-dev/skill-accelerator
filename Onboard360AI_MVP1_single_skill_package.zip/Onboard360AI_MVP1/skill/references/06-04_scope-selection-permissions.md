# Scope Selection & Permission Explanation

> **Use case 6:** Apigee Subscription
> **Reference id:** `scope-selection-permissions` · **Phase:** P2
> **Business rules:** BR-13

---

## Purpose

Drives scope selection and explains why scopes are permissions rather than metadata.

---

## Instructions

```
SCOPE SELECTION IS MANDATORY AND CONSEQUENTIAL.

Wrong, unauthorised or unapproved scope selection leads to rejected subscriptions. ICMP implements SECURITY VALIDATION against the approved scope at runtime. A partner cannot select one scope and then use a different one later.

FAILURE MODES — state these plainly:
- Operation checks may fail
- API access may be denied
- Subscription approval may be rejected

EXPLAIN THE REASON, NOT JUST THE RULE. The single most important sentence in this skill:
SCOPES ARE NOT SIMPLY METADATA. THEY REPRESENT PERMISSIONS GRANTED TO THE CONSUMER APPLICATION.

A partner who believes scopes are a form-filling exercise selects loosely and gets rejected, or selects narrowly and gets denied at runtime. A partner who understands scopes are permissions selects deliberately.

PROCEDURE:
1. Read the partner's capability set from journey state — the scope selection should follow from it, not be invented fresh.
2. Present the available scopes for their APIs and repository.
3. For each selected scope, confirm which capability it serves. A scope that serves no declared capability is either an error or an undeclared capability; resolve which.
4. For each declared capability, confirm a scope covers it. A capability with no scope will fail at runtime.
5. Record the requested scope set. It becomes the APPROVED scope set only after approval — Postman Collection Generation depends on the approved set, not the requested one.
```

---

## Ordered steps

1. Read the declared capability set from journey state.
2. Present the available scopes for the partner's APIs and repository.
3. Confirm each selected scope maps to a declared capability.
4. Confirm each declared capability is covered by a scope.
5. State the runtime enforcement rule and the three failure modes.
6. Record the requested scope set, distinct from the approved set.

---

## Questions

**SSQ1** — sequential
- Prompt: Which ICMP APIs and functions do you need? These become your approved scopes and are enforced at runtime.
- Capture: `requestedScopes`

---

## Business rules enforced here

- **BR-13** [Scope] Scope selection is mandatory. ICMP performs runtime security validation against the approved scope; a scope cannot be selected then exceeded.

---

## Source documentation

- **ICMP API Scope Reference** — `<CONFLUENCE_URL:ICMP_API_SCOPE_REFERENCE>`
- **Apigee Scope Selection Guide** — `<CONFLUENCE_URL:APIGEE_SCOPE_SELECTION_GUIDE>`

---

## Tools

- **Apigee API Marketplace** [PLANNED · P1 now, P3 target] — (future) list_apis, (future) create_subscription, (future) get_subscription_status

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
