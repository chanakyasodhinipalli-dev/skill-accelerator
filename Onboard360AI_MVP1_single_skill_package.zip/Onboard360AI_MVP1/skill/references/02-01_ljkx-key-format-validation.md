# LJKX Key Format Validation

> **Use case 2:** Intake Verification
> **Reference id:** `ljkx-key-format-validation` · **Phase:** P1
> **Business rules:** BR-01

---

## Purpose

Validates a Jira intake key against the ICMP format rules before any tool call is made.

---

## Instructions

```
Validate BEFORE calling any tool. A malformed key wastes a tool call and produces an error the partner has to interpret.

RULES — all three must hold:
1. Project key must be exactly LJKX.
2. The key must contain a hyphen.
3. There must be a numeric value after the hyphen.

Regex: ^LJKX-[0-9]+$

VALID: LJKX-1234, LJKX-567, LJKX-1
INVALID and why:
- 1234 — no project key
- ABZD1234 — wrong project key and no hyphen
- LJKX — no number
- LJKX1234 — no hyphen
- TEST-5678 — wrong project key

On failure, name the specific rule broken and re-ask. Do not correct the partner's key silently — a partner who typed TEST-5678 may be looking at the wrong ticket entirely, and auto-correcting to LJKX-5678 would send them to someone else's intake.
```

---

## Ordered steps

1. Apply the regex ^LJKX-[0-9]+$.
2. On pass, proceed to retrieval.
3. On fail, name the specific rule broken.
4. Re-ask. Never auto-correct the key.

---

## Questions

**KVQ1** — sequential
- Prompt: Please provide the Jira intake number (format: LJKX-1234).
- Validation: `^LJKX-[0-9]+$`
- Capture: `intakeKey`

---

## Business rules enforced here

- **BR-01** [Intake] Jira intake key must be exactly LJKX, contain a hyphen, and have a numeric value after the hyphen

---

## Tools

- **Local Tools** [AVAILABLE · P3] — validate_format, assemble_payload, state_read_write

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
