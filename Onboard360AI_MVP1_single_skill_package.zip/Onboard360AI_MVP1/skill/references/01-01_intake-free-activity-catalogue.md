# Intake-Free Activity Catalogue

> **Use case 1:** POC Assistance
> **Reference id:** `intake-free-activity-catalogue` · **Phase:** P1
> **Business rules:** BR-03

---

## Purpose

Master skill listing everything a partner may do in a POC without raising an intake.

---

## Instructions

```
Deliver the complete intake-free activity list in one response, not drip-fed.

ACTIVITIES AVAILABLE WITHOUT AN INTAKE:
- Connect to Innovation APIs via Apigee
- Ingest documents into ICMP
- Search documents
- Read and retrieve documents
- General API usage within the Innovation scope
- ICMP UI access (guidance on obtaining it)

STATE THE BOUNDARIES ALONGSIDE THE LIST — the list is misleading without them:
- Innovation environment only
- No intake to the ECM or SSAT team
- No LOB prioritisation
- No scrum team assigned
- Self-service only

For each activity the partner selects, invoke the matching reference and return its documentation pointers.

WHEN ASKED FOR SOMETHING NOT ON THE LIST: say plainly that it requires an intake, name what specifically triggers the requirement (Non-Prod or Production access, scrum team support, production volume), and offer to hand to Intake Verification.

FUTURE EXPANSION: each activity becomes its own skill invoked from here, giving per-activity depth without changing the POC Assistance use case contract. Author guidance so that expansion is additive.
```

---

## Ordered steps

1. Deliver the full activity list with boundaries in one response.
2. Invoke the matching reference for each selected activity.
3. Return documentation pointers per activity.
4. For out-of-scope requests, name the trigger and offer Intake Verification.

---

## Business rules enforced here

- **BR-03** [POC] POC requires no intake, no LOB prioritisation and no scrum team; it is entirely self-service and Innovation-only

---

## Source documentation

- **ICMP POC Guide** — `<CONFLUENCE_URL:ICMP_POC_GUIDE>`
- **ICMP Innovation Environment Overview** — `<CONFLUENCE_URL:ICMP_INNOVATION_ENVIRONMENT_OVERVIEW>`

---

## Tools

- **Knowledge Base / Confluence** [PHASED · P1 now, P2 target] — return_links, read_and_answer
- **Local Tools** [AVAILABLE · P3] — validate_format, assemble_payload, state_read_write

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
