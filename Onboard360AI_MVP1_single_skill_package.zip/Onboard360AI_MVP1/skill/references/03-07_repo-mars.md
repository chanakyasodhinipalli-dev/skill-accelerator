# MARS

> **Use case 3:** Foundational Setup
> **Reference id:** `repo-mars` · **Phase:** P2
> **Business rules:** —

---

## Purpose

Downstream repository fronted by ICMP.

---

## Instructions

```
Cover the MARS integration path, supported operations, and the constraints partners most often hit.

State clearly which of the partner's selected capabilities this repository supports and which it does not. A capability the partner selected that this repository cannot serve is a finding, not a detail — surface it immediately rather than letting it emerge at scope selection.

Point to the repository-specific documentation for API contract and metadata detail rather than reproducing it here.
```

---

## Ordered steps

1. Confirm MARS is the correct repository.
2. Map the partner's selected capabilities against what this repository supports.
3. Surface unsupported capabilities immediately.
4. Point to repository-specific API and metadata documentation.

---

## Source documentation

- **ICMP MARS Integration Guide** — `<CONFLUENCE_URL:ICMP_MARS_INTEGRATION_GUIDE>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
