# Test Case Derivation

> **Use case 5:** Load Testing (SPLI)
> **Reference id:** `test-case-derivation` · **Phase:** P2
> **Business rules:** —

---

## Purpose

Derives SPLI test cases from the declared volume profile, capability set and repository.

---

## Instructions

```
SPLI is System Performance Load Ingestion Testing. Derive test cases; do not transcribe volumes.

DERIVE AT MINIMUM:
- A STEADY-STATE case per operation at the declared average
- A PEAK case per operation at the declared hourly peak and daily peak
- A SPECIAL-DAY case for each declared recurring spike, at its declared magnitude
- A CONCURRENCY case where IVaaS or ICMP UI is in scope, at declared peak concurrency
- A SUSTAINED case reflecting the monthly total spread across the declared traffic pattern
- A GROWTH case at declared baseline plus projected growth, where growth is material

CONSIDER THE CAPABILITY SET AND REPOSITORY. Which ICMP services each operation exercises depends on both. An ingestion case against MARS exercises a different path from one against FileNet, and a notification-subscribing partner exercises Kafka as well as the API.

MARK ESTIMATE-DERIVED CASES. Where the underlying volume figure was an estimate rather than a measured value, mark the case accordingly so the load testing team knows the confidence level and can plan margin.

Where a required input is missing, list it as an open item on the case rather than inventing a figure.
```

---

## Ordered steps

1. Read the volume profile, capability set and repository from journey state.
2. Derive steady-state, peak, special-day, concurrency, sustained and growth cases.
3. Map each case to the ICMP services it exercises.
4. Mark estimate-derived cases with their confidence level.
5. List missing inputs as open items rather than inventing figures.

---

## Source documentation

- **SPLI Test Case Standards** — `<CONFLUENCE_URL:SPLI_TEST_CASE_STANDARDS>`
- **ICMP Service Path Reference** — `<CONFLUENCE_URL:ICMP_SERVICE_PATH_REFERENCE>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
