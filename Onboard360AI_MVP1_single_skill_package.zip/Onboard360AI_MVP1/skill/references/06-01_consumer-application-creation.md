# Consumer Application Creation / Modification

> **Use case 6:** Apigee Subscription
> **Reference id:** `consumer-application-creation` · **Phase:** P1
> **Business rules:** BR-04, BR-05

---

## Purpose

Creating a new consumer application in NGDC, or correctly modifying an existing one.

---

## Instructions

```
The partner either creates a NEW consumer application or modifies an EXISTING one in the Apigee marketplace. Establish which before giving any guidance — the paths differ.

NGDC RULE — state this BEFORE the partner creates anything:
ALL NEW consumer applications MUST be created in NGDC (Next Generation Data Center). Existing and legacy applications sit in the HERITAGE data center; new applications must NOT go there. A consumer application created in the wrong data center has to be recreated, and the subscription with it.

REQUIRED: the BAM App ID and Remedy ID. The Remedy ID threads through consumer application registration, application ownership identification, access provisioning, subscription management and operational support. If the partner does not have it, hand to BAM Lookup before proceeding.

SOURCE OF TRUTH: the marketplace documentation, which changes over time. At phase 2, read the current page rather than reciting a remembered procedure.
```

---

## Ordered steps

1. Establish whether this is a new or existing consumer application.
2. State the NGDC rule before any creation step.
3. Confirm BAM App ID and Remedy ID are available; hand to BAM Lookup if not.
4. Read the current marketplace documentation and guide from it.
5. Capture the consumer application identifier into journey state.

---

## Questions

**CAQ1** — sequential
- Prompt: Are you creating a new consumer application or modifying an existing one?
- Options: New — will be created in NGDC · Existing — modifying
- Capture: `consumerAppMode`

---

## Business rules enforced here

- **BR-04** [Consumer app] All new consumer applications must be created in NGDC, not the Heritage data center
- **BR-05** [Consumer app] Marketplace documentation is the source of truth; skills must reflect the currently published version

---

## Source documentation

- **Apigee Consumer Application Guide** — `<CONFLUENCE_URL:APIGEE_CONSUMER_APPLICATION_GUIDE>`
- **NGDC Application Standards** — `<CONFLUENCE_URL:NGDC_APPLICATION_STANDARDS>`

---

## Tools

- **Apigee API Marketplace** [PLANNED · P1 now, P3 target] — (future) list_apis, (future) create_subscription, (future) get_subscription_status

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
