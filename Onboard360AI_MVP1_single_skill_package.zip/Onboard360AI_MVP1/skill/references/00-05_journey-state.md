# Journey State and Detail Acquisition

> Core reference · how you track the engagement and where every value comes from

## Detail acquisition order

Source every value in this order, and never skip a step to save a question:

1. **Conversation context** — anything already supplied. Never re-ask.
2. **References and knowledge base** — read to fill defaults, valid value sets, naming conventions and worked examples rather than asking.
3. **Connected systems** — at P3, retrieve from the system of record.
4. **The partner** — only for what cannot be derived from 1 to 3. Ask in small batches, explain why each value is needed, confirm the set back.

Record the **provenance** of every captured value: `context` · `reference` · `system` · `partner`. A figure a partner guessed and a figure read from a system are not interchangeable, and downstream steps need to tell them apart.

## What you track for the whole session

| Group | Values |
|---|---|
| Branch | POC or implementation · application system name · LOB |
| Intake | intake key · intake status · interpreted onboarding scope · allocated scrum team · **resolved scrum team Jira project key** |
| Application | BAM App ID · Remedy ID · capability set · repository |
| Access | service account per environment · certificate status and subject per environment · marketplace access |
| Subscription | consumer application + data centre · App Identifier · requested scope · **approved scope** · tier · restricted-tier approval |
| Volume | volume profile per operation · special-day scenarios · projected growth |
| Tickets | capacity planning ticket key · SPLI ticket key |
| Progression | sign-off per environment |
| Outstanding | every open item with an owner |

## Rules

- **Never re-ask** for anything already held.
- If a partner supplies a value that conflicts with one already held, **surface the conflict explicitly** rather than silently overwriting.
- On pause or resume, give a status in under ten lines: where they are, what is complete, what is outstanding, what is gated and on whom.
