# Reference Data

> Core reference · the values partners get wrong most often

## 1. Jira project keys

| Purpose | Key |
|---|---|
| **Intakes** | `LJKX` — fixed. Format: exactly LJKX, a hyphen, then digits. Regex `^LJKX-\d+$` |
| **Ticket creation** | The **allocated scrum team's own project key**, resolved from the intake. **Never LJKX. Never guessed.** |

Valid: `LJKX-1234` · `LJKX-567` · `LJKX-1`
Invalid: `1234` (no key) · `ABZD1234` (wrong key, no hyphen) · `LJKX` (no number) · `LJKX1234` (no hyphen) · `TEST-5678` (wrong project key)

A ticket raised in the wrong project is invisible to the team that must action it, while the partner believes it was raised.

## 2. Environments and service accounts

| Environment | Purpose | Service account | Partner-facing |
|---|---|---|---|
| Innovation | Development, POC | QAEnt | Yes |
| Non-Prod | Integration testing, UAT, load testing | QAEnt | Yes |
| Production | Live | Production | Yes |
| ProdFix | Production replicate — ICMP-internal validation before the production move | Production | **No — never offer it** |

Service account names **must encode the environment** (innovation / non-prod / prod).

## 3. Progression ladder

`Innovation → sign-off → Non-Prod → sign-off → Production`

No environment may be skipped. **No allocated scrum team = Innovation only.**

## 4. Access routing — by request type, not environment

| Request type | ADEnt (production) | QAEnt (non-production) |
|---|---|---|
| Service account creation | **ART** | **ART** |
| Service account group membership | **ART** | **ART** |
| Human user access | **AIMS** | **ART** |
| Human user LDAP group access | **AIMS** | **ART** |

Two questions resolve it every time:
1. Service account or human user? → **service account = ART, stop.** Environment is irrelevant.
2. Which environment? → **QAEnt = ART. ADEnt = AIMS.**

Edge cases: service-account ownership requests → ART. Functional or shared mailbox accounts are non-human → ART.

## 5. Certificates

Required **only** when the capability set includes Kafka notification subscriptions, ICMP streaming services, or any streaming API.

| Environment | Certificate subject |
|---|---|
| Non-Prod | `CN = EREP, OU = TESTAPP, OU = EREP, OU = ECS, O = Wells Fargo, C = US` |
| Production | `CN = EREP, OU = APP, OU = EREP, OU = ECS, O = Wells Fargo, C = US` |

Only the second element differs. **The full subject must be retained — no truncation.** Collect both in one prompt. `NOT AVAILABLE` is an accepted answer and becomes an open item, not a hard stop.

## 6. Subscription tiers

Recommended from the declared volume profile — peaks matter more than averages.

- **Legacy tiers** must not be selected for ICMP even though they remain visible in the marketplace. Visibility is not permission.
- **Restricted tiers — Diamond, Emerald, Top Tier** — require special request, prior discussion and approval before use.

## 7. App Identifier

The marketplace presents it as **optional**. For ICMP it is **mandatory**. It must hold the **service account** that will invoke the APIs, populated correctly **before** submission. Other applications may use a different convention; ICMP does not.

## 8. Consumer applications

All **new** consumer applications must be created in **NGDC** (Next Generation Data Center). Existing and legacy applications sit in the Heritage data centre; new applications must not go there.

## 9. ICMP capabilities catalogue

Extensible — this is the base set.

| Group | Capabilities |
|---|---|
| Content | Ingestion / archival · search and retrieval · download · export |
| Notifications | Request · document · package subscriptions |
| Viewer | ICMP Viewer as a Service (IVaaS) |
| Records | Retention on new and DAU documents · legal hold apply · legal hold remove · retention event updates |

Downstream consequences to flag as the partner selects:
- Notifications or streaming → **certificates required**
- IVaaS or ICMP UI → **user concurrency figures required** at Volume Assessment
- Every capability → specific **scopes and LDAP groups**

## 10. Repositories

ICMP FileNet (primary) · Documentum · DMS · MARS · other legacy repositories.

API contracts, metadata models and retention behaviour differ by repository. Do not let a partner proceed on "not sure".

## 11. Approval evidence — two screenshots, always

1. Subscription details showing the **App Identifier** field with the QAEnt/ADEnt App ID value.
2. **Selected scopes** and the subscription configuration.

Why: the approvers have no visibility into these details themselves. The screenshots are the only evidence available to them.

## 12. Volume

Declared **per operation**, never in aggregate. "We don't know" is not accepted — build an educated estimate and add a **20–30% buffer**.

Exceeding approved and declared volume allows the ICMP platform support team to **disable the subscription**. Growth of roughly **5–10%** over the declared baseline requires a **new LJKX intake** before that volume is enabled. Uncertainty does not exempt the partner — ICMP decides whether additional SPLI is required, not the partner.

## 13. SPLI

**System Performance Load Ingestion Testing.** Performed **end to end** across the partner's own upstream systems, not ICMP-only.
