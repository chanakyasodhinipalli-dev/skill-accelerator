# Ownership & Support Assessment

> **Use case 3:** Foundational Setup
> **Reference id:** `ownership-support-assessment` · **Phase:** P2
> **Business rules:** —

---

## Purpose

Collects the organisational metadata around the partner application, reused across multiple downstream processes.

---

## Instructions

```
Collect the organisational record for the partner application. This is reused in several places, so collect it once, properly, and hold it in journey state.

FIELDS:
- Primary support team
- Escalation team
- Production support team
- Architect
- Project manager
- All application systems involved in the end-to-end flow
- Owner of the end-to-end business flow

CONSUMED BY: email notification triggers; the Production Release Transition page; and other approval and handoff points.

EXPLAIN WHY when the partner pushes back on the volume of contact detail: when ICMP needs to reach someone about a volume anomaly, a failed subscription or a production incident, these are the only routes available. An incomplete record means the wrong person is contacted, or nobody is.

Capture teams and roles, not only individuals — individuals move. Where the partner supplies a person, ask for the team as well.
```

---

## Ordered steps

1. Explain what the record is used for.
2. Collect all seven fields.
3. Capture team names alongside individuals.
4. Record incomplete fields as tracked open items.
5. Hold in journey state for reuse.

---

## Questions

**OSQ1** — sequential
- Prompt: Who is your primary support team?
- Capture: `primarySupportTeam`

**OSQ2** — sequential
- Prompt: Who is your escalation team?
- Capture: `escalationTeam`

**OSQ3** — sequential
- Prompt: Who is your production support team?
- Capture: `productionSupportTeam`

**OSQ4** — sequential
- Prompt: Who is the architect for this application?
- Capture: `architect`

**OSQ5** — sequential
- Prompt: Who is the project manager?
- Capture: `projectManager`

**OSQ6** — sequential
- Prompt: Which application systems are involved in the end-to-end flow?
- Capture: `applicationSystemsInFlow`

**OSQ7** — sequential
- Prompt: Who owns the end-to-end business flow?
- Capture: `businessFlowOwner`

---

## Source documentation

- **Production Release Transition Page Guide** — `<CONFLUENCE_URL:PRODUCTION_RELEASE_TRANSITION_PAGE_GUIDE>`
- **ICMP Support Model** — `<CONFLUENCE_URL:ICMP_SUPPORT_MODEL>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
