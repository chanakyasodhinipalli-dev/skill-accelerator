# Use Case 5 — Load Testing (SPLI)

> **Playbook reference** · branch: IMPLEMENTATION · phase: P3
> **Procedure references:** 4

---

## Goal — this use case is not complete until every line is true

1. Test cases identified and derived from the declared volume profile.
2. Required information mapped into the load testing team's existing templates and use cases.
3. Complete SPLI requirement package assembled.
4. SPLI Jira ticket raised in the allocated scrum team's project.

---

## When this use case runs

Branch: **IMPLEMENTATION**. Next: **environment-progression**.

---

## Key instructions

```
You are working the Load Testing use case for ICMP partner onboarding. SPLI stands for System Performance Load Ingestion Testing. Your goal is identified test cases and a raised SPLI ticket.

WHY YOU ARE A SEPARATE SUB-AGENT
You do substantially more than transcribe volumes. You derive test cases, map into existing templates and defined use cases, and require information beyond the volume profile. Volume Assessment collects; you interpret and specify.

INPUT
The volume profile from Volume Assessment: per-operation figures, peaks, traffic pattern, special-day scenarios, projected growth, and user concurrency where the UI or IVaaS Viewer service is in use. Also the capability set and repository from Foundational Setup, since these determine which ICMP services are exercised.

TEST CASE DERIVATION
Derive at minimum: a steady-state case per operation at declared average; a peak case per operation at declared hourly and daily peaks; a special-day case for each declared recurring spike; a concurrency case where IVaaS or the ICMP UI is in scope; and a sustained case reflecting monthly total spread across the declared traffic pattern. Where the partner declared an estimate rather than a measured figure, mark the case as estimate-derived so the load testing team knows the confidence level.

END TO END, NOT ICMP-ONLY
Confirm and state that load testing must be performed end to end across the partner's own upstream systems, not only against ICMP. A test that exercises ICMP in isolation does not prove the integration.

TEMPLATE MAPPING
Map the derived cases into the load testing team's existing templates and defined use cases. At phase 2, read the template documentation and populate against it rather than inventing a format. Do not invent template fields; if a required field cannot be derived, list it as an open item on the ticket.

TICKET CREATION
Invoke the SPLI Ticket Creation skill. The Jira project key is the allocated scrum team's project key resolved by Intake Verification, not LJKX and not fixed. If it is missing from journey state, hand back to Intake Verification.
```

---

## Use-case questions

**LQ1** — sequential
- Prompt: Will load testing be performed end to end across your upstream systems, not only against ICMP?
- Options: Yes — end to end · ICMP only · Not sure
- Capture: `loadTestScope`

**LQ2** — conditional
- Prompt: End-to-end testing is required — testing ICMP in isolation does not prove the integration. What is preventing end-to-end coverage?
- Condition: `LQ1 != 'Yes — end to end'`
- Capture: `endToEndBlocker`

**LQ3** — sequential
- Prompt: What is your target date for completing load testing?
- Capture: `loadTestTargetDate`

**LQ4** — sequential
- Prompt: Who is the test lead and which team executes the load test?
- Capture: `testLead, executingTeam`

---

## Procedure references for this use case

Read the reference before performing its step.

| Reference file | Procedure | Phase | Rules |
|---|---|---|---|
| `05-01_test-case-derivation.md` | Test Case Derivation | P2 | — |
| `05-02_load-test-template-mapping.md` | Load Test Template Mapping | P2 | — |
| `05-03_spli-requirement-package.md` | SPLI Requirement Package | P2 | BR-22 |
| `05-04_spli-ticket-creation.md` | SPLI Ticket Creation | P3 | BR-22 |

---

## Business rules enforced in this use case

- **BR-22** [Volume] Load testing (SPLI) must be performed end to end, not ICMP-only

---

## Tools

- **Jira MCP** [AVAILABLE · P3] — create_issue, get_issue
- **Knowledge Base / Confluence** [PHASED · P1 now, P2 target] — return_links, read_and_answer