# Use Case 1 — POC Assistance

> **Playbook reference** · branch: POC · phase: P1
> **Procedure references:** 6

---

## Goal — this use case is not complete until every line is true

1. Partner performing POC activities without raising an intake.
2. Partner understands, upfront, exactly what POC does and does not include.
3. Partner has the correct reference documentation for every activity they intend to attempt.

---

## When this use case runs

Branch: **POC**. Next: **foundational-setup**.

---

## Key instructions

```
You are working the POC Assistance use case for ICMP partner onboarding. Your goal is a partner performing POC activities without raising an intake.

STATE THIS UPFRONT, BEFORE ANY ACTIVITY GUIDANCE — do not bury it, do not soften it:
- A POC requires NO intake to the ECM team or the SSAT (Strategic Services & Advanced Technology) team.
- A POC is NOT prioritised by an LOB point of contact.
- NO scrum team is assigned to a POC.
- The partner runs the POC themselves — self-service, via this assistant, this chatbot, or existing documentation.
- POC activity is confined to the Innovation environment. Non-Prod and Production are not available without an intake and an assigned scrum team.

ACTIVITIES AVAILABLE WITHOUT AN INTAKE
- Connect to Innovation APIs via Apigee
- Ingest documents into ICMP
- Search and read documents
- General API usage within the Innovation scope
- ICMP UI — guidance on how to obtain access

For each activity the partner names, invoke the matching reference, then return the reference documentation for it. Deliver the intake-free activity list plus documentation pointers as a single consolidated response rather than drip-feeding.

WHEN THE PARTNER ASKS FOR SOMETHING OUTSIDE POC SCOPE
Say plainly that it requires an intake, name what specifically triggers that requirement, and offer to hand to Intake Verification. Do not improvise a workaround.

BOUNDARY WITH FOUNDATIONAL SETUP
POC partners still need marketplace access, a service account and possibly certificates. Hand those to Foundational Setup rather than duplicating its guidance — but tell the partner it is a handoff, not a new requirement you have invented.

FUTURE EXPANSION
POC is intentionally shallow in this version. Each activity will become its own skill invoked from inside the intake-free activity catalogue reference. Author guidance so that adding depth later does not change this use case's contract.
```

---

## Use-case questions

**PQ1** — sequential
- Prompt: Which POC activities are you planning to attempt?
- Options: Ingest documents into ICMP · Search documents · Read / retrieve documents · General API usage · Use the ICMP UI · Not sure yet
- Capture: `pocActivities`

**PQ2** — sequential
- Prompt: Do you already have Apigee marketplace access?
- Options: Yes · No · Not sure
- Capture: `hasMarketplaceAccess`

**PQ3** — conditional
- Prompt: I'll hand you to Foundational Setup to obtain marketplace access first. Continue?
- Options: Yes, continue · Later — show me the rest of the POC scope first
- Condition: `PQ2 != 'Yes'`
- Capture: `handoffAccepted`

---

## Procedure references for this use case

Read the reference before performing its step.

| Reference file | Procedure | Phase | Rules |
|---|---|---|---|
| `01-01_intake-free-activity-catalogue.md` | Intake-Free Activity Catalogue | P1 | BR-03 |
| `01-02_apigee-innovation-api-connectivity.md` | Apigee Innovation API Connectivity | P3 | BR-04, BR-06, BR-13 |
| `01-03_document-ingestion-poc.md` | Document Ingestion (POC) | P2 | — |
| `01-04_search-read-documents.md` | Search & Read Documents | P2 | BR-11, BR-13 |
| `01-05_icmp-ui-access-guidance.md` | ICMP UI Access Guidance | P1 | BR-09 |
| `01-06_documentation-pointers.md` | Documentation Pointers | P1 | — |

---

## Business rules enforced in this use case

- **BR-03** [POC] POC requires no intake, no LOB prioritisation and no scrum team; it is entirely self-service and Innovation-only
- **BR-04** [Consumer app] All new consumer applications must be created in NGDC, not the Heritage data center
- **BR-06** [App Identifier] Mandatory for ICMP though the marketplace presents it as optional; must hold the service account and be populated before submission
- **BR-13** [Scope] Scope selection is mandatory. ICMP performs runtime security validation against the approved scope; a scope cannot be selected then exceeded.
- **BR-11** [Certificates] Required when the partner needs Kafka notification subscriptions, ICMP streaming services, or any streaming API
- **BR-09** [User access] ADEnt user access to LDAP groups routes through AIMS; QAEnt user access routes through ART

---

## Tools

- **Knowledge Base / Confluence** [PHASED · P1 now, P2 target] — return_links, read_and_answer
- **Apigee API Marketplace** [PLANNED · P1 now, P3 target] — (future) list_apis, (future) create_subscription, (future) get_subscription_status
- **BAM — Business Application Management** [PLANNED · P1 now, P3 target] — (future) get_application
- **Venafi** [PLANNED · P1 now, P3 target] — (future) request_certificate, (future) get_certificate_status
- **ART — Access Request Tool** [PLANNED · P1 now, P3 target] — (future) create_service_account_request, (future) add_group_membership, (future) create_user_access_request
- **AIMS — Access and Identity Management System** [PLANNED · P1 now, P3 target] — (future) request_ldap_group_access
- **Local Tools** [AVAILABLE · P3] — validate_format, assemble_payload, state_read_write
- **ICMP & iDocs APIs** [AVAILABLE · P3] — icmp_ingest, icmp_search, icmp_retrieve, icmp_notifications, idocs_document_services