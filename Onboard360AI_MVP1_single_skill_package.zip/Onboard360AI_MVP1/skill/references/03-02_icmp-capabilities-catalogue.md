# ICMP Capabilities Catalogue

> **Use case 3:** Foundational Setup
> **Reference id:** `icmp-capabilities-catalogue` · **Phase:** P2
> **Business rules:** BR-11

---

## Purpose

Maintains the complete, current list of ICMP capabilities so partners can identify what they actually need.

---

## Instructions

```
Maintain and present the full capability list. The partner's selection from it drives scope selection, LDAP group membership, certificate requirements and volume collection — so an inaccurate selection propagates errors through the entire onboarding.

CONTENT OPERATIONS: document ingestion and archival; search and retrieval; document download; document export.
NOTIFICATION OPERATIONS: request notification subscription; document notification subscription; package notification subscription.
VIEWER: ICMP Viewer integration — ICMP Viewer as a Service (IVaaS).
RECORDS OPERATIONS: applying retention to new and DAU documents; legal hold application; legal hold removal; retention event updates.

The catalogue is EXTENSIBLE — this is the base set, not a closed list. If a partner names a capability not listed, do not deny it exists; check the documentation and, if it exists, record it as a catalogue gap.

FLAG THE DOWNSTREAM CONSEQUENCES as the partner selects:
- Notification or streaming capabilities -> certificates required (Venafi)
- IVaaS or UI -> user concurrency figures required at Volume Assessment
- Each capability -> specific scopes and LDAP groups
```

---

## Ordered steps

1. Present the full capability catalogue grouped by type.
2. Capture the partner's selection.
3. Flag downstream consequences for each selected capability.
4. Record catalogue gaps where a partner names something unlisted.

---

## Questions

**CCQ1** — sequential
- Prompt: Which ICMP capabilities does your application require?
- Options: Ingestion / archival · Search and retrieval · Download · Export · Request notifications · Document notifications · Package notifications · ICMP Viewer (IVaaS) · Retention (new and DAU) · Legal hold apply · Legal hold remove · Retention event updates · Something not listed
- Capture: `capabilitySet`

---

## Business rules enforced here

- **BR-11** [Certificates] Required when the partner needs Kafka notification subscriptions, ICMP streaming services, or any streaming API

---

## Source documentation

- **ICMP Capabilities Catalogue** — `<CONFLUENCE_URL:ICMP_CAPABILITIES_CATALOGUE>`
- **ICMP Retention and Legal Hold Guide** — `<CONFLUENCE_URL:ICMP_RETENTION_AND_LEGAL_HOLD_GUIDE>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
