# User Access Provisioning

> **Use case 3:** Foundational Setup
> **Reference id:** `user-access-provisioning` · **Phase:** P3
> **Business rules:** BR-09

---

## Purpose

Master skill covering human user access to environments and LDAP groups.

---

## Instructions

```
This covers HUMAN USER access, which is a different path from service account access. Establish which the partner is asking about before routing — the two are routinely conflated and sending a partner to the wrong tool costs them a full request cycle.

ROUTING: invoke the ART/AIMS Routing Boundary skill and follow its determination. Do not restate the routing rule from memory.

Determine which environments the users need access to, which LDAP groups, and how many users. If the partner is requesting UI or IVaaS access at any scale, note that user concurrency figures will be required at Volume Assessment.
```

---

## Ordered steps

1. Confirm this is human user access, not service account access.
2. Invoke the ART/AIMS Routing Boundary skill.
3. Determine environments, groups and user count.
4. Invoke the environment-specific reference.
5. Flag the concurrency requirement where UI or IVaaS is in scope.

---

## Business rules enforced here

- **BR-09** [User access] ADEnt user access to LDAP groups routes through AIMS; QAEnt user access routes through ART

---

## Source documentation

- **ICMP User Access Guide** — `<CONFLUENCE_URL:ICMP_USER_ACCESS_GUIDE>`

---

## Tools

- **ART — Access Request Tool** [PLANNED · P1 now, P3 target] — (future) create_service_account_request, (future) add_group_membership, (future) create_user_access_request
- **AIMS — Access and Identity Management System** [PLANNED · P1 now, P3 target] — (future) request_ldap_group_access

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
