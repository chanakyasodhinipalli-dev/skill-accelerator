# Volume Rationale & Stakes

> **Use case 4:** Volume Assessment
> **Reference id:** `volume-rationale-stakes` · **Phase:** P1
> **Business rules:** BR-19, BR-20

---

## Purpose

Explains why volume is collected and what happens when it is wrong — answered from the skill's own knowledge, never deferred.

---

## Instructions

```
This skill exists because partners abandon volume questionnaires they do not understand. Answer rationale questions inline, from your own knowledge, without deferring to another team and without losing collection state.

THE STAKES — state these early, not as a footnote:
- Volumes drive the SPLI load testing performed before the partner goes live in production.
- ICMP handles MILLIONS OF REQUESTS PER DAY across all lines of business.
- If actual volume exceeds what was declared and ICMP services degrade, the blast radius is ENTERPRISE-WIDE. Every LOB and every upstream and downstream system on ICMP is affected, not only the partner who under-declared. This is why the numbers are asked for at this level of detail.
- ENFORCEMENT: if volume exceeds what was approved and declared, the ICMP platform support team CAN DISABLE THE SUBSCRIPTION.

REQUIRED FIDELITY: peak volumes at hourly AND daily granularity, plus the normal-business-hours profile. An average alone is not sufficient — capacity fails on peaks, not averages.

ANSWER GENERIC ICMP QUESTIONS INLINE. A partner who asks mid-collection how retention works should get an answer, then be returned to the exact field they were on.
```

---

## Ordered steps

1. State the stakes before collecting figures.
2. Answer rationale questions inline from own knowledge.
3. Answer generic ICMP questions inline without losing collection state.
4. Return the partner to the exact field they were on.

---

## Business rules enforced here

- **BR-19** [Volume] Volume must be declared per operation; 'we do not know' is not accepted — an educated estimate plus a 20-30% buffer is required
- **BR-20** [Volume] Exceeding approved and declared volume allows the ICMP platform support team to disable the subscription

---

## Source documentation

- **ICMP Capacity Management** — `<CONFLUENCE_URL:ICMP_CAPACITY_MANAGEMENT>`
- **SPLI Load Testing Overview** — `<CONFLUENCE_URL:SPLI_LOAD_TESTING_OVERVIEW>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
