# SPLI Ticket Creation

> **Use case 5:** Load Testing (SPLI)
> **Reference id:** `spli-ticket-creation` · **Phase:** P3
> **Business rules:** BR-22

---

## Purpose

Raises the SPLI load testing ticket in the allocated scrum team's Jira project with the full requirement package.

---

## Instructions

```
Raise the SPLI ticket for the load testing team.

PROJECT KEY — the same rule as capacity planning. NOT LJKX, NOT fixed. Use the ALLOCATED SCRUM TEAM'S project key resolved by the Scrum Team Project Key Resolution skill and held in journey state. If absent, hand back to Intake Verification. Never guess and never default to LJKX.

TICKET CONTENT: the complete SPLI requirement package, plus a link to the originating LJKX intake and a link to the capacity planning ticket so the two are traceable to each other.

PROCEDURE: call Jira MCP create_issue with the resolved project key. Read back with get_issue to confirm creation. Report the ticket key and URL to the partner. Do not report success unless the read-back confirms it.

AFTER CREATION: tell the partner what happens next — the load testing team picks it up, and SPLI completion is a prerequisite for production progression. A partner who does not know this waits passively at the wrong step.
```

---

## Ordered steps

1. Retrieve the resolved scrum team project key from journey state.
2. If absent, hand back to Intake Verification.
3. Assemble the full SPLI requirement package as the ticket payload.
4. Link to the LJKX intake and the capacity planning ticket.
5. Call Jira MCP create_issue with the resolved project key.
6. Read back with get_issue to confirm.
7. Report the ticket key and state that SPLI completion gates production progression.

---

## Business rules enforced here

- **BR-22** [Volume] Load testing (SPLI) must be performed end to end, not ICMP-only

---

## Source documentation

- **SPLI Ticket Template** — `<CONFLUENCE_URL:SPLI_TICKET_TEMPLATE>`
- **Scrum Team to Jira Project Key Mapping** — `<CONFLUENCE_URL:SCRUM_TEAM_TO_JIRA_PROJECT_KEY_MAPPING>`

---

## Tools

- **Jira MCP** [AVAILABLE · P3] — create_issue, get_issue

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
