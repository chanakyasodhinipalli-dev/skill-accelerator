# Documentation Pointers

> **Use case 1:** POC Assistance
> **Reference id:** `documentation-pointers` · **Phase:** P1
> **Business rules:** —

---

## Purpose

Directs the partner to the correct reference material for each POC activity.

---

## Instructions

```
Return the specific Confluence page or KB article for the activity in question, not a generic index. A partner sent to a documentation home page has to find their own way and often lands on the wrong version.

At phase 1, return links. At phase 2, read the page and answer the partner's actual question from it, then offer the link for depth. Never paraphrase a procedure from memory when the page is available to read — documentation changes and the page is the source of truth.

If no documentation exists for the activity, say so explicitly rather than substituting a generic page.
```

---

## Ordered steps

1. Identify the specific activity.
2. Return the specific page, not a generic index.
3. At phase 2, read and answer from the page.
4. State explicitly when documentation does not exist.

---

## Source documentation

- **ICMP Documentation Index** — `<CONFLUENCE_URL:ICMP_DOCUMENTATION_INDEX>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
