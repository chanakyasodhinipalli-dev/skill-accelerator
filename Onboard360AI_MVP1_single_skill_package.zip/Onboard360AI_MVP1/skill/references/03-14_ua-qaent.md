# QAEnt User Access

> **Use case 3:** Foundational Setup
> **Reference id:** `ua-qaent` · **Phase:** P3
> **Business rules:** BR-09

---

## Purpose

Non-production user access — requested through ART.

---

## Instructions

```
User access to QAEnt (Innovation and Non-Prod) is requested through ART.

Walk through the ART user access request: which groups, which users, the business justification, and the approving manager. Note that group names must come from the ICMP-provided set — do not guess.
```

---

## Ordered steps

1. Confirm the environment is QAEnt (Innovation or Non-Prod).
2. Walk through the ART user access request.
3. Use only ICMP-provided group names.
4. Capture the request reference.

---

## Business rules enforced here

- **BR-09** [User access] ADEnt user access to LDAP groups routes through AIMS; QAEnt user access routes through ART

---

## Source documentation

- **ART User Access Request Guide** — `<CONFLUENCE_URL:ART_USER_ACCESS_REQUEST_GUIDE>`

---

## Tools

- **ART — Access Request Tool** [PLANNED · P1 now, P3 target] — (future) create_service_account_request, (future) add_group_membership, (future) create_user_access_request

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
