# BAM Lookup

> **Use case 3:** Foundational Setup
> **Reference id:** `bam-lookup` · **Phase:** P1
> **Business rules:** —

---

## Purpose

Retrieves application name, Remedy ID and App ID from Business Application Management.

---

## Instructions

```
BAM — Business Application Management — is the source of the application name, Remedy ID and App ID.

WHY THIS MATTERS: the Remedy ID threads through the entire onboarding and subscription lifecycle — consumer application registration, application ownership identification, access provisioning, subscription management and operational support activities. Nothing in the Apigee path works without it. Establish it early rather than at submission time.

Walk the partner through locating their application in BAM and retrieving the application name, Remedy ID and App ID. If they do not know which BAM record corresponds to their application, help them identify it from the application system name and LOB.

There is currently no external integration with BAM. Guidance is instruction-based. In future, MCP or API access will allow direct retrieval — author the captured values into journey state so the eventual integration replaces the question rather than the whole skill.
```

---

## Ordered steps

1. Explain why the Remedy ID and App ID are needed downstream.
2. Guide the partner to locate their application record in BAM.
3. Capture application name, Remedy ID and App ID into journey state.
4. If the record cannot be identified, help locate it from application system name and LOB.

---

## Questions

**BQ1** — sequential
- Prompt: What is your BAM application name, Remedy ID and App ID?
- Capture: `bamApplicationName, remedyId, bamAppId`

---

## Source documentation

- **BAM Application Lookup Guide** — `<CONFLUENCE_URL:BAM_APPLICATION_LOOKUP_GUIDE>`

---

## Tools

- **BAM — Business Application Management** [PLANNED · P1 now, P3 target] — (future) get_application

---

## Future implementation

Future implementation: integrate BAM via MCP or API so application name, Remedy ID and App ID are retrieved automatically from the application system name, and the partner is asked only to confirm.
