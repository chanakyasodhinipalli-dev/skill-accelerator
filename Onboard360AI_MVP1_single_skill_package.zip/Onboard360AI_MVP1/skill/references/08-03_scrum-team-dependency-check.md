# Scrum Team Dependency Check

> **Use case 8:** Environment Progression
> **Reference id:** `scrum-team-dependency-check` · **Phase:** P3
> **Business rules:** BR-17

---

## Purpose

Determines whether a dedicated scrum team is assigned, which governs environment access beyond Innovation.

---

## Instructions

```
Determine the scrum team allocation from the intake summary produced by Intake Verification. Do not ask the partner if the answer is available from the intake — they frequently do not know.

THE RULE: without a dedicated scrum team assisting them, the partner should NOT go for Non-Prod or Production access or subscriptions. Innovation only.

IF NO SCRUM TEAM IS ALLOCATED:
- Say so plainly and early. Do not let the partner discover it at subscription time.
- Explain what it means concretely: Innovation only, no Non-Prod, no Production.
- Explain how allocation happens — through LOB prioritisation of the intake — and who owns it.
- Tell them what they CAN do in the meantime, so the answer is not purely a block.

IF A SCRUM TEAM IS ALLOCATED: record the team name in journey state and confirm the scrum team project key has been resolved for downstream ticket creation. The two are linked; a partner with an allocated team but an unresolved project key will fail at capacity planning ticket creation.
```

---

## Ordered steps

1. Read the scrum team allocation from the intake summary.
2. If none, state the Innovation-only consequence plainly and early.
3. Explain how allocation happens and who owns it.
4. State what the partner can do in the meantime.
5. If allocated, record the team and confirm the project key is resolved.

---

## Business rules enforced here

- **BR-17** [Progression] Without a dedicated scrum team, the partner may subscribe in Innovation only

---

## Tools

- **Jira MCP** [AVAILABLE · P3] — get_issue, get_project

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
