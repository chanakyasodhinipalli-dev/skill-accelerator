# Repository Support

> **Use case 3:** Foundational Setup
> **Reference id:** `repository-support` · **Phase:** P2
> **Business rules:** —

---

## Purpose

Master skill establishing unambiguously which ICMP repository the partner requires.

---

## Instructions

```
ICMP fronts multiple internal and downstream repositories. The partner must know which one their content lives in or targets, because API contracts, metadata models and retention behaviour differ by repository.

REPOSITORIES: ICMP FileNet (the primary repository); Documentum; DMS; MARS; and other legacy repositories.

Do not let the partner proceed on "not sure". A partner who builds against the FileNet contract when their content targets MARS discovers the mismatch during integration testing, which is expensive. If they do not know, help them determine it: ask where their content is created, which system owns it today, and what their upstream system already integrates with.

Invoke the matching repository reference once determined.
```

---

## Ordered steps

1. Ask which repository the partner requires.
2. If unsure, determine it from where content originates and what the upstream system integrates with today.
3. Invoke the matching repository reference.
4. Record the repository in journey state.

---

## Questions

**RSQ1** — sequential
- Prompt: Which repository does your content live in, or target?
- Options: ICMP FileNet · Documentum · DMS · MARS · Legacy — other · Not sure
- Capture: `repository`

---

## Source documentation

- **ICMP Repository Overview** — `<CONFLUENCE_URL:ICMP_REPOSITORY_OVERVIEW>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
