# Documentum

> **Use case 3:** Foundational Setup
> **Reference id:** `repo-documentum` · **Phase:** P2
> **Business rules:** —

---

## Purpose

Downstream repository fronted by ICMP.

---

## Instructions

```
Cover the Documentum integration path, how it differs from FileNet in metadata and retrieval behaviour, and any operations not supported.

State clearly which of the partner's selected capabilities this repository supports and which it does not. A capability the partner selected that this repository cannot serve is a finding, not a detail — surface it immediately rather than letting it emerge at scope selection.

Point to the repository-specific documentation for API contract and metadata detail rather than reproducing it here.
```

---

## Ordered steps

1. Confirm Documentum is the correct repository.
2. Map the partner's selected capabilities against what this repository supports.
3. Surface unsupported capabilities immediately.
4. Point to repository-specific API and metadata documentation.

---

## Source documentation

- **ICMP Documentum Integration Guide** — `<CONFLUENCE_URL:ICMP_DOCUMENTUM_INTEGRATION_GUIDE>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
