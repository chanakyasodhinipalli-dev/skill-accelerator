# ECM Intake Creation Walkthrough

> **Use case 2:** Intake Verification
> **Reference id:** `ecm-intake-creation-walkthrough` · **Phase:** P2
> **Business rules:** —

---

## Purpose

Drives the partner through creating a new ECM onboarding intake when none exists.

---

## Instructions

```
Walk the partner through the ECM intake creation process step by step rather than handing them a link and leaving.

Cover what the intake must contain for it to be actionable: the application system, the LOB, the business purpose, the ICMP capabilities required, the target environments, the intended go-live timeline, and the ownership and support contacts. An intake missing these gets returned, which costs a cycle.

Set expectations about what happens next: LOB prioritisation, scrum team allocation, and the fact that scrum team allocation is what unlocks Non-Prod and Production. A partner who understands this chases the right thing.

At phase 2, read the current intake documentation and guide from it — the intake form changes and stale guidance produces returned tickets.
```

---

## Ordered steps

1. Confirm no intake already exists.
2. Walk through the intake form section by section.
3. State the required content and why each item matters.
4. Set expectations on prioritisation and scrum team allocation.
5. Capture the resulting intake key when the partner has it.

---

## Source documentation

- **ECM Intake Process** — `<CONFLUENCE_URL:ECM_INTAKE_PROCESS>`
- **ECM Intake Form Field Guide** — `<CONFLUENCE_URL:ECM_INTAKE_FORM_FIELD_GUIDE>`

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
