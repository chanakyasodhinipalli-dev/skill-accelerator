# Environment Variable Seeding

> **Use case 7:** Postman Collection Generation
> **Reference id:** `environment-variable-seeding` · **Phase:** P3
> **Business rules:** —

---

## Purpose

Seeds the collection with the correct environment, service account and endpoint values.

---

## Instructions

```
Seed a Postman environment alongside the collection.

SEED: target environment name (Innovation / Non-Prod / Production); base URL for that environment; service account (QAEnt for Innovation and Non-Prod, production account for Production); App Identifier; and any required standard headers.

NEVER EMBED SECRETS. Credentials, tokens, private keys and certificate material are named placeholders only. State clearly which placeholders the partner must fill in themselves and where each value comes from.

Where the capability set includes streaming or notification APIs, include the certificate configuration as a documented placeholder and point to the Venafi Certificates skill for how to obtain it.

Name the environment file so the target environment is obvious. A partner running a Non-Prod collection against production values is a real and avoidable incident.
```

---

## Ordered steps

1. Seed environment name, base URL, service account, App Identifier and standard headers.
2. Leave all secrets as named placeholders.
3. State which placeholders the partner must complete and where each value comes from.
4. Include certificate placeholders where streaming or notifications are in scope.
5. Name files so the target environment is unambiguous.

---

## Tools

- **Postman Collection Generator** [AVAILABLE · P3] — build_collection, emit_download
- **ICMP & iDocs APIs** [AVAILABLE · P3] — icmp_ingest, icmp_search, icmp_retrieve, icmp_notifications, idocs_document_services

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
