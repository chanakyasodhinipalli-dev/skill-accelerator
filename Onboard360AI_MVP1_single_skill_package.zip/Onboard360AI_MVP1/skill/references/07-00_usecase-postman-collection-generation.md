# Use Case 7 — Postman Collection Generation

> **Playbook reference** · branch: BOTH · phase: P3
> **Procedure references:** 3

---

## Goal — this use case is not complete until every line is true

1. Scope-accurate Postman collection generated from the approved scope set.
2. Collection seeded with the correct environment, service account and endpoint values.
3. Collection delivered to the partner as a downloadable file.

---

## When this use case runs

Branch: **BOTH**. Terminal — return control to the partner.

---

## Key instructions

```
You are working the Postman Collection Generation use case for ICMP partner onboarding. Your goal is a scope-accurate collection generated and downloaded.

WHEN YOU RUN
After subscription approval. You consume the APPROVED scope set as input — that is what makes the collection accurate rather than generic. If the scope set is not approved yet, say so and wait; a collection built on a requested-but-unapproved scope teaches the partner to call things they will be denied.

WHAT YOU BUILD
Include exactly the requests the approved scope permits. Do not include convenience examples outside the approved scope, even helpful-looking ones — a partner who finds a request in their collection reasonably assumes they are entitled to call it.
Seed environment variables for: target environment (Innovation / Non-Prod / Production), base URL for that environment, service account, App Identifier, and any required headers. Leave secrets as named placeholders; never embed credentials, tokens or certificate material.
Where the partner's capability set includes streaming or notification APIs, include the certificate configuration as a documented placeholder and point to the Venafi skill.

DELIVERY
Emit as a Postman v2.1 collection. Name it so the environment is obvious from the filename. Tell the partner what is in it, what they must fill in themselves, and what will fail and why if they call outside their scope.
```

---

## Use-case questions

**PMQ1** — sequential
- Prompt: Which environment should the collection target?
- Options: Innovation · Non-Prod · Production
- Capture: `collectionEnvironment`

**PMQ2** — conditional
- Prompt: I need your approved scope set before I can build an accurate collection. Has your subscription been approved?
- Options: Yes — approved · Not yet
- Condition: `approved scope set not present in journey state`
- Capture: `subscriptionApproved`

---

## Procedure references for this use case

Read the reference before performing its step.

| Reference file | Procedure | Phase | Rules |
|---|---|---|---|
| `07-01_scope-driven-collection-build.md` | Scope-Driven Collection Build | P3 | BR-13 |
| `07-02_environment-variable-seeding.md` | Environment Variable Seeding | P3 | — |
| `07-03_download-delivery.md` | Download Delivery | P3 | — |

---

## Business rules enforced in this use case

- **BR-13** [Scope] Scope selection is mandatory. ICMP performs runtime security validation against the approved scope; a scope cannot be selected then exceeded.

---

## Tools

- **Postman Collection Generator** [AVAILABLE · P3] — build_collection, emit_download
- **Local Tools** [AVAILABLE · P3] — validate_format, assemble_payload, state_read_write
- **ICMP & iDocs APIs** [AVAILABLE · P3] — icmp_ingest, icmp_search, icmp_retrieve, icmp_notifications, idocs_document_services