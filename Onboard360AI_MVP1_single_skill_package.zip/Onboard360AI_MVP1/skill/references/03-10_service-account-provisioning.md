# Service Account Provisioning

> **Use case 3:** Foundational Setup
> **Reference id:** `service-account-provisioning` · **Phase:** P3
> **Business rules:** BR-07, BR-08, BR-10

---

## Purpose

Master skill covering why service accounts are required, how to obtain them, and the naming and grouping rules.

---

## Instructions

```
EXPLAIN WHY BEFORE ASKING FOR ONE — partners who do not understand this supply a personal account and fail later.

ICMP APIs are consumed by APPLICATIONS, not by individuals. Integrations therefore require accounts that are:
- non-human
- non-expiring
- dedicated application accounts
- not tied to any specific user

This is why service accounts carry: application authentication; API access; Apigee consumer application association; security group membership; auditing; and operational support.

ENVIRONMENT MAPPING
Innovation -> QAEnt service account
Non-Prod -> QAEnt service account
Production -> production service account
All creation routes through ART regardless of environment.

NAMING
The service account name must encode the environment (innovation / non-prod / prod) so it is identifiable at a glance. Production accounts remain separate from innovation and non-prod accounts even though creation runs through the same tool.

GROUP MEMBERSHIP
The service account must be added to the LDAP groups provided by ICMP resources during onboarding. Which groups apply depends on the access type required, the APIs in scope and the operations to be performed. This is determined during onboarding, not from a fixed list. DO NOT GUESS GROUP NAMES — if the group set has not been provided, say so and record it as an open item against the ICMP onboarding contact.
```

---

## Ordered steps

1. Explain why service accounts are required.
2. Determine which environments need accounts.
3. Invoke the environment-specific reference.
4. Apply the environment-encoding naming rule.
5. Capture the ICMP-provided LDAP group set; never guess group names.

---

## Questions

**SAQ1** — sequential
- Prompt: Which environments do you need service accounts for?
- Options: Innovation · Non-Prod · Production
- Capture: `serviceAccountEnvironments`

---

## Business rules enforced here

- **BR-07** [Service accounts] ICMP APIs are consumed by applications, not individuals — accounts must be non-human, non-expiring, dedicated and not tied to a user
- **BR-08** [Service accounts] All service account creation and group addition routes through ART, for both ADEnt and QAEnt
- **BR-10** [Service accounts] Service account names must encode the environment (innovation / non-prod / prod)

---

## Source documentation

- **Service Account Standards** — `<CONFLUENCE_URL:SERVICE_ACCOUNT_STANDARDS>`
- **ART Service Account Request Guide** — `<CONFLUENCE_URL:ART_SERVICE_ACCOUNT_REQUEST_GUIDE>`

---

## Tools

- **ART — Access Request Tool** [PLANNED · P1 now, P3 target] — (future) create_service_account_request, (future) add_group_membership, (future) create_user_access_request

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
