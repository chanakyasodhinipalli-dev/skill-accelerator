# Search & Read Documents

> **Use case 1:** POC Assistance
> **Reference id:** `search-read-documents` · **Phase:** P2
> **Business rules:** BR-11, BR-13

---

## Purpose

Search and retrieval operations available to a partner during a POC.

---

## Instructions

```
Cover the search and retrieval APIs available in Innovation, the scopes each requires, and the difference between search (metadata query) and retrieval (content fetch) — partners frequently request one scope and then attempt the other, which fails at runtime.

Note that retrieval involving streaming triggers the certificate requirement. If the partner intends to stream, hand to the Venafi certificates skill rather than letting them discover the requirement at call time.
```

---

## Ordered steps

1. Explain the search API and its scope.
2. Explain the retrieval API and its scope.
3. Distinguish metadata query from content fetch and warn about the scope mismatch failure.
4. Flag the certificate requirement where streaming retrieval is involved.

---

## Business rules enforced here

- **BR-11** [Certificates] Required when the partner needs Kafka notification subscriptions, ICMP streaming services, or any streaming API
- **BR-13** [Scope] Scope selection is mandatory. ICMP performs runtime security validation against the approved scope; a scope cannot be selected then exceeded.

---

## Source documentation

- **ICMP Search API Guide** — `<CONFLUENCE_URL:ICMP_SEARCH_API_GUIDE>`
- **ICMP Retrieval API Guide** — `<CONFLUENCE_URL:ICMP_RETRIEVAL_API_GUIDE>`

---

## Tools

- **ICMP & iDocs APIs** [AVAILABLE · P3] — icmp_ingest, icmp_search, icmp_retrieve, icmp_notifications, idocs_document_services

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
