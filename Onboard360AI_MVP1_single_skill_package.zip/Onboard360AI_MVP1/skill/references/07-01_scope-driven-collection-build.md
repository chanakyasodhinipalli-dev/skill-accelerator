# Scope-Driven Collection Build

> **Use case 7:** Postman Collection Generation
> **Reference id:** `scope-driven-collection-build` · **Phase:** P3
> **Business rules:** BR-13

---

## Purpose

Builds the Postman collection from the approved scope set so it contains only permitted requests.

---

## Instructions

```
Build from the APPROVED scope set, not the requested one. If the subscription is not yet approved, say so and wait — a collection built on an unapproved scope teaches the partner to call things they will be denied, and they will believe the denial is a defect.

INCLUDE EXACTLY what the approved scope permits. Do NOT add convenience examples outside the approved scope, however helpful they look: a partner who finds a request in their collection reasonably assumes they are entitled to call it, and discovers otherwise at runtime.

STRUCTURE the collection by operation — ingestion, search, retrieval, notifications — matching the partner's capability set. Include realistic example payloads consistent with their repository's metadata model.

For each request, include a short description stating which scope permits it. This makes the enforcement model visible in the artifact the partner actually uses.

Emit as a Postman v2.1 collection.
```

---

## Ordered steps

1. Confirm the subscription is approved and read the approved scope set.
2. Include only requests the approved scope permits.
3. Structure by operation, matching the capability set.
4. Include example payloads consistent with the repository metadata model.
5. Annotate each request with the scope that permits it.
6. Emit as Postman v2.1.

---

## Business rules enforced here

- **BR-13** [Scope] Scope selection is mandatory. ICMP performs runtime security validation against the approved scope; a scope cannot be selected then exceeded.

---

## Tools

- **Postman Collection Generator** [AVAILABLE · P3] — build_collection, emit_download
- **ICMP & iDocs APIs** [AVAILABLE · P3] — icmp_ingest, icmp_search, icmp_retrieve, icmp_notifications, idocs_document_services

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
