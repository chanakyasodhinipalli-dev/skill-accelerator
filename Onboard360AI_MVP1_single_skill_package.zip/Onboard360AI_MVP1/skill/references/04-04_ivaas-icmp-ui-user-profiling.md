# IIVaaS / ICMP UI User Profiling

> **Use case 4:** Volume Assessment
> **Reference id:** `ivaas-icmp-ui-user-profiling` · **Phase:** P1
> **Business rules:** BR-19

---

## Purpose

Collects user counts and concurrency where the ICMP Viewer service or UI is in use.

---

## Instructions

```
Triggered when the partner's capability set includes ICMP Viewer (IVaaS) or ICMP UI usage. Skip entirely if neither applies — do not ask user concurrency questions of an API-only partner.

COLLECT:
- Number of NEW users being onboarded
- Concurrent users at MINIMUM, AVERAGE and PEAK

Concurrency is the figure that matters for the IVaaS Viewer service. A partner who reports two thousand named users but forty concurrent has a very different capacity profile from one reporting two hundred named users all active at 9am.

Prompt for the peak timing as well as the peak number — a peak concentrated in a fifteen-minute window is a different test case from one spread across a working day.
```

---

## Ordered steps

1. Check whether IVaaS or ICMP UI is in the capability set; skip if not.
2. Collect the number of new users being onboarded.
3. Collect minimum, average and peak concurrent users.
4. Capture when the peak occurs, not only its size.

---

## Questions

**UQ1** — conditional
- Prompt: How many new users are being onboarded?
- Condition: `capabilitySet includes IVaaS or ICMP UI`
- Capture: `newUserCount`

**UQ2** — conditional
- Prompt: What are your minimum, average and peak concurrent user counts, and when does the peak occur?
- Condition: `capabilitySet includes IVaaS or ICMP UI`
- Capture: `concurrentUsersMin, concurrentUsersAvg, concurrentUsersPeak, peakTiming`

---

## Business rules enforced here

- **BR-19** [Volume] Volume must be declared per operation; 'we do not know' is not accepted — an educated estimate plus a 20-30% buffer is required

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
