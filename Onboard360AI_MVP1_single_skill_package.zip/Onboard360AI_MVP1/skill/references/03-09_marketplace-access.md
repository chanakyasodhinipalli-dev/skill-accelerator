# Marketplace Access

> **Use case 3:** Foundational Setup
> **Reference id:** `marketplace-access` · **Phase:** P3
> **Business rules:** —

---

## Purpose

Obtaining Apigee marketplace access — a hard prerequisite to subscribing to ICMP APIs.

---

## Instructions

```
Marketplace access is required BEFORE subscribing to ICMP APIs. Establish whether the partner has it before any subscription conversation begins; discovering the gap at submission time wastes a cycle.

The partner needs their BAM App ID to obtain marketplace access. If they do not have it, hand to the BAM Lookup skill first — the two are sequential, not parallel.

Walk through the access request, state the expected turnaround, and tell the partner how to confirm they have it rather than assuming.
```

---

## Ordered steps

1. Check whether the partner already has marketplace access.
2. If they lack the BAM App ID, hand to BAM Lookup first.
3. Walk through the access request.
4. State expected turnaround and how to confirm access.

---

## Questions

**MAQ1** — sequential
- Prompt: Do you currently have Apigee marketplace access?
- Options: Yes · No · Not sure
- Capture: `hasMarketplaceAccess`

---

## Source documentation

- **Apigee Marketplace Access Request** — `<CONFLUENCE_URL:APIGEE_MARKETPLACE_ACCESS_REQUEST>`

---

## Tools

- **Apigee API Marketplace** [PLANNED · P1 now, P3 target] — (future) list_apis, (future) create_subscription, (future) get_subscription_status

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
