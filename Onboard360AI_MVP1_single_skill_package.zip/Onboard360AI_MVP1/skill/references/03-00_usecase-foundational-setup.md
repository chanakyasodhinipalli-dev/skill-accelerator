# Use Case 3 — Foundational Setup

> **Playbook reference** · branch: BOTH · phase: P1
> **Procedure references:** 19

---

## Goal — this use case is not complete until every line is true

1. Identity, access and environment established for the partner application.
2. Service accounts created for every environment the partner is entitled to.
3. Correct access route followed for every request type (ART versus AIMS).
4. Certificates obtained where the partner's capability set requires them.
5. Repository, capability set and ownership record captured.

---

## When this use case runs

Branch: **BOTH**. Next: **apigee-subscription, volume-assessment**.

---

## Key instructions

```
You are working the Foundational Setup use case for ICMP partner onboarding. Your goal is identity, access and environment established. You serve both the POC and implementation branches; POC partners need a narrower subset, so scope your questions to their branch.

ORDER OF WORK
1. ICMP Foundations and the Capabilities Catalogue — establish what the partner actually needs. Everything downstream (scope, groups, certificates) derives from this.
2. Repository Support — establish unambiguously which repository the partner requires.
3. BAM lookup — obtain application name, Remedy ID and App ID. The Remedy ID threads through consumer application registration, ownership identification, access provisioning, subscription management and operational support. Nothing in the Apigee path works without it.
4. Marketplace access — a hard prerequisite to subscribing to ICMP APIs.
5. Service account provisioning — per environment, via ART.
6. User access provisioning — via ART or AIMS depending on request type and environment.
7. Venafi certificates — only where the capability set triggers the requirement.
8. Ownership and Support Assessment — collect the organisational record reused downstream.

WHY SERVICE ACCOUNTS — explain this, do not just ask for one
ICMP APIs are consumed by applications, not by individuals. Integrations therefore require accounts that are non-human, non-expiring, dedicated to the application, and not tied to any specific user. The service account carries application authentication, API access, Apigee consumer application association, security group membership, auditing and operational support.
The service account must be added to the LDAP groups provided by ICMP resources during onboarding. Which groups apply depends on the access type required, the APIs in scope and the operations to be performed — it is a determination made during onboarding, not a fixed list. Do not guess group names.

SERVICE ACCOUNT NAMING
Names must encode the environment (innovation / non-prod / prod) so they are identifiable at a glance. Production accounts remain separate from innovation and non-prod accounts even though creation runs through the same tool.

ACCESS ROUTING — apply the boundary rule exactly
Invoke the ART/AIMS Routing Boundary skill for every access request and follow its determination. Never send a partner to both tools for the same request, and never leave the tool ambiguous.

CERTIFICATES — conditional, not universal
Certificates are required only when the partner needs Kafka notification subscriptions, ICMP streaming services, or any API involving streaming. If none of those apply, say so rather than sending the partner on an unnecessary Venafi request. Where required, two sets are needed: non-prod and production. The full certificate subject must be retained — no truncation. NOT AVAILABLE is an acceptable answer; it becomes a downstream action item, not a hard stop.
```

---

## Use-case questions

**FQ1** — sequential
- Prompt: Which ICMP capabilities does your application need?
- Options: Ingestion / archival · Search and retrieval · Download · Export · Request notifications · Document notifications · Package notifications · ICMP Viewer (IVaaS) · Retention · Legal hold · Retention event updates
- Capture: `capabilitySet`

**FQ2** — sequential
- Prompt: Which repository does your content live in, or target?
- Options: ICMP FileNet · Documentum · DMS · MARS · Legacy — other · Not sure
- Capture: `repository`

**FQ3** — sequential
- Prompt: What is your BAM App ID and Remedy ID?
- Capture: `bamAppId, remedyId`

**FQ4** — conditional
- Prompt: No problem — I'll show you how to retrieve them from BAM. Continue?
- Options: Yes · I'll get them and come back
- Condition: `FQ3 unanswered or 'not sure'`
- Capture: `bamLookupMode`

**FQ5** — sequential
- Prompt: Which environments do you need service accounts for?
- Options: Innovation · Non-Prod · Production
- Capture: `serviceAccountEnvironments`

**FQ6** — conditional
- Prompt: Your capability set requires application certificates. Please provide your certificate information — enter NOT AVAILABLE if you do not have it yet.
- Condition: `capabilitySet includes any of [Request notifications, Document notifications, Package notifications] OR any streaming API`
- Capture: `nonProdCertificateSubject, prodCertificateSubject`

---

## Procedure references for this use case

Read the reference before performing its step.

| Reference file | Procedure | Phase | Rules |
|---|---|---|---|
| `03-01_icmp-foundations.md` | ICMP Foundations | P2 | — |
| `03-02_icmp-capabilities-catalogue.md` | ICMP Capabilities Catalogue | P2 | BR-11 |
| `03-03_repository-support.md` | Repository Support | P2 | — |
| `03-04_repo-icmp-filenet.md` | ICMP FileNet | P2 | — |
| `03-05_repo-documentum.md` | Documentum | P2 | — |
| `03-06_repo-dms.md` | DMS | P2 | — |
| `03-07_repo-mars.md` | MARS | P2 | — |
| `03-08_repo-legacy.md` | Legacy Repositories | P2 | — |
| `03-09_marketplace-access.md` | Marketplace Access | P3 | — |
| `03-10_service-account-provisioning.md` | Service Account Provisioning | P3 | BR-07, BR-08, BR-10 |
| `03-11_sa-qaent.md` | QAEnt Service Account Creation | P3 | BR-08, BR-10 |
| `03-12_sa-adent.md` | ADEnt Service Account Creation | P3 | BR-08, BR-10 |
| `03-13_user-access-provisioning.md` | User Access Provisioning | P3 | BR-09 |
| `03-14_ua-qaent.md` | QAEnt User Access | P3 | BR-09 |
| `03-15_ua-adent.md` | ADEnt User Access (AIMS) | P3 | BR-09 |
| `03-16_art-aims-routing-boundary.md` | ART / AIMS Routing Boundary | P1 | BR-08, BR-09 |
| `03-17_bam-lookup.md` | BAM Lookup | P1 | — |
| `03-18_venafi-certificates.md` | Venafi Certificates | P1 | BR-11, BR-12 |
| `03-19_ownership-support-assessment.md` | Ownership & Support Assessment | P2 | — |

---

## Business rules enforced in this use case

- **BR-11** [Certificates] Required when the partner needs Kafka notification subscriptions, ICMP streaming services, or any streaming API
- **BR-07** [Service accounts] ICMP APIs are consumed by applications, not individuals — accounts must be non-human, non-expiring, dedicated and not tied to a user
- **BR-08** [Service accounts] All service account creation and group addition routes through ART, for both ADEnt and QAEnt
- **BR-10** [Service accounts] Service account names must encode the environment (innovation / non-prod / prod)
- **BR-09** [User access] ADEnt user access to LDAP groups routes through AIMS; QAEnt user access routes through ART
- **BR-12** [Certificates] Two sets required — non-prod and production. The full certificate subject must be retained.

---

## Tools

- **Knowledge Base / Confluence** [PHASED · P1 now, P2 target] — return_links, read_and_answer
- **BAM — Business Application Management** [PLANNED · P1 now, P3 target] — (future) get_application
- **Venafi** [PLANNED · P1 now, P3 target] — (future) request_certificate, (future) get_certificate_status
- **ART — Access Request Tool** [PLANNED · P1 now, P3 target] — (future) create_service_account_request, (future) add_group_membership, (future) create_user_access_request
- **AIMS — Access and Identity Management System** [PLANNED · P1 now, P3 target] — (future) request_ldap_group_access