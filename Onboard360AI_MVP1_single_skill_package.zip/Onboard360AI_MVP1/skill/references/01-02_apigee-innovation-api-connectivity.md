# Apigee Innovation API Connectivity

> **Use case 1:** POC Assistance
> **Reference id:** `apigee-innovation-api-connectivity` · **Phase:** P3
> **Business rules:** BR-04, BR-06, BR-13

---

## Purpose

How to connect to ICMP Innovation APIs through Apigee without an intake.

---

## Instructions

```
Explain that Innovation API access through Apigee requires no intake, but does require marketplace access, a consumer application and a QAEnt service account. Those come from Foundational Setup — hand over rather than duplicating the guidance, and tell the partner it is a handoff rather than a new hurdle.

Cover: obtaining marketplace access; creating the consumer application in NGDC; the App Identifier requirement (mandatory for ICMP even though the marketplace presents it as optional); selecting the Innovation scope; and the QAEnt service account that Innovation uses.

State the runtime scope enforcement rule here too, even in POC: ICMP validates against the approved scope. A POC that calls outside its scope fails in exactly the same way production does.
```

---

## Ordered steps

1. Confirm the partner has, or is routed to obtain, marketplace access.
2. Explain consumer application creation in NGDC.
3. State the mandatory App Identifier rule and the QAEnt service account for Innovation.
4. Guide Innovation scope selection.
5. State that scope is enforced at runtime, in POC as in production.

---

## Business rules enforced here

- **BR-04** [Consumer app] All new consumer applications must be created in NGDC, not the Heritage data center
- **BR-06** [App Identifier] Mandatory for ICMP though the marketplace presents it as optional; must hold the service account and be populated before submission
- **BR-13** [Scope] Scope selection is mandatory. ICMP performs runtime security validation against the approved scope; a scope cannot be selected then exceeded.

---

## Source documentation

- **Apigee Marketplace — ICMP APIs** — `<CONFLUENCE_URL:APIGEE_MARKETPLACE_—_ICMP_APIS>`
- **ICMP Innovation API Reference** — `<CONFLUENCE_URL:ICMP_INNOVATION_API_REFERENCE>`

---

## Tools

- **Apigee API Marketplace** [PLANNED · P1 now, P3 target] — (future) list_apis, (future) create_subscription, (future) get_subscription_status
- **ICMP & iDocs APIs** [AVAILABLE · P3] — icmp_ingest, icmp_search, icmp_retrieve, icmp_notifications, idocs_document_services

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
