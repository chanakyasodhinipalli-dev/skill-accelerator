# Document Ingestion (POC)

> **Use case 1:** POC Assistance
> **Reference id:** `document-ingestion-poc` · **Phase:** P2
> **Business rules:** —

---

## Purpose

Ingesting and archiving documents into ICMP during a proof of concept.

---

## Instructions

```
Explain the ingestion path available in Innovation: the API, the required scope, the document and metadata expectations, and the target repository.

Establish the repository first — ingestion behaviour differs by repository, and a partner who assumes FileNet when their content targets another repository will build against the wrong contract. Hand to the Repository Support skill if it is not yet determined.

Set expectations about POC volume: Innovation is not sized for production-scale ingestion. If the partner wants to ingest at meaningful volume, that is a Volume Assessment and Load Testing conversation, and it requires an intake.
```

---

## Ordered steps

1. Confirm the target repository.
2. Explain the ingestion API and required scope.
3. State document and metadata expectations.
4. Set POC volume expectations and name the threshold at which an intake is required.

---

## Source documentation

- **ICMP Ingestion API Guide** — `<CONFLUENCE_URL:ICMP_INGESTION_API_GUIDE>`
- **ICMP Document Metadata Model** — `<CONFLUENCE_URL:ICMP_DOCUMENT_METADATA_MODEL>`

---

## Tools

- **ICMP & iDocs APIs** [AVAILABLE · P3] — icmp_ingest, icmp_search, icmp_retrieve, icmp_notifications, idocs_document_services

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
