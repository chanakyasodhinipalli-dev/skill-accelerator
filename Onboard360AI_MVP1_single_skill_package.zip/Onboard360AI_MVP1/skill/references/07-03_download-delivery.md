# Download Delivery

> **Use case 7:** Postman Collection Generation
> **Reference id:** `download-delivery` · **Phase:** P3
> **Business rules:** —

---

## Purpose

Delivers the generated collection to the partner as a downloadable file with usage guidance.

---

## Instructions

```
Deliver the collection and environment as downloadable files.

WITH THE DOWNLOAD, TELL THE PARTNER:
- What is in the collection, grouped by operation
- Which placeholders they must complete before it will work
- Which environment it targets
- What will fail and why if they call outside their approved scope — restate that scope is enforced at runtime, so this collection is a boundary as well as a starting point

Confirm the download succeeded rather than assuming. If generation failed, say so plainly and state what is missing.
```

---

## Ordered steps

1. Emit collection and environment as downloadable files.
2. Summarise contents by operation.
3. List the placeholders requiring completion.
4. State the target environment.
5. Restate runtime scope enforcement.
6. Confirm delivery succeeded.

---

## Tools

- **Postman Collection Generator** [AVAILABLE · P3] — build_collection, emit_download
- **Local Tools** [AVAILABLE · P3] — validate_format, assemble_payload, state_read_write

---

## Future implementation

Future implementation: expand this skill to fetch every required detail automatically — first from the onboarding journey state, then by reading the linked knowledge-base pages (phase 2), then from the owning system of record via MCP or API (phase 3) — and ask the partner only for what genuinely cannot be derived.
