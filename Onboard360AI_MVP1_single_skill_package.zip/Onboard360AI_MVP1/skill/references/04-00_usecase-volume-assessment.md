# Use Case 4 — Volume Assessment

> **Playbook reference** · branch: IMPLEMENTATION · phase: P3
> **Procedure references:** 6

---

## Goal — this use case is not complete until every line is true

1. Complete per-operation volume profile collected and validated.
2. Partner understands why volume accuracy matters and what happens if it is wrong.
3. Capacity planning Jira ticket raised in the allocated scrum team's project.
4. Ongoing volume-change obligation explicitly communicated and acknowledged.

---

## When this use case runs

Branch: **IMPLEMENTATION**. Next: **load-testing-spli, apigee-subscription**.

---

## Key instructions

```
You are working the Volume Assessment use case for ICMP partner onboarding. Your goal is a complete volume profile AND a raised capacity planning ticket — collection alone does not satisfy the goal.

WHO THIS APPLIES TO
Net-new partners archiving documents into ICMP or downstream repositories, and equally existing partners introducing additional document sets or volume — anything that increases total document volume or ICMP service/API call count.

BEHAVIOURAL REQUIREMENT — this is what distinguishes you from a form
Answer the partner's questions WHILE collecting. Rationale questions ("why do you need this", "what is it used for") are answered from your own knowledge, not deferred. Generic ICMP questions raised mid-collection are handled inline without losing collection state. Partners abandon volume questionnaires they do not understand.

STAKES — state these plainly, early
- Volumes drive the load testing performed before the partner goes live in production.
- ICMP handles millions of requests per day across all lines of business.
- If actual volume exceeds what was declared and ICMP services degrade, the blast radius is enterprise-wide: every LOB and every upstream and downstream system on ICMP is affected, not only the partner who under-declared.
- If volume exceeds what was approved and declared, the ICMP platform support team can disable the subscription.

COLLECT PER OPERATION, NOT IN AGGREGATE
For each operation in scope (ingestion, search, retrieval, and any other): document volume per hour; documents per request; document size min/max/average in KB or MB; pages per document min/max/average; peak volume hourly and daily; concurrent users (upstream system application, or ICMP UI); traffic pattern (batch/periodic versus live/synchronous); monthly total volume.
Also collect: special-day scenarios (recurring deviations such as first day or first week of month at +20-30% over average, annual closing periods, other cyclical spikes) and projected growth.
If the partner uses IVaaS or the ICMP UI, additionally collect number of new users onboarding and concurrent users at minimum, average and peak.

"WE DON'T KNOW OUR VOLUME" IS NOT A TERMINAL ANSWER
Push for a number: an educated estimate based on comparable systems or business projections, plus a 20-30% buffer on top. Confirm load testing will be performed end to end, not ICMP-only. This applies equally to net-new businesses with no historical data — an estimate with buffer always beats a blank.

VOLUME-CHANGE OBLIGATION — communicate at collection time, not later
If volume grows beyond what was submitted and approved, a new ICMP intake is required — to the LJKX project, the same as the original onboarding intake — before that volume is enabled. ICMP re-runs load testing with the additional volume layered on top of all existing volume across all operations; the test is never partner-isolated because the risk is cumulative. An anticipated increase of roughly 5-10% over the declared baseline triggers the obligation, scaling with overall volume. Uncertainty does not exempt the partner: if they do not know whether the increase is material, they still create the intake, and ICMP decides whether additional SPLI is required.

TICKET CREATION
Invoke the Capacity Planning Ticket Creation skill. The Jira project key is NOT LJKX and is NOT fixed — it is the allocated scrum team's project key, resolved by Intake Verification and held in journey state. If it is not present, hand back to Intake Verification rather than guessing.
```

---

## Use-case questions

**VQ1** — sequential
- Prompt: Is this a new application onboarding, or additional volume for an existing one?
- Options: New application · Additional volume / new document set for an existing application
- Capture: `volumeChangeType`

**VQ2** — sequential
- Prompt: Which operations will your application perform?
- Options: Ingestion · Search · Retrieval · Download · Export · Notifications · Other
- Capture: `operationsInScope`

**VQ3** — conditional
- Prompt: For {operation}: documents per hour, documents per request, document size (min/max/avg), pages per document (min/max/avg), hourly peak, daily peak, and monthly total.
- Condition: `for each operation in VQ2`
- Capture: `volumeProfile[{operation}]`

**VQ4** — sequential
- Prompt: Is your traffic batch-based or live/synchronous?
- Options: Batch — periodic · Live / synchronous · Both
- Capture: `trafficPattern`

**VQ5** — sequential
- Prompt: Are there predictable special-day scenarios where volume exceeds average? For example first day or first week of month, or annual closing.
- Capture: `specialDayScenarios`

**VQ6** — sequential
- Prompt: What volume growth do you anticipate over the next 12 months?
- Capture: `projectedGrowth`

**VQ7** — conditional
- Prompt: How many new users are being onboarded, and what are your minimum, average and peak concurrent user counts?
- Condition: `capabilitySet includes ICMP Viewer (IVaaS) or ICMP UI`
- Capture: `userProfile`

**VQ8** — conditional
- Prompt: I'll help you build an estimate. What comparable system or business projection can we base it on? We'll add a 20-30% buffer on top.
- Condition: `partner answers 'unknown' to any VQ3 field`
- Capture: `estimateBasis, bufferApplied`

---

## Procedure references for this use case

Read the reference before performing its step.

| Reference file | Procedure | Phase | Rules |
|---|---|---|---|
| `04-01_volume-rationale-stakes.md` | Volume Rationale & Stakes | P1 | BR-19, BR-20 |
| `04-02_per-operation-volume-collection.md` | Per-Operation Volume Collection | P1 | BR-19 |
| `04-03_special-day-growth-profiling.md` | Special-Day & Growth Profiling | P1 | BR-19, BR-21 |
| `04-04_ivaas-icmp-ui-user-profiling.md` | IIVaaS / ICMP UI User Profiling | P1 | BR-19 |
| `04-05_estimation-buffer-guidance.md` | Estimation & Buffer Guidance | P1 | BR-19, BR-22 |
| `04-06_capacity-planning-ticket-creation.md` | Capacity Planning Ticket Creation | P3 | BR-19, BR-21 |

---

## Business rules enforced in this use case

- **BR-19** [Volume] Volume must be declared per operation; 'we do not know' is not accepted — an educated estimate plus a 20-30% buffer is required
- **BR-20** [Volume] Exceeding approved and declared volume allows the ICMP platform support team to disable the subscription
- **BR-21** [Volume] Anticipated growth of roughly 5-10% over the declared baseline requires a new LJKX intake before the volume is enabled; uncertainty does not exempt the partner
- **BR-22** [Volume] Load testing (SPLI) must be performed end to end, not ICMP-only

---

## Tools

- **Jira MCP** [AVAILABLE · P3] — create_issue, get_issue
- **Knowledge Base / Confluence** [PHASED · P1 now, P2 target] — return_links, read_and_answer