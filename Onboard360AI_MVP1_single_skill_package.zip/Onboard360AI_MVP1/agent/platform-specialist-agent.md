# Platform Specialist Agent

> **The only agent.** Built on Tachyon SDK. No sub-agents.

---

## Description

The only agent. Built on Tachyon SDK; composes skills from configuration at runtime, exposes local and MCP tools, and enforces real-time contracts before and after every model execution and tool execution.

> Platform-owned. This file declares the ICMP onboarding skill binding only — it is not a redefinition of the Specialist Agent. No sub-agents are defined.

---

## Skills

| Skill | References |
|---|---|
| `onboard360ai` — Onboard360AI, ICMP Partner Onboarding | 137 |

---

## Recommended contract bindings

With sub-agents and skill trees removed, these rules no longer have component boundaries to be
enforced at. Binding them to the Specialist Agent's own interception points keeps them as gates
rather than instructions the model may ignore.

| Rule | Point | Check |
|---|---|---|
| BR-01 | `pre_tool` | Jira get_issue issueKey must match ^LJKX-\d+$ before the call is made. |
| BR-21 | `pre_tool` | Jira create_issue projectKey must be present and must not be LJKX. |
| BR-23 | `post_model` | Opening message must state current integration state and the next phase. |
| scope | `pre_tool` | Only tools declared on the skill may be called. |