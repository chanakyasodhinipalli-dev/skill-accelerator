# ECM Intake — Parallel Skills (v5)

Analysis and discovery for the ECM partner self-service intake run as one loop with four kinds of step:

1. **Split skills** (six analysis sections S1–S6, six discovery categories C1–C6) run in parallel and **only flag gaps**: whether gaps exist, a one-sentence gap summary, the gap fields, and a gap list where each gap says what is wrong (`issue`) and what would close it (`needed`). They never write a question and never talk to anyone.
2. A **merge skill** combines the latest six results into one **gap report**: the master summary of gaps, the master gap list, the follow-up questions, and a **JIRA comment** (Jira wiki markup) that is posted on the JIRA issue and shown in the reviewer view. It writes the questions but never asks them.
3. A **collection skill** is the **only step that talks to the requestor**, as a chat or from a form. It asks every question in the report, catches obvious problems on the spot (TBD, placeholders, a role instead of a person, a missing unit), recaps, and returns an **answer package**. Experts are reached only through the requestor, who passes on their answers.
4. The workflow's **pre-split step** applies the package and re-runs the split skills the answers affect. Anything still open comes back in a new gap report. The loop repeats until the merge returns `READY_TO_PROCEED`.

Every skill exists in **two input versions**:

| Version | Folder | Input on the first check | From the second check on |
|---|---|---|---|
| **VA — question IDs** | `skills/VA-question-id-input/` | Data-capture response keyed by the 46 question IDs | Same |
| **VB — JIRA description** | `skills/VB-jira-description-input/` | The JIRA description (question text + answers, no IDs), read by the workflow before invoking the skills. Each split skill finds its own questions by meaning and returns `extractedAnswers`. | Answers keyed by question ID, built by the pre-split step from `extractedAnswers` (identical to VA), so the `-QID` skills can be used from here on |

![Analysis loop](illustrations/01-analysis-loop.png)

## What changed from v4, and why

| Your answer | What changed | Why |
|---|---|---|
| Gemini, model set to auto | WIRING section 7 is rewritten for Gemini: leave temperature at its default of 1.0 (v4 said 0, which is wrong for Gemini 3), set the maximum output to 65,536 tokens because thinking tokens count against it, use low thinking for the chat step, JSON output mode for split and merge skills, and keep each `SKILL.md` as the unchanged start of the prompt so Gemini's automatic caching applies. `maxQuestions` default 40 → **60**. | Google recommends keeping Gemini 3 at temperature 1.0, because lower values can cause looping or worse results. Gemini 3 Pro and Flash allow 65,536 output tokens, shared with thinking. At 60 questions the biggest sample report needs about 18,220 tokens plus thinking, so a whole first discovery round fits in one report. |
| Form or chat | The collection skills support both. WIRING section 3 shows both set-ups, including which form fields to build from each question. | Chat closes more gaps per round (problems are re-asked on the spot); a form needs no conversation step. |
| Through the requestor | Collect talks only to the requestor: `respondent` and `onlyQuestions` are gone. When the requestor passes on someone's answer, it is recorded with `source` (full name plus employee ID or email). The package's `respondents` / `respondentRef` are replaced by `source`, and the workflow stores the source as the data point's respondent. | Nobody else is contacted. Technical answers stay attributed to a named person, so the discovery check on unidentified technical answers still works. |
| A JIRA comment and the reviewer view | The merges write `jiraComment` (Jira wiki markup) by default. `documentFormat` can also be `markdown`, `both` or `none`. | Markdown headings turn into numbered lists in Jira, so the comment needs wiki markup. Read as plain text in a reviewer view it is still clear. Writing one document instead of two keeps the merge output shorter. |
| Split skills into SKILL.md + references? | **Not adopted.** Each skill stays a single `SKILL.md`. Measured reasons are in the next section. | References only save tokens when a large part of a skill is rarely needed. Here, the part that could be moved costs more to fetch than it saves. |
| Token optimisation | (1) Collect gets only the summary text and the questions, not the whole report. (2) The pre-split step re-runs only the affected split skills. (3) VB can switch to the `-QID` skills after the first check. (4) One document by default. | Numbers in "Where v5 saves tokens" below. |

## Would splitting skills into SKILL.md + references save tokens?

Not for these skills. A reference saves tokens only when it is large and rarely needed, *and* the platform loads it on demand. On-demand loading is one more model turn, which re-sends the whole `SKILL.md` and the input before the model continues. (If ESAGE loads every file of a skill on every call instead, a split saves nothing at all.)

| Skill | Part that could move to a reference | When it's needed | Verdict |
|---|---|---|---|
| Section skills S1–S6 | Nothing in the `-QID` versions: every owned answer is re-checked on every call, so the field rules, quality checks and person checks are always used. In `-JIRA`, the first-check reading section (about 1,221–1,442 tokens). | First check only. | Keep. For VB, call the `-QID` skills from the second check on: the same saving without any extra turn. |
| Category skills C1–C6 | The material used only when a category has no gaps left: Step 4, the requirement templates, the specification fields, the reviews and the result example: 1,551–2,604 tokens, 23%–29% of each skill. | Every call that writes a `categoryResult`. | Keep inline. In the D-P1 sample run, moving it out saves about 13,766 tokens on the calls with gaps, but the 6 result-writing calls each need an extra turn that re-sends about 5,210–7,412 tokens of instructions plus the input: about 43,870 tokens and 6 more model turns. |
| Merge skills | The document templates (about 500 tokens). | Every report with a JIRA comment (the default). | Keep. |
| Collection skills | Anything. | — | Keep. In a chat, text read mid-conversation is re-read on every later turn, so nothing is saved. |

Gemini's automatic caching also works better with whole skills: it discounts a repeated start of the prompt, from 4,096 tokens on Gemini 3.x models. By the characters ÷ 4 estimate, every split skill and merge is above that size on its own, while a slimmed-down core would often fall below it.

## Where v5 saves tokens

Measured on the D-P1 samples (discovery for a 10-service intake: 57 gaps, 56 questions in the first report).

| Change | Before | v5 |
|---|---|---|
| The collection step gets only `summaryText` and `followUpQuestions` | The whole report, about 18,603 tokens, re-read on every chat turn | About 8,503 tokens per turn. Over the roughly 14 turns of the first discovery chat, about 141,400 tokens fewer |
| The pre-split step re-runs only the split skills the answers affect | 18 category calls in three cycles | 13 calls: C5 is kept from cycle 1, and only C1 and C4 run in cycle 3. That is about 42,959 instruction tokens less, plus inputs and outputs |
| VB switches to the `-QID` skills after the first check | `-JIRA` skills every cycle | 1,221–1,442 fewer tokens per section call and about 385 per category call |
| One document by default (`documentFormat: jira`) | (v4: one markdown document) | Same size. Writing both formats would add about 4,424 output tokens to this report |
| Low thinking for the chat step | Default (high) thinking on every chat turn | Faster replies, fewer thinking tokens. The chat only asks and records; the split skills do the judging |

## Package layout

```
README.md                      this file
WIRING-ESAGE.md                how to wire the loop in ESAGE: state, inputs, chat or form, applying packages, re-run rule, Gemini settings
skills/
  VA-question-id-input/
    analysis/   ECMIntakeAnalysis-S1…S6-*-QID, -Merge-QID, -Collect-QID      (8 skills)
    discovery/  ECMIntakeDiscovery-C1…C6-*-QID, -Merge-QID, -Collect-QID     (8 skills)
  VB-jira-description-input/   the same 16 skills, suffix -JIRA
samples/                       92 samples for both versions (88 JSON inputs/outputs + 4 example conversations), index in samples/README.md
tests/ECM_Intake_Parallel_Skills_Test_Scenarios_v5.xlsx   scenarios, inputs (VA answers, VB JIRA text), expected results per skill per cycle, collection tests
illustrations/                 9 diagrams (PNG + SVG)
data-capture/ECM_Business_Intake_Step1_Triage_v6_0.xlsx   the Step 1 question set the IDs come from
```

## Skill catalogue

Instruction sizes are approximate (characters ÷ 4), QID / JIRA. Each folder holds only its `SKILL.md`.

| Stage | Skill (both versions) | Covers | Instruction tokens |
|---|---|---|---|
| analysis | `ECMIntakeAnalysis-S1-RequestorOwnership-QID` / `ECMIntakeAnalysis-S1-RequestorOwnership-JIRA` | Requestor, sponsors, business/governance/ECM teams (9 questions) — flags gaps only | ~6,353 / ~7,691 |
| analysis | `ECMIntakeAnalysis-S2-RequestSummary-QID` / `ECMIntakeAnalysis-S2-RequestSummary-JIRA` | Title, category, tracking IDs, narratives, ECM help (10) — flags gaps only | ~5,972 / ~7,383 |
| analysis | `ECMIntakeAnalysis-S3-ContentUsage-QID` / `ECMIntakeAnalysis-S3-ContentUsage-JIRA` | Content kinds, actions, arrival, consumers, ECM use, volume, sensitivity, retention (10) — flags gaps only | ~6,311 / ~7,753 |
| analysis | `ECMIntakeAnalysis-S4-ImpactValue-QID` / `ECMIntakeAnalysis-S4-ImpactValue-JIRA` | Impact, consequence, benefits, measures (6) — flags gaps only | ~4,875 / ~6,238 |
| analysis | `ECMIntakeAnalysis-S5-TimelineFunding-QID` / `ECMIntakeAnalysis-S5-TimelineFunding-JIRA` | Deadline, date, driver, commitment owner, funding (8) — flags gaps only | ~5,921 / ~7,236 |
| analysis | `ECMIntakeAnalysis-S6-ConnectedSystems-QID` / `ECMIntakeAnalysis-S6-ConnectedSystems-JIRA` | Systems outside ECM and the flow between them (3) — flags gaps only | ~4,478 / ~5,699 |
| analysis | `ECMIntakeAnalysis-Merge-QID` / `ECMIntakeAnalysis-Merge-JIRA` | Combines the latest six outputs into one gap report: master summary, master gap list, follow-up questions, JIRA comment. Talks to no one. | ~4,539 / ~4,537 |
| analysis | `ECMIntakeAnalysis-Collect-QID` / `ECMIntakeAnalysis-Collect-JIRA` | The only step that talks to the requestor (chat or form): asks every question, light checks, recap, answer package. | ~3,722 / ~3,720 |
| discovery | `ECMIntakeDiscovery-C1-CoreOnboarding-QID` / `ECMIntakeDiscovery-C1-CoreOnboarding-JIRA` | core-onboarding — flags gaps only | ~6,761 / ~7,171 |
| discovery | `ECMIntakeDiscovery-C2-SecurityRecords-QID` / `ECMIntakeDiscovery-C2-SecurityRecords-JIRA` | security-compliance, records-retention — flags gaps only | ~7,160 / ~7,540 |
| discovery | `ECMIntakeDiscovery-C3-RepositoryMigration-QID` / `ECMIntakeDiscovery-C3-RepositoryMigration-JIRA` | icmp-repository, content-migration — flags gaps only | ~8,845 / ~9,225 |
| discovery | `ECMIntakeDiscovery-C4-CaptureIntelligence-QID` / `ECMIntakeDiscovery-C4-CaptureIntelligence-JIRA` | content-capture, document-ai, virus-scan — flags gaps only | ~8,137 / ~8,517 |
| discovery | `ECMIntakeDiscovery-C5-OutputCommunications-QID` / `ECMIntakeDiscovery-C5-OutputCommunications-JIRA` | document-generation, print-mail, esignature — flags gaps only | ~8,552 / ~8,932 |
| discovery | `ECMIntakeDiscovery-C6-IntegrationArchitecture-QID` / `ECMIntakeDiscovery-C6-IntegrationArchitecture-JIRA` | api-onboarding, event-integration, solution-architecture, testing-performance — flags gaps only | ~9,850 / ~10,230 |
| discovery | `ECMIntakeDiscovery-Merge-QID` / `ECMIntakeDiscovery-Merge-JIRA` | Combines the latest six outputs into one gap report: master summary, master gap list, follow-up questions, JIRA comment. Talks to no one. | ~5,492 / ~5,490 |
| discovery | `ECMIntakeDiscovery-Collect-QID` / `ECMIntakeDiscovery-Collect-JIRA` | The only step that talks to the requestor (chat or form): asks every question, light checks, recap, answer package. | ~3,765 / ~3,763 |

The merge and collection skills are the same in both versions apart from their names.

## How a cycle runs

1. **Pre-split step** (workflow) builds the input from its state. On the first check it runs all six split skills in parallel; after that, only the ones the answers affect (WIRING section 5).
2. **Merge** gets the latest output of all six (re-run or kept): `READY_TO_PROCEED` ends the stage; `GAPS_OPEN` goes to the collection step and the JIRA comment is posted; `MERGE_ERROR` re-runs the failing skills; discovery also has `RERUN_REQUIRED` (a signal must reach another category first; nobody is asked) and `REJECTED_TO_ANALYSIS`.
3. **Collect**: a chat with the requestor that ends with the answer package as its final message, or one call that checks a form.
4. **Pre-split step** applies the package (answer = replace, add = append, confirm / keepIntake = confirmation, useNew = base correction, `source` = the data point's respondent, pendingWith, skip requests), adds 1 to `cycle`, and goes back to 1.

After analysis returns `READY_TO_PROCEED`, discovery starts with the validated intake. After discovery returns `READY_TO_PROCEED`, the workflow attaches each category's `categoryResult` unchanged and hands over to Human / Accountable Reviews.

## Loading the skills

Each folder under `skills/…/analysis` and `skills/…/discovery` is one skill: upload the folder (it contains only `SKILL.md`). Register both versions if you use VB, because VB switches to the `-QID` skills after the first check.

* Split and merge skills: one call each. Instructions = `SKILL.md`; message = the input JSON; JSON output.
* Collection skills: chat (multi-turn) or form (one call with `interactive: false`). See WIRING section 3.

## Testing

* `tests/…xlsx` — 21 scenarios (analysis A-P1…A-N6, A-J1, A-J2; discovery D-P1…D-N6, D-J1), the exact VA answers and VB JIRA descriptions, the expected gaps per section/category per cycle (including which skills re-run), the expected merge results, and 14 collection tests.
* `samples/` — one complete storyline per stage in both versions (A-P3: gaps → conversation → package → clear; D-P1: 57 gaps → first batch → pause → answers passed on from a named expert → complete), plus negative cases (contradictions, injection, missing and duplicate JIRA questions, form mode, conflict and base correction, unapplied signal, incomplete intake). A03 shows both document formats.

## Assumptions

* **[ASSUMPTION]** ESAGE runs the collection skill either as a chat that ends when the skill's message is a JSON object with `packageType: ECMAnswerPackage`, or as one call for a form. You confirmed both are possible; the end-of-chat signal is what the workflow has to detect.
* **[ASSUMPTION]** The workflow can keep each split skill's last output and run a subset of the six. This matters because re-running only the affected skills is where most of the call savings come from. If it can't, running all six every cycle gives the same result at a higher cost.
* **[ASSUMPTION]** JIRA comments are posted as Jira wiki markup (Jira Data Center, or the Jira Cloud REST API v2). If your connector needs Atlassian Document Format instead, it has to convert the text, or the merge has to use `documentFormat: markdown` with a converter.
* **[ASSUMPTION]** ESAGE lets you set the maximum output tokens and, ideally, the thinking level per step. If auto mode fixes a lower output limit, lower `maxQuestions` (WIRING section 7 has the formula).
* **[ASSUMPTION]** The question unique IDs are the `name` keys of the 46 fields in the v6.0 data-capture workbook, and select answers arrive as option keys. Labels are also accepted and converted.
* **[ASSUMPTION]** Base corrections agreed during discovery (a CONFLICT answered "use the new answer") are not re-validated by analysis.
* Platform values that are still `UNSET` are carried as `FIT_CHECK_PENDING`; setting them later only needs an edit to the **Platform facts** table of the affected category skills.

## Open questions

1. How does ESAGE load extra files in a skill folder: all at once, or when the model asks for one? It doesn't change v5 (there are no references), but it decides whether references are worth revisiting later.
2. Does your JIRA connector take Jira wiki markup for comments (see the assumption above)?

## Verification done

* 32 skill folders, each containing only `SKILL.md`; frontmatter names match the folders; descriptions under 1,024 characters.
* No split skill contains question wording; the merges never route or address anyone; the collection skills take only the summary text and the follow-up questions, and talk only to the requestor.
* Every JSON example inside the skills parses; all sample files parse and match the keys in the skills' examples; every package covers each asked gap once; every JIRA comment and markdown document contains every question.
* Each of the 46 questions and 31 cross-section rules has exactly one owning section; each of the 104 data points and 28 applicability rules has exactly one owning category; the re-run tables in WIRING match the ownership and read lists.
* QID and JIRA merge and collection skills are identical apart from the version label.
* Not yet done: running the skills on Gemini in ESAGE. Use the workbook's expected results for the first run.
