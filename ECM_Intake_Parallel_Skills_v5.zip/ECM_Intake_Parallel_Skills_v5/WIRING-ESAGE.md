# Wiring the loop in ESAGE (v5)

This is the contract between the ESAGE workflow and the 16 skills of one version (VA or VB). The skills are **stateless**. The workflow's **pre-split step** holds everything that must survive between cycles, builds each input, applies each answer package and decides which split skills run.

```
                ┌───────────────────────── answer package (COLLECTED) ◄──────────────────────────┐
                ▼                                                                                 │
   pre-split step ──► affected S1 … S6 / C1 … C6 (parallel, flag gaps) ──► Merge ──► GAPS_OPEN ──► Collect (chat or form) ◄──► requestor
                                                                              │         └──► jiraComment → JIRA issue + reviewer view
                                                                              └──► READY_TO_PROCEED: end of the stage
```

## 1. Who does what

| Step | Does | Never |
|---|---|---|
| Split skills | Check their own questions or data points; flag each gap with `issue` and `needed`; one-sentence `gapSummary`. | Write a question, address the requestor, suggest an answer. |
| Merge | Checks the six outputs; master summary; master gap list; follow-up questions; JIRA comment. | Re-judges a gap; talks to anyone. |
| Collect | Talks only to the requestor; asks every question; light checks with up to two re-asks; recap; answer package. | Contacts anyone else; adds or changes a question; decides a gap is closed; fills in an answer. |
| Pre-split step (workflow) | Holds state; applies the package; runs the affected split skills; stops on `READY_TO_PROCEED`; loop guards. | Edits answers beyond the package rules below. |

## 2. Workflow state (one record per intake)

| Variable | Stage | Holds |
|---|---|---|
| `intakeId`, `version` | both | Reference; `VA` or `VB`. |
| `jiraKey`, `jiraDescription` | both (VB) | Read from JIRA before the first analysis check. |
| `requestor` | both | The requestor's full name and employee ID or email (from the session). |
| `today` | analysis | Today's date, `YYYY-MM-DD` (sent to S5). |
| `cycle` | each stage | Starts at 1; +1 each time an answer package is applied. |
| `answers` | analysis | The 46 answers keyed by question ID (selects as option keys, multiselects as lists). |
| `confirmations` | each stage | `{questionId, rule, reason}` — "keep my answer" replies. |
| `pendingWith` | each stage | `{questionId, person}` — people the requestor named for questions they couldn't answer. |
| `askedGapIds` | each stage | Every gap ID the requestor has been asked about so far (sent to the merge as `previousGapIds`). |
| `skipLog` | each stage | `{gapId, cycle, text}` from each package's `skipRequests` (for the guard in section 6). |
| `lastOutputs` | each stage | The latest output of each of the six split skills. Skills that don't re-run keep theirs, and the merge always gets all six. |
| `lastReport` | each stage | The latest merge output. |
| `intake` | discovery | Frozen copy of `answers` when analysis returns `READY_TO_PROCEED`. |
| `baseCorrections` | discovery | `{questionId: newValue}` agreed in discovery (a CONFLICT answered "use the new answer"). |
| `discoveryAnswers` | discovery | `{"DP-…" or "APPL.<domain>": {value, respondent, cycle}}`; `respondent` = `{fullName, employeeId, email}`. |
| `rerunCount` | discovery | `RERUN_REQUIRED` loops in the current cycle. |

## 3. Analysis loop

**A0 (VB only).** Read the JIRA issue: `jiraKey`, `jiraDescription`.

**A1 — pre-split step.** Cycle 1: run all six section skills in parallel. Later cycles: run only the sections in the re-run set (section 5); the others keep their `lastOutputs`. The same input goes to every section that runs:

```json
{"intakeId": "INT-2026-00957", "cycle": 1, "answers": {"requestorName": "…", "primaryRequestCategory": "regulatoryCommitment", "contentActions": ["store", "retrieve"]},
 "confirmations": [], "pendingWith": [],
 "sessionIdentity": {"fullName": "…", "employeeId": "…", "email": "…"}, "directoryResults": null, "today": "2026-11-25"}
```

`sessionIdentity` and `directoryResults` are read by S1 and S5 only; `today` by S5 only (sending them to all is harmless). VB, cycle 1: run the `-JIRA` skills with `"answers": {}` plus `jiraKey` and `jiraDescription`. From cycle 2 the input is exactly like VA, so run the `-QID` skills (about 1,221–1,442 fewer tokens per call).

**A2 (VB, cycle 1).** Build `answers` from the six outputs' `extractedAnswers`: for each question take `keys` when it is not null (single select → `keys[0]`, multiselect → the list), otherwise `answer`.

**A3 — merge.** Input: `{"intakeId", "cycle", "sectionOutputs": {"S1": …, "S6": …}, "previousGapIds": askedGapIds, "maxQuestions": 60, "documentFormat": "jira"}`, with the latest output of every section, re-run or kept.

**A4 — act on `status`.**

| Status | Do |
|---|---|
| `READY_TO_PROCEED` | Freeze `intake = answers`; post `jiraComment`; start discovery (section 4). |
| `GAPS_OPEN` | Store `lastReport`; post `jiraComment` on the JIRA issue and show it in the reviewer view; go to A5. |
| `MERGE_ERROR` | Re-run the sections in `rerunSections` once with the same input, then merge again. A second failure → hand to the ECM intake coordinator. |

**A5 — collection step.** Run `ECMIntakeAnalysis-Collect` with `SKILL.md` as instructions, in one of two set-ups.

*Chat.* First message:

```json
{"intakeId": "INT-2026-00957", "cycle": 1, "summaryText": <lastReport.masterSummary.text>, "followUpQuestions": <lastReport.followUpQuestions>,
 "requestor": {"fullName": "…", "employeeId": "…", "email": "…"}, "interactive": true}
```

Send only these keys. The gap list and the documents aren't needed, and in a chat everything in the first message is re-read on every turn. Pass each requestor reply as the next message, unchanged. The chat ends when the skill's message is a JSON object with `packageType: ECMAnswerPackage`; show its `closingMessage` to the requestor, never the JSON. If the requestor leaves without finishing, send one more message, `The requestor has had to stop.`, and the skill returns the package with `closedBy: requestor-paused`.

*Form.* Render one field per follow-up question:

| From the question | Form element |
|---|---|
| `group` | Section heading |
| `question`, `answerFormat` | Field label and help text |
| `options` with `answerType` `select` / `multiselect` | Single or multiple choice; otherwise a text box |
| `allowNominee: true` | An extra "Who knows this? (full name plus employee ID or work email)" field |
| `keepAllowed: true` | "Keep my current answer" checkbox plus a reason box (show `currentAnswer`) |
| `namedPerson` | A note: "Waiting for <namedPerson>'s answer" |

Then call the skill once with `"interactive": false` and `"formAnswers"` (plus the same keys as the chat). Put each field's value under the question number, as text: the answer itself, `Who knows: <full name, employee ID or email>`, or (analysis) `Keep: <reason>`; for example `{"1": "Arjun Mehta, E1022918", "4": "Keep: the archive system applies the records schedule"}`. It returns the package straight away; obvious problems are `FLAGGED` instead of re-asked, and the section skills flag them again next cycle.

**A6 — pre-split step: apply the package**, in this order:

| Package item | Change to the state |
|---|---|
| `answers[]`, `mode: answer` | `answers[questionId]` = `keys` if not null (single select → `keys[0]`), else `value`. Remove this question's `confirmations` and `pendingWith`. |
| `mode: add` | Text: append `value` on a new line. Multiselect: add `keys` to the list. Remove this question's `confirmations` and `pendingWith`. |
| `mode: confirm` | For each rule in `rules`: add `{questionId, rule, reason}` to `confirmations`. |
| `source` | Analysis: no state change (it shows whose answer the requestor passed on). |
| `check: FLAGGED` | Apply like any other answer. The section skills flag it again if it still fails; never drop or fix it in the workflow. |
| `pendingWith[]` | Add `{questionId, person}`. |
| `skipRequests[]` | Add to `skipLog`. No change to `answers`. |
| `unanswered[]`, `unmatched[]` | No state change (`unmatched` can be shown to a coordinator). |

Then add every gap ID the package covers (`answers`, `pendingWith`, `unanswered`, `skipRequests`) to `askedGapIds`; `cycle` += 1; work out the re-run set (section 5); go to **A1**. If the re-run set is empty (only skips or nothing answered), go straight to **A3** with the kept outputs.

## 4. Discovery loop

**D1 — pre-split step.** Cycle 1: run all six category skills in parallel. Later cycles: the re-run set (section 5); the others keep their `lastOutputs`.

```json
{"intakeId": "INT-2026-00931", "cycle": 1, "intake": {"…46 answers…": "…"}, "baseCorrections": {}, "discoveryAnswers": {},
 "confirmations": [], "pendingWith": [], "triggers": []}
```

VB cycle 1 uses the `-JIRA` skills and adds `jiraKey` and `jiraDescription`; afterwards copy each output's `extractedAnswers` into `discoveryAnswers` as `{value: answer, respondent: requestor, cycle: 1}` and use the `-QID` skills.

`triggers` for a category = every signal in the **latest** outputs of all categories whose `targetCategory` is that category (send them on every run, not only new ones).

**D2 — merge.** Input: `{"intakeId", "cycle", "categoryOutputs": {"C1": …, "C6": …}, "previousGapIds": askedGapIds, "maxQuestions": 60, "documentFormat": "jira"}`.

| Status | Do |
|---|---|
| `REJECTED_TO_ANALYSIS` | The intake isn't complete (shouldn't happen after analysis). Go back to the analysis loop with the current `answers`. |
| `MERGE_ERROR` | Re-run `rerunCategories` once; second failure → coordinator. |
| `RERUN_REQUIRED` | Add `newTriggers` to the targets' `triggers`, re-run `rerunCategories` **in the same cycle** (nobody is asked), merge again. More than 3 in one cycle → coordinator. |
| `GAPS_OPEN` | Store `lastReport`; post `jiraComment`; collection step (D3). |
| `READY_TO_PROCEED` | Post `jiraComment`; assemble the review package: the merge's `completion` + each category's `categoryResult` **unchanged**. Hand over to Human / Accountable Reviews. |

**D3 — collection step.** As A5, with `ECMIntakeDiscovery-Collect`. The workflow never contacts the people the requestor names. Their items come back in the next report marked "waiting for <name>", and the requestor passes on their answers.

**D4 — pre-split step: apply the package.**

| Package item | Change to the state |
|---|---|
| `mode: answer` | `discoveryAnswers[questionId]` = `{value: keys ?? value, respondent: source ?? requestor, cycle}`. Remove its `pendingWith`. A corrected figure for a conflict arrives as an `answer` for the data point in `conflict.fromDataPoint`. |
| `mode: add` | Append `value` to the existing value; respondent = `source ?? requestor`. |
| `mode: keepIntake` | Add `{questionId, rule: "CONFLICT", reason}` to `confirmations`. |
| `mode: useNew` | `baseCorrections[questionId]` = `value` (it is the conflict's `newValue`); remove any CONFLICT confirmation for it. |
| `FLAGGED`, `pendingWith[]`, `skipRequests[]`, `unanswered[]`, `unmatched[]` | As in analysis. |

`source` is the person whose answer the requestor passed on, as written (full name plus employee ID or work email). Store it as `{fullName, employeeId, email}`; the category skills accept a technical answer only when its respondent is an identified person.

Then update `askedGapIds`; `cycle` += 1; `rerunCount` = 0; work out the re-run set (section 5); go to **D1**.

## 5. Re-run rule

After applying a package, re-run:

1. the **owner** of every gap the package answered, confirmed, kept, corrected or named a person for (the part of the `gapId` before the first dot: `S1`…`S6` or `C1`…`C6`);
2. every split skill that **reads** a question the package changed (tables below);
3. **all six** after a `useNew` base correction (discovery).

Skills outside the set keep their last output, and the merge gets all six. This is safe because the skills are stateless: a skill whose inputs didn't change would return the same result. If ESAGE can't run a subset, run all six every cycle: the result is the same, it just costs more.

**Analysis** — sections that read each question (besides its owner):

| Question | Sections |
|---|---|
| `primaryRequestCategory` | S1, S2, S3, S4, S5 |
| `primaryTrackingId` | S2, S5 |
| `additionalTrackingIds` | S2, S5 |
| `currentBusinessApproach` | S2, S3, S4, S5, S6 |
| `requestNeedAndOutcome` | S2, S3, S4, S5, S6 |
| `ecmSupportDescription` | S2, S3, S4, S6 |
| `contentArrival` | S1, S3, S6 |
| `contentConsumers` | S1, S3, S6 |
| `existingEcmUsage` | S2, S3 |
| `contentSensitivity` | S1, S3 |
| `retentionRequired` | S1, S3 |
| `enterpriseImpact` | S2, S3, S4, S6 |
| `deliveryDriverDetails` | S2, S3, S4, S5, S6 |
| `deadlineConsequence` | S4, S5 |
| `isExternallyCommitted` | S4, S5 |
| `hasNonEcmSystems` | S1, S6 |
| `crossSystemImpactSummary` | S2, S3, S4, S6 |
| every other question | its owner only |

**Discovery** — categories that also read each answer:

| Question | Also |
|---|---|
| `DP-REP-01` | C4 |
| `DP-REP-05` | C6 |
| `DP-CORE-05` | C6 |
| `DP-CORE-06` | C6 |
| `DP-CAP-02` | C6 |
| `DP-GEN-08` | C3 |
| `DP-ES-06` | C2, C3 |
| `DP-API-02` | C4 |
| `APPL.records-retention` | C3, C6 |
| `APPL.icmp-repository` | C6 |
| `APPL.content-migration` | C6 |
| `APPL.content-capture` | C6 |
| `APPL.document-ai` | C6 |
| `APPL.virus-scan` | C6 |
| `APPL.document-generation` | C6 |
| `APPL.print-mail` | C6 |
| `APPL.esignature` | C6 |
| any CONFLICT answered "use the new answer" | all six |

## 6. Guards and hand-offs

| Guard | Suggested value |
|---|---|
| Analysis cycles | 6, then hand to the ECM intake coordinator with `lastReport` (the JIRA comment is already on the issue). |
| Discovery cycles | 8, then hand over the same way. |
| The same gap in `skipLog` in two packages | Hand to the coordinator: the requestor can't or won't provide it. |
| `RERUN_REQUIRED` per cycle | 3. |
| Output not valid JSON | Strip a code fence if there is one; otherwise retry the same call once (optionally adding "Return only the JSON object."). Then let the merge report `MERGE_ERROR`. |
| Output cut off (finish reason `MAX_TOKENS`) | Raise the maximum output tokens, or lower `maxQuestions`, and run the call again. |
| `PENDING` items | They stay open until the requestor passes on the named person's answer. |

## 7. Gemini settings (auto mode)

| Setting | Split skills | Merge | Collect (chat) |
|---|---|---|---|
| Instructions / message | `SKILL.md` / input JSON | `SKILL.md` / input JSON | `SKILL.md` / first message JSON, then the requestor's replies |
| Temperature | Leave at the default (1.0). Google recommends this for Gemini 3; lower values can cause looping or worse results. | Same | Same |
| Thinking level | Default | Default (try `low` if the merge is slow) | `low`: faster replies; the chat only asks and records |
| Maximum output tokens | 65,536 (thinking counts against it; a category result can be long) | 65,536 | Default |
| Output format | JSON mode (`application/json`) if ESAGE offers it | JSON mode | Text (the final message is JSON) |

* **Caching.** Keep `SKILL.md` as the fixed start of every call and the input last. Gemini caches a repeated prompt start automatically (from 4,096 tokens on Gemini 3.x), which makes repeated calls of the same skill cheaper when many intakes run close together.
* **Auto switching.** Google lists Gemini 3 Pro and Gemini 3 Flash with a 1M-token input window and 65,536 output tokens, far more than these calls need. If auto can pick a model with a lower output limit, size `maxQuestions` for that model. Keep the same version of the skills whichever model runs them.
* **Merge output size**, measured on the samples (indented JSON): about 84 tokens per gap in the master gap list, 143 per follow-up question and 79 per question for the JIRA comment, plus about 1,000. The biggest sample (D-P1: 57 gaps, 56 questions) needs about **18,220** tokens with the JIRA comment, 13,796 with `documentFormat: none` and 22,644 with `both`, plus thinking.
* **`maxQuestions`.** If ESAGE fixes a lower output limit, use `(limit − thinking allowance − 1,000 − gaps × 84) ÷ 222`. Gaps past the cap are asked in the next round, so a smaller cap only adds a round; it never loses a gap.
* **Package size.** About 104 tokens per answer, so a 60-question package is under 7,000 tokens.

## 8. Documents: JIRA comment and reviewer view

* `documentFormat: "jira"` (default): `jiraComment` is Jira wiki markup (`h2.` headings, `||` tables, `{{…}}` for question IDs). Post it as a comment on the intake's JIRA issue, and show the same text in the reviewer view: it reads clearly as plain text.
* `documentFormat: "both"`: also writes `document` in markdown, if the reviewer view renders markdown and you want it formatted there. Costs about 4,424 more output tokens in the biggest sample.
* `documentFormat: "none"`: no document. Use this if ESAGE can fill the templates from the JSON itself (the templates are in the merge skills), which costs no model tokens at all.
