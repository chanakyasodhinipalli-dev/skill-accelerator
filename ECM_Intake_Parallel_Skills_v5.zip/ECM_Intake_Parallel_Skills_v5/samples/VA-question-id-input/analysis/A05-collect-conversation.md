# Collection conversation — A-P3, analysis cycle 1

The collection skill asks every question, catches a missing employee ID and a "TBD" on the spot, recaps, and then returns the package.

**Collect skill:**

> Hi Priya. Before intake INT-2026-00957 can move on to discovery, 4 items need your input. You can answer in any order and in your own words; for item 4 you can also name someone who knows.
>
> 1 Requestor and Ownership
> 1. [sponsoringProductOwner] Who is the product owner accountable for scope and priority? Your answer named a relationship ("my manager"); please give the person's full name and their employee ID or work email.
>    Answer format: Full name plus employee ID or work email.
>
> 2 Request Summary
> 2. [primaryTrackingId] This request is driven by a regulatory commitment, so it needs the commitment's tracking ID. What is the ID, and which system is it recorded in?
>    Answer format: The ID exactly as recorded, plus the name of the system it comes from.
> 3. [currentBusinessApproach] You've described what happens today and who does it. What goes wrong or holds you back with the current way of working?
>    Answer format: A few sentences on delays, errors, risks or costs today; include a number if you have one.
>
> 3 Content and Usage
> 4. [contentActions] What needs to happen to the content? This answer decides which ECM services apply, so "not sure" can't be used.
>    Options: Receive or collect it / Store and manage it securely / Search, view, or retrieve it / Automatically classify it or pull data out of it / Create documents from templates or data / Collect signatures / Print and mail it / Keep it for a required period, then dispose of it / Move it from another system / Check it for viruses or malware
>    If you don't know, you can name someone who does: full name plus employee ID or work email.

**Requestor:**

> 1. Arjun Mehta
> 2. TBD, I'll find it later
> 3. Packs take 3 to 5 days to arrive, about 8% are incomplete, and scanned files sit on shared drives without retention controls, which the 2026 regulatory review flagged.
> 4. Receive or collect it; Store and manage it securely; Search, view, or retrieve it; Automatically classify it or pull data out of it; Keep it for a required period, then dispose of it; Check it for viruses or malware

**Collect skill:**

> Thanks, 2 of 4 done. Two quick follow-ups:
> 1. I also need Arjun Mehta's employee ID or work email.
> 2. The tracking ID is needed before the intake can move on to discovery. Do you have it now? It's the ID of the regulatory commitment, plus the system it's recorded in.

**Requestor:**

> E1022918, arjun.mehta@northwindbank.com. The commitment is REG-2026-00417 in the Regulatory Commitments Register.

**Collect skill:**

> Here's what I have:
> 1. Arjun Mehta, E1022918, arjun.mehta@northwindbank.com
> 2. REG-2026-00417, Regulatory Commitments Register
> 3. Added: packs take 3 to 5 days to arrive, about 8% are incomplete…
> 4. Receive, store, retrieve, classify/extract, keep and dispose, malware check
> Is that all correct?

**Requestor:**

> Yes.

**Collect skill:**

> (final message: the answer package in A06-collect-package-COLLECTED.json)
