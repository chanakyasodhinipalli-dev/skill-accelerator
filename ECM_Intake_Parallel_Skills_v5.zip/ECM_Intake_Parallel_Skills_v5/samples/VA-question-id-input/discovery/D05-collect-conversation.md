# Collection conversation — D-P1, discovery cycle 1 (first batch)

The requestor answers the first three P1 items, names the engineering lead for the two technical ones, and pauses.

**Collect skill:**

> Hi Priya. Discovery for INT-2026-00931 has found 10 ECM services for this request, and 56 details are needed before their specifications can be completed. I'll go through them a few at a time; you can answer in any order and in your own words, and for the technical items you can name someone who knows.
>
> Application setup and access
> 1. [DP-CORE-05] Has a scrum team been allocated to deliver this? If so, which team, and what's its Jira project key?
>    Answer format: A team name plus its Jira project key (not LJKX), or "no team allocated".
>    If you don't know, you can name someone who does: full name plus employee ID or work email.
> 2. [DP-CORE-06] Which environments do you need: Innovation, Non-Prod, Production?
>    Answer format: One or more of Innovation, Non-Prod, Production. Production needs Non-Prod, and Non-Prod needs Innovation.
>
> Storing and retrieving documents
> 3. [DP-REP-01 + DP-AI-01] Please list each kind of document you'll store, using the names your business uses, for example the form or letter names.
>    Answer format: One or more specific document names, as your business calls them.
>    One answer covers both.
>
> System connections (APIs)
> 4. [DP-API-02] For each application, what will it do: send or upload documents, search, fetch, update document details, or delete?
>    Answer format: For each application: a list of operations.
>    If you don't know, you can name someone who does: full name plus employee ID or work email.
>
> Overall design
> 5. [DP-SA-01] For the Loan Origination System (LOS): does it send content to ECM, read from ECM, or both? Does it connect by API, events, batch files, or through people using screens?
>    Answer format: For each system: a role plus a connection style.
>    If you don't know, you can name someone who does: full name plus employee ID or work email.

**Requestor:**

> 1. Yes: Mortgage Platform Squad, Jira project MORTP. 2. Innovation, Non-Prod and Production. 3. Mortgage application form, payslips, bank statements, proof-of-identity copies, property valuation report, signed offer letter. 4 and 5: Daniel Brooks, E1040057 knows the LOS side. I have to go to a meeting now; can we continue later?

**Collect skill:**

> (final message: the answer package in D06-collect-package-requestor-paused.json; the workflow shows its closingMessage to Priya)
