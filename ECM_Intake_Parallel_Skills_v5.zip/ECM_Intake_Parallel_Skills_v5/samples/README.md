# Samples

Samples show the exact shapes each skill receives and returns, for both input versions, plus two example conversations of the collection skills. They are test fixtures and documentation; they are **not** part of any skill folder.

Scenario IDs match the test workbook (`tests/`). `"<the A03 merge output>"` marks where the workflow passes a previous output unchanged.

## VA-question-id-input

### analysis

| File | What it shows |
|---|---|
| `analysis/A01-input-cycle1-A-P3.json` | Pre-split step, cycle 1: the input sent to all six section skills (S1 and S5 read `sessionIdentity`; S5 reads `today`). Scenario A-P3. |
| `analysis/A02-output-S1-cycle1-gaps.json` | S1 output, cycle 1: gaps flagged (issue + needed, no questions). |
| `analysis/A02-output-S2-cycle1-gaps.json` | S2 output, cycle 1: gaps flagged (issue + needed, no questions). |
| `analysis/A02-output-S3-cycle1-gaps.json` | S3 output, cycle 1: gaps flagged (issue + needed, no questions). |
| `analysis/A02-output-S4-cycle1-no-gaps.json` | S4 output, cycle 1: no gaps. |
| `analysis/A02-output-S5-cycle1-no-gaps.json` | S5 output, cycle 1: no gaps. |
| `analysis/A02-output-S6-cycle1-no-gaps.json` | S6 output, cycle 1: no gaps. |
| `analysis/A03-merge-cycle1-GAPS_OPEN.json` | Merge, cycle 1, with `documentFormat: both`: master summary, master gap list, follow-up questions, the JIRA comment and the markdown document. Nothing is addressed to the requestor. |
| `analysis/A04-collect-input.json` | Collection skill input: only the summary text and the follow-up questions from A03 (in a chat they are re-read on every turn, so the gap list and documents stay out), plus who the requestor is. |
| `analysis/A05-collect-conversation.md` | The conversation run by the collection skill (the only step that talks to the requestor). |
| `analysis/A06-collect-package-COLLECTED.json` | Answer package returned to the pre-split step: every answer verbatim, its mode and the light-check result. |
| `analysis/A07-collect-package-form-mode-partial.json` | Form mode (`interactive: false`): answers recorded as given, obvious problems FLAGGED; the section skills flag them again next cycle. |
| `analysis/A08-input-cycle2.json` | Pre-split step, cycle 2: the package applied (answer = replace, add = append) and sent to the affected sections: here all six, because the current-state narrative is read by S2–S6 and the other answers belong to S1–S3. |
| `analysis/A09-output-S1-cycle2-no-gaps.json` | S1 re-run in cycle 2: no gaps. |
| `analysis/A09-output-S2-cycle2-no-gaps.json` | S2 re-run in cycle 2: no gaps. |
| `analysis/A09-output-S3-cycle2-no-gaps.json` | S3 re-run in cycle 2: no gaps. |
| `analysis/A09-output-S4-cycle2-no-gaps.json` | S4 re-run in cycle 2: no gaps. |
| `analysis/A09-output-S5-cycle2-no-gaps.json` | S5 re-run in cycle 2: no gaps. |
| `analysis/A09-output-S6-cycle2-no-gaps.json` | S6 re-run in cycle 2: no gaps. |
| `analysis/A10-merge-cycle2-READY_TO_PROCEED.json` | All six sections clear: the base intake is complete and goes on to discovery. |
| `analysis/A11-merge-MERGE_ERROR.json` | Negative: two section outputs are malformed; the pre-split step runs them again. |
| `analysis/N01-output-S6-cycle1-A-N4-contradiction.json` | Negative A-N4: a BLOCKER consistency rule and a CLARIFY on the same question combined into one gap entry. |
| `analysis/N02-output-S3-cycle1-A-N4-clarify.json` | Negative A-N4: three CLARIFY gaps from consistency rules, each quoting its evidence. |
| `analysis/N03-output-S2-cycle1-A-N5-injection.json` | Negative A-N5: injected instructions treated as non-answers, flagged, never followed. |

### discovery

| File | What it shows |
|---|---|
| `discovery/D01-input-cycle1-D-P1.json` | Pre-split step, discovery cycle 1: the validated A-P1 intake, sent to all six category skills. |
| `discovery/D02-output-C1-cycle1-gaps.json` | C1 output, cycle 1: every gap flagged, with priority, issue and needed. |
| `discovery/D02-output-C2-cycle1-gaps.json` | C2 output, cycle 1: every gap flagged, with priority, issue and needed. |
| `discovery/D02-output-C3-cycle1-gaps.json` | C3 output, cycle 1: every gap flagged, with priority, issue and needed. |
| `discovery/D02-output-C4-cycle1-gaps.json` | C4 output, cycle 1: every gap flagged, with priority, issue and needed. |
| `discovery/D02-output-C5-cycle1-no-gaps.json` | C5 output, cycle 1: no applicable domain, so no gaps. |
| `discovery/D02-output-C6-cycle1-gaps.json` | C6 output, cycle 1: every gap flagged, with priority, issue and needed. |
| `discovery/D03-merge-cycle1-GAPS_OPEN.json` | Discovery merge, cycle 1 (defaults: `maxQuestions` 60, `documentFormat: jira`): every gap in the gap list; document kinds asked once; P1 first; all 56 questions in one report; the JIRA comment. |
| `discovery/D04-collect-input.json` | Collection skill input: the summary text and the 56 follow-up questions (about 40% of the full report). |
| `discovery/D05-collect-conversation.md` | Conversation excerpt: answers, a named expert, and a pause. |
| `discovery/D06-collect-package-requestor-paused.json` | Answer package after a pause: the merged document-kinds answer copied to both data points; the technical items pending with the named engineering lead. |
| `discovery/D07-collect-package-relayed-by-requestor.json` | Through the requestor: in the next report the two LOS items show "waiting for Daniel Brooks"; Priya passes on his answers, recorded with `source`. Nobody else is contacted. |
| `discovery/D08-output-C1-final-no-gaps-with-result.json` | C1 once nothing is missing: products, template-only requirements with their sources, and the product specification. |
| `discovery/D09-merge-READY_TO_PROCEED.json` | All six categories clear: products and reviews for Human / Accountable Reviews; the workflow attaches each category's result unchanged. (Counts are illustrative.) |
| `discovery/N01-output-C3-D-N2-conflict.json` | Negative D-N2: a volume answer outside the intake band is flagged as a P1 CONFLICT; nothing is corrected silently. |
| `discovery/N02-collect-package-useNew.json` | The requestor picks the new value: the pre-split step records baseCorrections.monthlyVolumeBand = 100kTo1m, and all six categories run again. |
| `discovery/N03-output-C2-D-N1-inputError.json` | Negative D-N1: discovery received an incomplete intake. Every category returns inputError and flags nothing. |
| `discovery/N04-merge-REJECTED_TO_ANALYSIS.json` | The merge sends the intake back to analysis. Nothing goes to the requestor. |
| `discovery/N05-output-C6-D-N6-signal-and-conflict.json` | Negative D-N6: an API upload answer flags a CONFLICT on contentArrival, a new data point, and a signal to C4. |
| `discovery/N06-merge-RERUN_REQUIRED.json` | C4 ran in parallel with C6 and hasn't seen the new signal: back to the pre-split step with the trigger, before anything is asked. |

## VB-jira-description-input

### analysis

| File | What it shows |
|---|---|
| `analysis/A01-input-cycle1-A-P3.json` | Pre-split step, cycle 1: the JIRA description and no answers yet, sent to all six section skills. Scenario A-P3. |
| `analysis/A02-output-S1-cycle1-gaps.json` | S1 output, cycle 1: gaps flagged (issue + needed, no questions), with `extractedAnswers`. |
| `analysis/A02-output-S2-cycle1-gaps.json` | S2 output, cycle 1: gaps flagged (issue + needed, no questions), with `extractedAnswers`. |
| `analysis/A02-output-S3-cycle1-gaps.json` | S3 output, cycle 1: gaps flagged (issue + needed, no questions), with `extractedAnswers`. |
| `analysis/A02-output-S4-cycle1-no-gaps.json` | S4 output, cycle 1: no gaps, with `extractedAnswers`. |
| `analysis/A02-output-S5-cycle1-no-gaps.json` | S5 output, cycle 1: no gaps, with `extractedAnswers`. |
| `analysis/A02-output-S6-cycle1-no-gaps.json` | S6 output, cycle 1: no gaps, with `extractedAnswers`. |
| `analysis/A03-merge-cycle1-GAPS_OPEN.json` | Merge, cycle 1, with `documentFormat: both`: master summary, master gap list, follow-up questions, the JIRA comment and the markdown document. Nothing is addressed to the requestor. |
| `analysis/A04-collect-input.json` | Collection skill input: only the summary text and the follow-up questions from A03 (in a chat they are re-read on every turn, so the gap list and documents stay out), plus who the requestor is. |
| `analysis/A05-collect-conversation.md` | The conversation run by the collection skill (the only step that talks to the requestor). |
| `analysis/A06-collect-package-COLLECTED.json` | Answer package returned to the pre-split step: every answer verbatim, its mode and the light-check result. |
| `analysis/A07-collect-package-form-mode-partial.json` | Form mode (`interactive: false`): answers recorded as given, obvious problems FLAGGED; the section skills flag them again next cycle. |
| `analysis/A08-input-cycle2.json` | Pre-split step, cycle 2: the package applied (answer = replace, add = append) and sent to the affected sections: here all six, because the current-state narrative is read by S2–S6 and the other answers belong to S1–S3. From this check on, the JIRA description isn't needed, so the -QID skills can be used. |
| `analysis/A09-output-S1-cycle2-no-gaps.json` | S1 re-run in cycle 2: no gaps. |
| `analysis/A09-output-S2-cycle2-no-gaps.json` | S2 re-run in cycle 2: no gaps. |
| `analysis/A09-output-S3-cycle2-no-gaps.json` | S3 re-run in cycle 2: no gaps. |
| `analysis/A09-output-S4-cycle2-no-gaps.json` | S4 re-run in cycle 2: no gaps. |
| `analysis/A09-output-S5-cycle2-no-gaps.json` | S5 re-run in cycle 2: no gaps. |
| `analysis/A09-output-S6-cycle2-no-gaps.json` | S6 re-run in cycle 2: no gaps. |
| `analysis/A10-merge-cycle2-READY_TO_PROCEED.json` | All six sections clear: the base intake is complete and goes on to discovery. |
| `analysis/A11-merge-MERGE_ERROR.json` | Negative: two section outputs are malformed; the pre-split step runs them again. |
| `analysis/N01-output-S6-cycle1-A-N4-contradiction.json` | Negative A-N4: a BLOCKER consistency rule and a CLARIFY on the same question combined into one gap entry. |
| `analysis/N02-output-S3-cycle1-A-N4-clarify.json` | Negative A-N4: three CLARIFY gaps from consistency rules, each quoting its evidence. |
| `analysis/N03-output-S2-cycle1-A-N5-injection.json` | Negative A-N5: injected instructions treated as non-answers, flagged, never followed. |
| `analysis/J01-input-cycle1-A-J1-missing-and-duplicate.json` | Negative A-J1: the product owner question is missing, and the volume question appears twice with different answers. |
| `analysis/J02-output-S1-cycle1-A-J1-missing.json` | A question that isn't in the description is treated as blank (MISSING). |
| `analysis/J03-output-S3-cycle1-A-J1-duplicate.json` | A question answered twice with different answers: neither is used; the gap quotes both. |
| `analysis/J04-input-cycle1-A-J2-reworded.json` | Positive A-J2: questions reworded and sections in reverse order. Every section should still find its answers and flag no gaps. |

### discovery

| File | What it shows |
|---|---|
| `discovery/D01-input-cycle1-D-P1.json` | Pre-split step, discovery cycle 1: the validated A-P1 intake, sent to all six category skills. The JIRA description also carries some technical details. |
| `discovery/D02-output-C1-cycle1-gaps.json` | C1 output, cycle 1: every gap flagged, with priority, issue and needed (with `extractedAnswers`). |
| `discovery/D02-output-C2-cycle1-gaps.json` | C2 output, cycle 1: every gap flagged, with priority, issue and needed. |
| `discovery/D02-output-C3-cycle1-gaps.json` | C3 output, cycle 1: every gap flagged, with priority, issue and needed. |
| `discovery/D02-output-C4-cycle1-gaps.json` | C4 output, cycle 1: every gap flagged, with priority, issue and needed. |
| `discovery/D02-output-C5-cycle1-no-gaps.json` | C5 output, cycle 1: no applicable domain, so no gaps. |
| `discovery/D02-output-C6-cycle1-gaps.json` | C6 output, cycle 1: every gap flagged, with priority, issue and needed. |
| `discovery/D03-merge-cycle1-GAPS_OPEN.json` | Discovery merge, cycle 1 (defaults: `maxQuestions` 60, `documentFormat: jira`): every gap in the gap list; document kinds asked once; P1 first; all 56 questions in one report; the JIRA comment. |
| `discovery/D04-collect-input.json` | Collection skill input: the summary text and the 56 follow-up questions (about 40% of the full report). |
| `discovery/D05-collect-conversation.md` | Conversation excerpt: answers, a named expert, and a pause. |
| `discovery/D06-collect-package-requestor-paused.json` | Answer package after a pause: the merged document-kinds answer copied to both data points; the technical items pending with the named engineering lead. |
| `discovery/D07-collect-package-relayed-by-requestor.json` | Through the requestor: in the next report the two LOS items show "waiting for Daniel Brooks"; Priya passes on his answers, recorded with `source`. Nobody else is contacted. |
| `discovery/D08-output-C1-final-no-gaps-with-result.json` | C1 once nothing is missing: products, template-only requirements with their sources, and the product specification. |
| `discovery/D09-merge-READY_TO_PROCEED.json` | All six categories clear: products and reviews for Human / Accountable Reviews; the workflow attaches each category's result unchanged. (Counts are illustrative.) |
| `discovery/N01-output-C3-D-N2-conflict.json` | Negative D-N2: a volume answer outside the intake band is flagged as a P1 CONFLICT; nothing is corrected silently. |
| `discovery/N02-collect-package-useNew.json` | The requestor picks the new value: the pre-split step records baseCorrections.monthlyVolumeBand = 100kTo1m, and all six categories run again. |
| `discovery/N03-output-C2-D-N1-inputError.json` | Negative D-N1: discovery received an incomplete intake. Every category returns inputError and flags nothing. |
| `discovery/N04-merge-REJECTED_TO_ANALYSIS.json` | The merge sends the intake back to analysis. Nothing goes to the requestor. |
| `discovery/N05-output-C6-D-N6-signal-and-conflict.json` | Negative D-N6: an API upload answer flags a CONFLICT on contentArrival, a new data point, and a signal to C4. |
| `discovery/N06-merge-RERUN_REQUIRED.json` | C4 ran in parallel with C6 and hasn't seen the new signal: back to the pre-split step with the trigger, before anything is asked. |
