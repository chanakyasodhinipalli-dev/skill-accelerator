---
name: ECMIntakeAnalysis-Merge-QID
description: Merges the latest outputs of the six ECM intake section skills (S1–S6, question-ID input version) into one gap report — a master summary of gaps, the master gap list and the follow-up questions, with a JIRA comment and/or markdown document — for the collection step. Writes the questions but never asks them, never addresses the requestor and never re-judges a gap. Status READY_TO_PROCEED when no section has gaps, GAPS_OPEN otherwise, MERGE_ERROR when an output is missing or malformed. Use after every parallel run of the section skills.
---

# ECMIntakeAnalysis-Merge-QID

**Input version:** question-ID answers (QID). The merge works the same way in both versions.

## Your job

Combine the latest outputs of the six section skills into **one gap report**:
- no section has gaps → `READY_TO_PROCEED`: the base intake is complete and goes on to discovery;
- any section has gaps → `GAPS_OPEN`, with three parts: the **master summary of gaps**, the **master gap list**, and the **follow-up questions document**;
- an output is missing or malformed → `MERGE_ERROR`.

You **write** the follow-up questions; you never **ask** them. The collection step, which comes next, is the only step that talks to the requestor. So the report contains no greeting, no "please answer", and no message addressed to anyone: the questions themselves are the only text written for the requestor.

Rules that never change:
1. Never re-check an answer, and never add, drop or change the meaning of a gap. The section skills decide the gaps; you combine them and turn each one into a question.
2. Copy gap IDs, question IDs, gap types, severities, rules, current answers, issues, needed text and allowed values exactly.
3. Never invent facts, examples or values in a question.
4. Output the JSON object only: no code fences, no text before or after it.

## Input

| Key | What it holds |
|---|---|
| `intakeId`, `cycle` | Copy into the output. |
| `sectionOutputs` | An object with keys `S1`…`S6`: the latest output of each section skill. |
| `previousGapIds` | Optional. Gap IDs already put to the requestor in earlier rounds (the workflow keeps this list). |
| `maxQuestions` | Optional, default 60. The most follow-up questions in one report. Gaps beyond it stay in the gap list and get their questions in the next report. |
| `documentFormat` | Optional, default `jira`. Which documents to write: `jira` (`jiraComment`), `markdown` (`document`), `both`, or `none`. A document that isn't asked for is an empty string. |

## Procedure — follow these steps in order

1. **Check the six outputs.** For each of S1–S6:
   - it is present and is a JSON object (ignore a code fence around it);
   - `section` matches its key;
   - it has `gapsExist`, `gapFields`, `gapSummary` and `gaps`;
   - `gapsExist` is `true` exactly when `gaps` is not empty;
   - every gap has `gapId`, `questionId`, `gapType`, `issue` and `needed`.

   On any failure, return `MERGE_ERROR` with `rerunSections` (the failing sections) and `errors` (one plain sentence each), and stop.
2. **All clear?** If all six have `gapsExist: false`, return `READY_TO_PROCEED`: `masterSummary.text` = "No gaps. The base intake is complete and can go on to discovery.", totals of 0, empty `gapList` and `followUpQuestions`, and the short documents. Stop.
3. **Master gap list.** Take every gap from every section, in section order (S1 to S6) and then in the order each section gave. If two gaps have the same `gapId`, keep the first. Each entry has only `gapId`, `gapType`, `severity`, `issue` and `needed` (copied) and `inThisRound`: `true` for the first `maxQuestions` gaps, `false` for the rest. The gap's other keys are used only in its question; keeping the list short keeps the report fast to write.
4. **Follow-up questions.** For every gap with `inThisRound: true`, in list order, write one question (see **Writing the follow-up questions**). Number them from 1. Each question also gets `group`, the section name (S1 `1 Requestor and Ownership`, S2 `2 Request Summary`, S3 `3 Content and Usage`, S4 `4 Impact and Value`, S5 `5 Timeline and Funding`, S6 `6 Connected Systems`), and `askedBefore`: `true` if its `gapId` is in `previousGapIds`.
5. **Master summary.** `text`: two to four sentences — how many gaps, how many blocking and how many to clarify, which sections, the main themes in plain words, and that the intake can't go on to discovery until the blocking gaps are closed. `totals`: `gaps`, `blocking`, `toClarify`. `byArea`: one row per section (`area` = section name, `gaps`, `blocking`, `toClarify`), all six. `inThisRound` and `notInThisRound`: how many gaps are and aren't covered by this report's questions; `askedBefore`: how many of this report's questions have `askedBefore: true`.
6. **Documents.** Write the documents that `documentFormat` asks for, from **Document templates**.
7. `infoNotes`: every section's infoNotes, each prefixed with its section code, e.g. `S1: sponsoringArchitect not yet assigned`.

## Writing the follow-up questions

Write **one follow-up question per gap**, from that gap's `issue`, `needed`, `currentAnswer` and `allowedValues`, and nothing else.

| gapType | How to write the question |
|---|---|
| `MISSING` | Ask for what `needed` describes. |
| `INVALID` | One short clause on what is wrong (from `issue`), then ask for what `needed` describes. |
| `CLARIFY` | State the mismatch from `issue` (keep its quotes and figures), then ask which is right, or whether they want to keep the current answer and say why. |
| `NOT_SURE` | Say in a few words why the answer matters (from `issue`), then ask for what `needed` describes. |
| `PENDING` | Say that `namedPerson` was named for this and that their answer is still needed; ask for it. |

Rules for every question:
- Plain business words a requestor understands without knowing the intake rules. Address them as "you". At most about 40 words.
- Ask only for what `needed` describes; when `needed` names only a missing part, ask only for that part.
- Never invent example names, IDs, dates, numbers or values. Use only what is in `issue`, `needed`, `currentAnswer` and `allowedValues`.
- Never mention rule IDs, gap IDs, question IDs, configuration keys, skill names or sections' internal workings.
- `answerFormat`: what a complete answer contains, from `needed`, in plain words (for example "Full name plus employee ID or work email.").
- `options`: copy `allowedValues` exactly, or `[]`.

Each `followUpQuestions` entry: `number`, `gapId`, `questionId`, `relatedQuestionIds`, `group`, `gapType`, `rules`, `currentAnswer`, `question`, `answerFormat`, `answerType`, `options`, `allowNominee` (copy), `keepAllowed` (`true` for `CLARIFY`: the current answer may be kept with a reason of at least five words), `namedPerson` (copy), `askedBefore`.

## Document templates

Both documents hold the same content; only the markup differs.

**`jiraComment`** (Jira wiki markup; posted as a JIRA comment and shown in the reviewer view). In text you copy into it, write `[`, `]`, `{`, `}` and `|` as `\[`, `\]`, `\{`, `\}` and `\|`, so Jira doesn't read them as links, macros or table cells.

````
h2. ECM intake gap report — <intakeId> — analysis check <cycle>

h3. Summary

<masterSummary.text>

||Area||Gaps||Blocking||To clarify||
|<one row per section>|

h3. Gaps

||#||Gap ID||Type||Severity||Issue||
|<one row per gapList entry>|

h3. Follow-up questions

h4. <group>

*<number>.* {{<questionId>}} <question>
* Answer format: <answerFormat>
* Options: <label> / <label>                                   (only with options)
* Current answer: "<currentAnswer>" (can be kept with a reason) (only when keepAllowed)
* Can be answered by naming someone who knows: full name plus employee ID or work email   (only when allowNominee)
* Waiting for: <namedPerson>                                    (only for PENDING)
* Asked before                                                  (only when askedBefore)
````

**`document`** (markdown):

````
# ECM intake gap report — <intakeId> — analysis check <cycle>

## Summary

<masterSummary.text>

| Area | Gaps | Blocking | To clarify |
|---|---|---|---|
| <one row per section> |

## Gaps

| # | Gap ID | Type | Severity | Issue |
|---|---|---|---|---|
| <one row per gapList entry> |

## Follow-up questions

### <group>

**<number>. [<questionId>]** <question>
- Answer format: <answerFormat>
- Options: <label> / <label>                                   (only with options)
- Current answer: "<currentAnswer>" (can be kept with a reason) (only when keepAllowed)
- Can be answered by naming someone who knows: full name plus employee ID or work email   (only when allowNominee)
- Waiting for: <namedPerson>                                    (only for PENDING)
- Asked before                                                  (only when askedBefore)
````

For `READY_TO_PROCEED`: the title, the Summary heading and the summary text only. For `MERGE_ERROR`: empty strings.

## Output

Return one JSON object with these keys:
- `reportType`: `ECMGapReport`.
- `stage`: `analysis`.
- `intakeId`, `cycle`, `status` (`GAPS_OPEN`, `READY_TO_PROCEED` or `MERGE_ERROR`).
- `masterSummary`: `text`, `totals`, `byArea`, `inThisRound`, `notInThisRound`, `askedBefore`.
- `gapList`: the master gap list (step 3); `[]` unless `GAPS_OPEN`.
- `followUpQuestions`: step 4; `[]` unless `GAPS_OPEN`.
- `jiraComment` and `document`: step 6.
- `rerunSections` and `errors`: only for `MERGE_ERROR`; otherwise `[]`.
- `infoNotes`.

Example — four gaps in three sections:

```json
{
 "reportType": "ECMGapReport",
 "stage": "analysis",
 "intakeId": "INT-2026-00957",
 "cycle": 1,
 "status": "GAPS_OPEN",
 "masterSummary": {
  "text": "4 gaps in 3 of the 6 sections: 3 blocking and 1 to clarify. The product owner is given as a relationship instead of a named person, the audit finding's tracking ID is a placeholder, the description of today's process doesn't say what goes wrong, and the retention answer doesn't match the selected actions. The intake can't go on to discovery until the blocking gaps are closed.",
  "totals": {"gaps": 4, "blocking": 3, "toClarify": 1},
  "byArea": [
   {"area": "1 Requestor and Ownership", "gaps": 1, "blocking": 1, "toClarify": 0},
   {"area": "2 Request Summary", "gaps": 2, "blocking": 2, "toClarify": 0},
   {"area": "3 Content and Usage", "gaps": 1, "blocking": 0, "toClarify": 1},
   {"area": "4 Impact and Value", "gaps": 0, "blocking": 0, "toClarify": 0},
   {"area": "5 Timeline and Funding", "gaps": 0, "blocking": 0, "toClarify": 0},
   {"area": "6 Connected Systems", "gaps": 0, "blocking": 0, "toClarify": 0}
  ],
  "inThisRound": 4,
  "notInThisRound": 0,
  "askedBefore": 0
 },
 "gapList": [
  {
   "gapId": "S1.sponsoringProductOwner",
   "gapType": "INVALID",
   "severity": "BLOCKER",
   "issue": "The answer names a relationship, not a person.",
   "needed": "the product owner accountable for scope and priority: full name plus employee ID or work email.",
   "inThisRound": true
  },
  {
   "gapId": "S2.primaryTrackingId",
   "gapType": "INVALID",
   "severity": "BLOCKER",
   "issue": "\"TBD\" is a placeholder, not a tracking ID. The request is driven by an audit finding, so it needs the authoritative ID.",
   "needed": "the authoritative tracking ID for the audit finding, plus the system it comes from.",
   "inThisRound": true
  },
  {
   "gapId": "S2.currentBusinessApproach",
   "gapType": "INVALID",
   "severity": "BLOCKER",
   "issue": "The description says what happens today and who does it, but not what goes wrong or what it costs, and it is shorter than the 40 meaningful words needed.",
   "needed": "only the missing part: what goes wrong or limits the current way of working (for example delays, errors, risk or cost).",
   "inThisRound": true
  },
  {
   "gapId": "S3.retentionRequired",
   "gapType": "CLARIFY",
   "severity": "CLARIFY",
   "issue": "The content must be kept for a set period, but \"Keep it for a required period, then dispose of it\" isn't selected in what needs to happen to the content.",
   "needed": "whether keeping the content for the required period, then disposing of it, is in scope: if so, that action added; if not, a reason to keep the answers as they are.",
   "inThisRound": true
  }
 ],
 "followUpQuestions": [
  {
   "number": 1,
   "gapId": "S1.sponsoringProductOwner",
   "questionId": "sponsoringProductOwner",
   "relatedQuestionIds": [],
   "group": "1 Requestor and Ownership",
   "gapType": "INVALID",
   "rules": ["PERSON"],
   "currentAnswer": "my manager",
   "question": "Who is the product owner accountable for scope and priority? Your answer named a relationship (\"my manager\"); please give the person's full name and their employee ID or work email.",
   "answerFormat": "Full name plus employee ID or work email.",
   "answerType": "person",
   "options": [],
   "allowNominee": false,
   "keepAllowed": false,
   "namedPerson": null,
   "askedBefore": false
  },
  {
   "number": 2,
   "gapId": "S2.primaryTrackingId",
   "questionId": "primaryTrackingId",
   "relatedQuestionIds": [],
   "group": "2 Request Summary",
   "gapType": "INVALID",
   "rules": ["FIELD", "Q1"],
   "currentAnswer": "TBD",
   "question": "This request is driven by an audit finding, so it needs the finding's tracking ID. \"TBD\" can't be used: what is the ID, and which system is it recorded in?",
   "answerFormat": "The ID exactly as recorded, plus the name of the system it comes from.",
   "answerType": "text",
   "options": [],
   "allowNominee": false,
   "keepAllowed": false,
   "namedPerson": null,
   "askedBefore": false
  },
  {
   "number": 3,
   "gapId": "S2.currentBusinessApproach",
   "questionId": "currentBusinessApproach",
   "relatedQuestionIds": [],
   "group": "2 Request Summary",
   "gapType": "INVALID",
   "rules": ["FIELD", "Q6"],
   "currentAnswer": "Auditors request loan files by email and the records team searches shared drives and archive boxes to find them, then sends copies back.",
   "question": "You've described what happens today and who does it. What goes wrong or holds you back with the current way of working?",
   "answerFormat": "A few sentences on delays, errors, risks or costs today; include a number if you have one.",
   "answerType": "textarea",
   "options": [],
   "allowNominee": false,
   "keepAllowed": false,
   "namedPerson": null,
   "askedBefore": false
  },
  {
   "number": 4,
   "gapId": "S3.retentionRequired",
   "questionId": "retentionRequired",
   "relatedQuestionIds": ["contentActions"],
   "group": "3 Content and Usage",
   "gapType": "CLARIFY",
   "rules": ["XF-C4"],
   "currentAnswer": "Yes",
   "question": "You said the content must be kept for a set period, but keeping it and then disposing of it isn't one of the selected actions. Is that part of this request? If yes, it will be added to the actions; if not, you can keep your answers as they are and say why.",
   "answerFormat": "Yes or No. To keep the answers as they are, a reason of at least five words.",
   "answerType": "select",
   "options": [{"label": "Yes", "key": "yes"}, {"label": "No", "key": "no"}],
   "allowNominee": false,
   "keepAllowed": true,
   "namedPerson": null,
   "askedBefore": false
  }
 ],
 "jiraComment": "h2. ECM intake gap report — INT-2026-00957 — analysis check 1\n\nh3. Summary\n\n4 gaps in 3 of the 6 sections: 3 blocking and 1 to clarify. The product owner is given as a relationship instead of a named person, the audit finding's tracking ID is a placeholder, the description of today's process doesn't say what goes wrong, and the retention answer doesn't match the selected actions. The intake can't go on to discovery until the blocking gaps are closed.\n\n||Area||Gaps||Blocking||To clarify||\n|1 Requestor and Ownership|1|1|0|\n|2 Request Summary|2|2|0|\n|3 Content and Usage|1|0|1|\n|4 Impact and Value|0|0|0|\n|5 Timeline and Funding|0|0|0|\n|6 Connected Systems|0|0|0|\n\nh3. Gaps\n\n||#||Gap ID||Type||Severity||Issue||\n|1|S1.sponsoringProductOwner|INVALID|BLOCKER|The answer names a relationship, not a person.|\n|2|S2.primaryTrackingId|INVALID|BLOCKER|\"TBD\" is a placeholder, not a tracking ID. The request is driven by an audit finding, so it needs the authoritative ID.|\n|3|S2.currentBusinessApproach|INVALID|BLOCKER|The description says what happens today and who does it, but not what goes wrong or what it costs, and it is shorter than the 40 meaningful words needed.|\n|4|S3.retentionRequired|CLARIFY|CLARIFY|The content must be kept for a set period, but \"Keep it for a required period, then dispose of it\" isn't selected in what needs to happen to the content.|\n\nh3. Follow-up questions\n\nh4. 1 Requestor and Ownership\n\n*1.* {{sponsoringProductOwner}} Who is the product owner accountable for scope and priority? Your answer named a relationship (\"my manager\"); please give the person's full name and their employee ID or work email.\n* Answer format: Full name plus employee ID or work email.\n\nh4. 2 Request Summary\n\n*2.* {{primaryTrackingId}} This request is driven by an audit finding, so it needs the finding's tracking ID. \"TBD\" can't be used: what is the ID, and which system is it recorded in?\n* Answer format: The ID exactly as recorded, plus the name of the system it comes from.\n\n*3.* {{currentBusinessApproach}} You've described what happens today and who does it. What goes wrong or holds you back with the current way of working?\n* Answer format: A few sentences on delays, errors, risks or costs today; include a number if you have one.\n\nh4. 3 Content and Usage\n\n*4.* {{retentionRequired}} You said the content must be kept for a set period, but keeping it and then disposing of it isn't one of the selected actions. Is that part of this request? If yes, it will be added to the actions; if not, you can keep your answers as they are and say why.\n* Answer format: Yes or No. To keep the answers as they are, a reason of at least five words.\n* Options: Yes / No\n* Current answer: \"Yes\" (can be kept with a reason)\n",
 "document": "",
 "rerunSections": [],
 "errors": [],
 "infoNotes": []
}
```
