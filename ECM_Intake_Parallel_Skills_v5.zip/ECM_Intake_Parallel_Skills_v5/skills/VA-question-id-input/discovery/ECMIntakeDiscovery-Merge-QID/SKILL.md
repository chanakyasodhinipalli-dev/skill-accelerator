---
name: ECMIntakeDiscovery-Merge-QID
description: Merges the outputs of the six ECM discovery category skills (C1–C6, question-ID input version) into one gap report — a master summary of gaps with the services found, the master gap list and the follow-up questions, with a JIRA comment and/or markdown document — for the collection step. Writes the questions but never asks them, never addresses the requestor and never re-judges a gap. Statuses: READY_TO_PROCEED (no gaps; completion summary for Human / Accountable Reviews), GAPS_OPEN, RERUN_REQUIRED (a signal must reach another category first), REJECTED_TO_ANALYSIS, MERGE_ERROR. Use after every parallel run of the category skills.
---

# ECMIntakeDiscovery-Merge-QID

**Input version:** question-ID answers (QID). The merge works the same way in both versions.

## Your job

Combine the latest outputs of the six discovery category skills into **one gap report**. The status is one of:
- `REJECTED_TO_ANALYSIS`: a category reported an `inputError`; the base intake isn't complete, so it goes back to analysis.
- `MERGE_ERROR`: an output is missing or malformed.
- `RERUN_REQUIRED`: a category sent a signal that its target category hasn't seen yet; the workflow re-runs the categories before anything is asked.
- `READY_TO_PROCEED`: no category has gaps; you write the completion summary for Human / Accountable Reviews.
- `GAPS_OPEN`: gaps remain; you write three parts: the **master summary of gaps**, the **master gap list**, and the **follow-up questions document**.

You **write** the follow-up questions; you never **ask** them. The collection step, which comes next, is the only step that talks to the requestor. So the report contains no greeting, no "please answer", and no message addressed to anyone: the questions themselves are the only text written for the requestor.

Rules that never change:
1. Never re-check an answer, and never add, drop or change the meaning of a gap. Never copy the categories' requirements or specifications into your output; the workflow attaches each category's `categoryResult` unchanged.
2. Copy gap IDs, question IDs, gap types, severities, priorities, rules, current answers, issues, needed text, allowed values and conflicts exactly.
3. Never invent facts, examples or values in a question.
4. Output the JSON object only: no code fences, no text before or after it.

## Input

| Key | What it holds |
|---|---|
| `intakeId`, `cycle` | Copy into the output. |
| `categoryOutputs` | An object with keys `C1`…`C6`: each category's latest output. |
| `previousGapIds` | Optional. Gap IDs already put to the requestor in earlier rounds (the workflow keeps this list). |
| `maxQuestions` | Optional, default 60. The most follow-up questions in one report. Gaps beyond it stay in the gap list and get their questions in the next report. |
| `documentFormat` | Optional, default `jira`. Which documents to write: `jira` (`jiraComment`), `markdown` (`document`), `both`, or `none`. A document that isn't asked for is an empty string. |

## Procedure — follow these steps in order

1. **Check the six outputs.** For each of C1–C6:
   - it is present and is a JSON object (ignore a code fence around it);
   - `category` matches its key;
   - it has `domainStatus`, `gapsExist` and `gaps`;
   - `gapsExist` is `true` exactly when `gaps` is not empty;
   - when `gapsExist` is `false` and `inputError` is `null`, `categoryResult` is an object.

   On any failure, return `MERGE_ERROR` with `rerunCategories` and `errors`, and stop.
2. **Input errors.** If any category has a non-null `inputError`, return `REJECTED_TO_ANALYSIS` with `errors` (each category's `inputError`, prefixed with its code), and stop.
3. **Signals.** A signal is seen when its target category's output lists its `signalId` in `triggersApplied`. If any signal is not seen, return `RERUN_REQUIRED` with `rerunCategories` (the target categories) and `newTriggers` (the unseen signals), and stop.
4. **All clear?** If all six have `gapsExist: false`, return `READY_TO_PROCEED` with `completion`:
   - `productsRequired` and `productsNotRequired`: the union from all `categoryResult`s, each entry copied as given;
   - `reviewsRequired`: the union, de-duplicated by review name;
   - `requirementCount` and `fitCheckCount`: totals across categories;
   - `assembleFrom`: `["C1","C2","C3","C4","C5","C6"]`.

   Also write `masterSummary` (services found, no gaps) and the short documents. Stop.
5. **Master gap list.** Take every gap from every category: P1 gaps first, then P2; within a priority, C1 to C6; within a category, the order given. If two gaps have the same `gapId`, keep the first. Each entry has only `gapId`, `priority`, `gapType`, `severity`, `issue` and `needed` (copied) and `inThisRound` (see step 6). The gap's other keys are used only in its question; keeping the list short keeps the report fast to write.
6. **Follow-up questions.** Group the list into questions:
   - gaps with the same non-null `dedupKey` become **one** question, placed at the first of them (for example `C3.DP-REP-01` and `C4.DP-AI-01`, both `documentKinds`, become one question with `questionIds` `["DP-REP-01","DP-AI-01"]`); it is P1 if any of them is P1;
   - every other gap is its own question.

   Take the first `maxQuestions` questions; their gaps get `inThisRound: true`, all others `false`. Write each question (see **Writing the follow-up questions**) and number them from 1. Each question takes `group`, `gapType`, `rules`, `currentAnswer`, `answerType`, `allowedValues` (as `options`), `respondent`, `allowNominee`, `conflict` and `namedPerson` from its first gap, and `askedBefore`: `true` if any of its gap IDs is in `previousGapIds`.
7. **Master summary.** `text`: two to four sentences — how many services apply (and how many are still candidates), how many gaps are open, how many are P1, the main themes in plain words, and that discovery can't finish until they are closed. `totals`: `gaps`, `blocking`, `toClarify`, `p1`. `byArea`: one row per category (`area` = code and name, `gaps`, `blocking`, `toClarify`), all six. `services`: every domain from every `domainStatus` (`domain`, `name`, `status`). `inThisRound` and `notInThisRound`: how many gaps are and aren't covered by this report's questions; `askedBefore`: how many of this report's questions have `askedBefore: true`.
8. **Documents.** Write the documents that `documentFormat` asks for, from **Document templates** (with the services table under the summary).
9. `infoNotes`: every category's infoNotes, prefixed with its code.

## Writing the follow-up questions

Write **one follow-up question per gap** (gaps merged by `dedupKey` share one question), from that gap's `issue`, `needed`, `currentAnswer` and `allowedValues`, and nothing else.

| gapType | How to write the question |
|---|---|
| `MISSING` | Ask for what `needed` describes. |
| `INVALID` | One short clause on what is wrong (from `issue`), then ask for what `needed` describes. |
| `CLARIFY` | State the mismatch from `issue` (keep its quotes and figures), then ask for an answer that removes the doubt (in discovery the current answer can't simply be kept). |
| `NOT_SURE` | Say in a few words why the answer matters (from `issue`), then ask for what `needed` describes. |
| `PENDING` | Say that `namedPerson` was named for this and that their answer is still needed; ask for it. |
| `CONFLICT` | Give both values in plain words with the evidence from `issue` (keep its figures), then ask which is right. `options`: the two `allowedValues`; say that a corrected value is also fine. |
| applicability (`APPL.<domain>`) | Ask the yes/no question that `needed` describes; if yes, ask for a short description of what it involves. |

Rules for every question:
- Plain business words a requestor understands without knowing the intake rules. Address them as "you". At most about 40 words.
- Ask only for what `needed` describes; when `needed` names only a missing part, ask only for that part.
- Never invent example names, IDs, dates, numbers or values. Use only what is in `issue`, `needed`, `currentAnswer` and `allowedValues`.
- Never mention rule IDs, gap IDs, question IDs, configuration keys, skill names or sections' internal workings.
- `answerFormat`: what a complete answer contains, from `needed`, in plain words (for example "Full name plus employee ID or work email.").
- `options`: copy `allowedValues` exactly, or `[]`.

Each `followUpQuestions` entry: `number`, `gapIds`, `questionIds`, `group`, `gapType`, `rules`, `currentAnswer`, `question`, `answerFormat`, `answerType`, `options`, `respondent`, `allowNominee`, `conflict`, `namedPerson`, `askedBefore`. (There is no keep option in discovery other than a conflict's "keep the intake answer": a doubtful answer needs a clearer one.)

## Document templates

Both documents hold the same content; only the markup differs.

**`jiraComment`** (Jira wiki markup; posted as a JIRA comment and shown in the reviewer view). In text you copy into it, write `[`, `]`, `{`, `}` and `|` as `\[`, `\]`, `\{`, `\}` and `\|`, so Jira doesn't read them as links, macros or table cells.

````
h2. ECM intake gap report — <intakeId> — discovery check <cycle>

h3. Summary

<masterSummary.text>

||Service||Status||
|<one row per services entry>|

||Area||Gaps||Blocking||To clarify||
|<one row per category>|

h3. Gaps

||#||Gap ID||Type||Severity||Issue||
|<one row per gapList entry>|

h3. Follow-up questions

h4. <group>

*<number>.* {{<questionIds joined with " + ">}} <question>
* Answer format: <answerFormat>
* Options: <label> / <label>                                   (only with options)
* Can be answered by naming someone who knows: full name plus employee ID or work email   (only when allowNominee)
* Waiting for: <namedPerson>                                    (only for PENDING)
* Asked before                                                  (only when askedBefore)
````

**`document`** (markdown):

````
# ECM intake gap report — <intakeId> — discovery check <cycle>

## Summary

<masterSummary.text>

| Service | Status |
|---|---|
| <one row per services entry> |

| Area | Gaps | Blocking | To clarify |
|---|---|---|---|
| <one row per category> |

## Gaps

| # | Gap ID | Type | Severity | Issue |
|---|---|---|---|---|
| <one row per gapList entry> |

## Follow-up questions

### <group>

**<number>. [<questionIds joined with " + ">]** <question>
- Answer format: <answerFormat>
- Options: <label> / <label>                                   (only with options)
- Can be answered by naming someone who knows: full name plus employee ID or work email   (only when allowNominee)
- Waiting for: <namedPerson>                                    (only for PENDING)
- Asked before                                                  (only when askedBefore)
````

For `READY_TO_PROCEED`: the title, the Summary heading, the summary text and the services table. For `MERGE_ERROR`, `RERUN_REQUIRED` and `REJECTED_TO_ANALYSIS`: empty strings.

## Output

Return one JSON object with these keys:
- `reportType`: `ECMGapReport`.
- `stage`: `discovery`.
- `intakeId`, `cycle`, `status`.
- `masterSummary`: `text`, `totals`, `byArea`, `services`, `inThisRound`, `notInThisRound`, `askedBefore` (for `READY_TO_PROCEED` too).
- `gapList`, `followUpQuestions`: `[]` unless `GAPS_OPEN`.
- `jiraComment` and `document`: step 8.
- `completion`: only for `READY_TO_PROCEED`; otherwise `null`.
- `rerunCategories` and `newTriggers`: only for `RERUN_REQUIRED` or `MERGE_ERROR`; otherwise `[]`.
- `errors`, `infoNotes`.

Example — second check of a small intake (engineering documents uploaded by staff):

```json
{
 "reportType": "ECMGapReport",
 "stage": "discovery",
 "intakeId": "INT-2026-01022",
 "cycle": 2,
 "status": "GAPS_OPEN",
 "masterSummary": {
  "text": "7 ECM services apply and 8 don't. 4 gaps are open in 3 categories, all blocking; 1 is a P1 conflict between the intake's volume band and the volumes given. A production support contact, how documents are looked up, and the availability need (waiting for Laura Chen) are still missing. Discovery can't finish until these are closed.",
  "totals": {"gaps": 4, "blocking": 4, "toClarify": 0, "p1": 1},
  "byArea": [
   {"area": "C1 Core Onboarding and Environments", "gaps": 1, "blocking": 1, "toClarify": 0},
   {"area": "C2 Security, Compliance and Records", "gaps": 0, "blocking": 0, "toClarify": 0},
   {"area": "C3 Repository and Migration", "gaps": 2, "blocking": 2, "toClarify": 0},
   {
    "area": "C4 Capture, Document Intelligence and Malware Scanning",
    "gaps": 0,
    "blocking": 0,
    "toClarify": 0
   },
   {"area": "C5 Output and Communications", "gaps": 0, "blocking": 0, "toClarify": 0},
   {"area": "C6 Integration, Architecture and Testing", "gaps": 1, "blocking": 1, "toClarify": 0}
  ],
  "services": [
   {"domain": "core-onboarding", "name": "Core onboarding", "status": "APPLICABLE"},
   {"domain": "security-compliance", "name": "Security and compliance", "status": "APPLICABLE"},
   {"domain": "icmp-repository", "name": "ICMP repository", "status": "APPLICABLE"},
   {"domain": "content-capture", "name": "Content capture", "status": "APPLICABLE"},
   {"domain": "virus-scan", "name": "Virus scanning", "status": "APPLICABLE"},
   {"domain": "solution-architecture", "name": "Solution architecture", "status": "APPLICABLE"},
   {"domain": "testing-performance", "name": "Testing and performance", "status": "APPLICABLE"},
   {"domain": "print-mail", "name": "Print and mail", "status": "NOT_APPLICABLE"},
   {"domain": "records-retention", "name": "Records and retention", "status": "NOT_APPLICABLE"},
   {"domain": "content-migration", "name": "Content migration", "status": "NOT_APPLICABLE"},
   {"domain": "document-ai", "name": "Document AI / iDocs", "status": "NOT_APPLICABLE"},
   {"domain": "document-generation", "name": "Document generation", "status": "NOT_APPLICABLE"},
   {"domain": "esignature", "name": "eSignature", "status": "NOT_APPLICABLE"},
   {"domain": "api-onboarding", "name": "API onboarding", "status": "NOT_APPLICABLE"},
   {"domain": "event-integration", "name": "Event integration", "status": "NOT_APPLICABLE"}
  ],
  "inThisRound": 4,
  "notInThisRound": 0,
  "askedBefore": 1
 },
 "gapList": [
  {
   "gapId": "C3.CONFLICT.monthlyVolumeBand",
   "priority": "P1",
   "gapType": "CONFLICT",
   "severity": "BLOCKER",
   "issue": "The intake says under 10,000 items a month, but the volume answer, about 900 documents a working day, comes to about 19,800 a month (900 × 22).",
   "needed": "which is right: the intake band, the new figure (10,000 to 100,000 a month), or a corrected figure.",
   "inThisRound": true
  },
  {
   "gapId": "C1.DP-CORE-11",
   "priority": "P2",
   "gapType": "MISSING",
   "severity": "BLOCKER",
   "issue": "Production is one of the environments needed, so a production support contact is required, and none has been given yet.",
   "needed": "the team that will support this in Production, plus a named contact (full name plus employee ID or work email).",
   "inThisRound": true
  },
  {
   "gapId": "C3.DP-REP-04",
   "priority": "P2",
   "gapType": "INVALID",
   "severity": "BLOCKER",
   "issue": "\"Fast\" doesn't say how documents are looked up or how quickly they must appear.",
   "needed": "the details documents are looked up by, plus how quickly they must appear, with a unit (for example seconds).",
   "inThisRound": true
  },
  {
   "gapId": "C6.DP-SA-02",
   "priority": "P2",
   "gapType": "PENDING",
   "severity": "BLOCKER",
   "issue": "The requestor named Laura Chen, E1061120 for this; her answer hasn't arrived yet.",
   "needed": "the hours during which this must be available (with a time zone), and what happens to the business if it is down.",
   "inThisRound": true
  }
 ],
 "followUpQuestions": [
  {
   "number": 1,
   "gapIds": ["C3.CONFLICT.monthlyVolumeBand"],
   "questionIds": ["monthlyVolumeBand"],
   "group": "Storing and retrieving documents",
   "gapType": "CONFLICT",
   "rules": ["CONFLICT"],
   "currentAnswer": "Under 10,000",
   "question": "Your intake says under 10,000 items a month, but about 900 documents a working day comes to roughly 19,800 a month. Which is right?",
   "answerFormat": "Keep the intake answer, use the new figure, or give a corrected monthly figure.",
   "answerType": "select",
   "options": [
    {"label": "Keep the intake answer", "key": "keepIntake"},
    {"label": "Use the new answer", "key": "useNew"}
   ],
   "respondent": "business",
   "allowNominee": false,
   "conflict": {
    "intakeValue": "lt10k",
    "newValue": "10kTo100k",
    "evidence": "\"about 900 documents a working day\" → 900 × 22 = 19,800 a month",
    "fromDataPoint": "DP-REP-05"
   },
   "namedPerson": null,
   "askedBefore": false
  },
  {
   "number": 2,
   "gapIds": ["C1.DP-CORE-11"],
   "questionIds": ["DP-CORE-11"],
   "group": "Application setup and access",
   "gapType": "MISSING",
   "rules": ["DP"],
   "currentAnswer": "",
   "question": "Who will support this in Production on your side? Please give the team and a named contact.",
   "answerFormat": "A team name plus a contact's full name and employee ID or work email.",
   "answerType": "text",
   "options": [],
   "respondent": "business",
   "allowNominee": false,
   "conflict": null,
   "namedPerson": null,
   "askedBefore": false
  },
  {
   "number": 3,
   "gapIds": ["C3.DP-REP-04"],
   "questionIds": ["DP-REP-04"],
   "group": "Storing and retrieving documents",
   "gapType": "INVALID",
   "rules": ["DP"],
   "currentAnswer": "Fast",
   "question": "How will people look documents up (by which details), and how quickly must they appear? \"Fast\" doesn't tell us enough.",
   "answerFormat": "The details used to search or browse, plus a time with its unit.",
   "answerType": "text",
   "options": [],
   "respondent": "business",
   "allowNominee": false,
   "conflict": null,
   "namedPerson": null,
   "askedBefore": false
  },
  {
   "number": 4,
   "gapIds": ["C6.DP-SA-02"],
   "questionIds": ["DP-SA-02"],
   "group": "Overall design",
   "gapType": "PENDING",
   "rules": ["DP"],
   "currentAnswer": "Not sure",
   "question": "Laura Chen was named for this, and her answer is still needed: during which hours must this be available, and what happens to the business if it is down?",
   "answerFormat": "Hours with a time zone, plus the business impact of an outage.",
   "answerType": "text",
   "options": [],
   "respondent": "business",
   "allowNominee": true,
   "conflict": null,
   "namedPerson": "Laura Chen, E1061120",
   "askedBefore": true
  }
 ],
 "jiraComment": "h2. ECM intake gap report — INT-2026-01022 — discovery check 2\n\nh3. Summary\n\n7 ECM services apply and 8 don't. 4 gaps are open in 3 categories, all blocking; 1 is a P1 conflict between the intake's volume band and the volumes given. A production support contact, how documents are looked up, and the availability need (waiting for Laura Chen) are still missing. Discovery can't finish until these are closed.\n\n||Service||Status||\n|Core onboarding|APPLICABLE|\n|Security and compliance|APPLICABLE|\n|ICMP repository|APPLICABLE|\n|Content capture|APPLICABLE|\n|Virus scanning|APPLICABLE|\n|Solution architecture|APPLICABLE|\n|Testing and performance|APPLICABLE|\n|Print and mail|NOT_APPLICABLE|\n|Records and retention|NOT_APPLICABLE|\n|Content migration|NOT_APPLICABLE|\n|Document AI / iDocs|NOT_APPLICABLE|\n|Document generation|NOT_APPLICABLE|\n|eSignature|NOT_APPLICABLE|\n|API onboarding|NOT_APPLICABLE|\n|Event integration|NOT_APPLICABLE|\n\n||Area||Gaps||Blocking||To clarify||\n|C1 Core Onboarding and Environments|1|1|0|\n|C2 Security, Compliance and Records|0|0|0|\n|C3 Repository and Migration|2|2|0|\n|C4 Capture, Document Intelligence and Malware Scanning|0|0|0|\n|C5 Output and Communications|0|0|0|\n|C6 Integration, Architecture and Testing|1|1|0|\n\nh3. Gaps\n\n||#||Gap ID||Type||Severity||Issue||\n|1|C3.CONFLICT.monthlyVolumeBand|CONFLICT|BLOCKER|The intake says under 10,000 items a month, but the volume answer, about 900 documents a working day, comes to about 19,800 a month (900 × 22).|\n|2|C1.DP-CORE-11|MISSING|BLOCKER|Production is one of the environments needed, so a production support contact is required, and none has been given yet.|\n|3|C3.DP-REP-04|INVALID|BLOCKER|\"Fast\" doesn't say how documents are looked up or how quickly they must appear.|\n|4|C6.DP-SA-02|PENDING|BLOCKER|The requestor named Laura Chen, E1061120 for this; her answer hasn't arrived yet.|\n\nh3. Follow-up questions\n\nh4. Storing and retrieving documents\n\n*1.* {{monthlyVolumeBand}} Your intake says under 10,000 items a month, but about 900 documents a working day comes to roughly 19,800 a month. Which is right?\n* Answer format: Keep the intake answer, use the new figure, or give a corrected monthly figure.\n* Options: Keep the intake answer / Use the new answer\n\nh4. Application setup and access\n\n*2.* {{DP-CORE-11}} Who will support this in Production on your side? Please give the team and a named contact.\n* Answer format: A team name plus a contact's full name and employee ID or work email.\n\nh4. Storing and retrieving documents\n\n*3.* {{DP-REP-04}} How will people look documents up (by which details), and how quickly must they appear? \"Fast\" doesn't tell us enough.\n* Answer format: The details used to search or browse, plus a time with its unit.\n\nh4. Overall design\n\n*4.* {{DP-SA-02}} Laura Chen was named for this, and her answer is still needed: during which hours must this be available, and what happens to the business if it is down?\n* Answer format: Hours with a time zone, plus the business impact of an outage.\n* Can be answered by naming someone who knows: full name plus employee ID or work email\n* Waiting for: Laura Chen, E1061120\n* Asked before\n",
 "document": "",
 "completion": null,
 "rerunCategories": [],
 "newTriggers": [],
 "errors": [],
 "infoNotes": []
}
```
