# How each skill performs its workflow internally

There are six illustrations, in PNG and SVG. In every version, V1/V3 and V2/V4 run exactly the same internal logic. The only difference is packaging: the referenced versions load separate reference files, and the single-file versions consult embedded sections with the same IDs.

## 1. ECMIntakeAnalysis (V1 integrated, and V3)
![ECMIntakeAnalysis internal workflow](1-V1-ECMIntakeAnalysis-internal-workflow.png)

| Step | What happens inside | Reference / section consulted |
|---|---|---|
| A. Load state | Round 0 creates the intake record. Every submitted value is stored as `initial` (never overwritten). Later rounds load the record and attach the reply. | ANA-05, ANA-00, ANA-01, SHARED-03 |
| B. Map reply | Reply parts are matched to `Q<round>-<n>`. Anything uncertain is kept as unmatched and asked about next round. | ANA-04 |
| C1. Field validation | Presence, type, format and option keys, for new, changed and dependent fields only. | ANA-02-T1 … T6 (only the tabs affected) |
| C2. Semantic quality | Q1–Q11: non-answers, placeholders, gibberish, label echo, generic text (fewer than 2 anchors), partial answers, duplication, fakes, relevance, injected instructions. | SHARED-01 |
| C3. Identity | I1–I6: full name plus employee ID or corporate email. Roles and pronouns are rejected. Directory lookup when available. | SHARED-02, SHARED-03 |
| C4. Cross-field | XF-R1–R11 make fields conditionally required. XF-C1–C21 check consistency, and narrative evidence must be quoted. | ANA-03 |
| D. Identify gaps | Open BLOCKER or CLARIFY, missing required fields, and "not sure" on DC fields. | ANA-01 classes |
| E. Follow-up | One message covering every gap, grouped by tab. The not-sure and skip procedures apply. No round limit. | ANA-04 |
| Gate | G1–G11 over the whole record. Any failure becomes a gap. | ANA-06 |
| Handover | One Normalized Discovery Context (facts only, verbatim narratives, provenance of initial versus final values). | ANA-07, ANA-08 |

## 2. ECMIntakeDiscovery (V1 integrated, and V3)
![ECMIntakeDiscovery internal workflow](2-V1-ECMIntakeDiscovery-internal-workflow.png)

| Step | What happens inside | Reference / section consulted |
|---|---|---|
| Input contract | IC1–IC6. If it fails, the result is `REJECTED_TO_ANALYSIS` and nothing is asked. | DIS-01 |
| Determine domains | 29 DA rules make each of the 15 domains APPLICABLE (strong rule), CANDIDATE (hint or weak rule) or NOT_APPLICABLE, with evidence. | DIS-02 |
| Load domains | Only the references for live domains are loaded. | DIS-D01 … DIS-D15 |
| Reuse base | Data points satisfied by the context are marked `SATISFIED_FROM_BASE` and never re-asked. | domain references |
| Derive requirements | A requirement is written only from a template whose inputs are all satisfied. UNSET platform values become `FIT_CHECK_PENDING`. | DIS-03, DIS-00, DIS-09 |
| Gaps and priority | P1 (applicability, gates and conflicts) is asked first, then P2 and P3 together. | DIS-04 |
| Follow-up and validation | A contextual message that routes technical items to the right person. Answers are checked against the Accept rule, the shared standards, and consistency with the base. | DIS-06, SHARED-01/02 |
| Update and recalculate | History is appended, base corrections are recorded verbatim, requirements are withdrawn and reissued, and domain applicability is recalculated. | DIS-05, DIS-07 |
| Gate and output | D1–D10. Then `DISCOVERY_COMPLETE`, with the review package going to Human / Accountable Reviews. | DIS-08, DIS-10 |

## 3. Split analysis: ECMIntakeAnalysis (engine) and ECMIntakeAnalysisFollowUp (V2, and V4)
![Split analysis loop](3-V2-Analysis-engine-and-follow-up-loop.png)

The engine runs every validation step and is the only judge of validity. Instead of writing a message, it emits a **gap report** (SHARED-04).

The follow-up skill:
- composes one message covering every gap;
- maps the replies;
- pre-screens only for obvious failures (Q1, Q2, Q3, Q10 and I2), re-asking each one once;
- handles "not sure" and skip requests;
- returns a verbatim **answer package**.

The engine re-validates every answer, whatever the pre-screen said. When it completes, it sends a **completion notice** so the follow-up skill can close with the requestor.

## 4. Split discovery: ECMIntakeDiscovery (engine) and ECMIntakeDiscoveryFollowUp (V2, and V4)
![Split discovery loop](4-V2-Discovery-engine-and-follow-up-loop.png)

This is the same pattern as split analysis, with three differences:
- the gap report is prioritised (P1 first);
- the follow-up skill quotes the requestor's earlier answers and routes technical items to identified nominees;
- the follow-up skill also checks units.

Contradictions with the base context come back to the engine as `CONFLICT` gaps.

## 5. End-to-end flow and the four versions
![End-to-end](5-End-to-end-and-four-versions.png)

## 6. Status lifecycles
![Status lifecycles](6-Status-lifecycles.png)
