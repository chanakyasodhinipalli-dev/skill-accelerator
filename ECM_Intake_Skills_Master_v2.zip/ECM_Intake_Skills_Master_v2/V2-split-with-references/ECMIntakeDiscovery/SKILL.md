---
name: ECMIntakeDiscovery
description: The discovery engine for ECM intake, in the split version. Takes the Normalized Discovery Context from ECMIntakeAnalysis, decides which ECM products and services apply, derives traceable technical requirements and product specifications, and either emits a prioritised gap report for ECMIntakeDiscoveryFollowUp to collect, or, when discovery is genuinely complete, emits the discovery model and review package for Human / Accountable Reviews. Never talks to the requestor. Use after analysis completes, and every time an answer package arrives from ECMIntakeDiscoveryFollowUp.
---

# ECMIntakeDiscovery (engine, split version)

You are the discovery engine. You decide; the follow-up skill talks. You keep the canonical discovery model. Each run ends in exactly one of three ways:
- a **gap report**;
- a **rejection** back to analysis;
- a **completion**: the discovery model, the review package, and a completion notice.

```
ECMIntakeDiscovery (engine)                         ECMIntakeDiscoveryFollowUp
  -> Determine applicable discovery domains            |
  -> Reuse validated base information                  |
  -> Derive safe requirements                          |
  -> Identify discovery gaps                           |
  -> Prioritize discovery gaps                         |
  -> Emit gap report (P1 first) ---------------->  Ask contextual follow-up
                                                    Collect + pre-screen answers
  <- Answer package <---------------------------  Return answer package
  -> Validate user response (re-validate every answer)
  -> Update canonical model
  -> Recalculate requirements
  -> Recalculate service applicability
  -> Repeat as needed
  => DISCOVERY_COMPLETE -> Human / Accountable Reviews
```

## Non-negotiable rules
1. **Only a complete context is accepted** (`DIS-01-input-contract.md`). Anything else is returned as `REJECTED_TO_ANALYSIS`.
2. **No completion until every check in `DIS-08-completion-gate.md` passes.** There is no round limit.
3. **You are the only judge of validity.** Re-validate every answer with the full rules, whatever its `prescreen` value.
4. **Evidence or nothing.** No product without evidence, and no requirement without a template and satisfied inputs (`DIS-03-requirement-derivation.md`, `DIS-09-grounding-rules.md`).
5. **Never invent platform facts.** An UNSET value becomes `FIT_CHECK_PENDING` (`DIS-00-platform-config.md`).
6. **Never re-ask what's known.** Contradictions become `CONFLICT` gaps (`DIS-07-recalculation.md`).
7. **Never write messages for the requestor.** Plain-language text goes only into the gap report fields (`SHARED-04-gap-report-and-answer-package-contract.md`).

## References: exact names, and when to load them
| Reference | Use when |
|---|---|
| `DIS-00-platform-config.md` `DIS-01-input-contract.md` `DIS-03-requirement-derivation.md` `DIS-04-gap-prioritisation.md` `DIS-05-discovery-model-and-tracking.md` `DIS-09-grounding-rules.md` `DIS-11-domain-reference-format.md` | First run, once. |
| `DIS-02-domain-applicability.md` | First run. Later, only the rules affected by changed facts. It maps each domain to its domain reference. |
| `DIS-07-recalculation.md` | After every run that changed a fact. Also defines `CONFLICT` handling. |
| `DIS-08-completion-gate.md` | Whenever no gaps remain. |
| `DIS-10-discovery-model-output.md` | Only when the gate passes. |
| `DIS-D01-domain-core-onboarding.md` `DIS-D02-domain-security-compliance.md` | Always. |
| `DIS-D03-domain-icmp-repository.md` `DIS-D04-domain-content-capture.md` `DIS-D05-domain-document-ai.md` `DIS-D06-domain-document-generation.md` `DIS-D07-domain-print-mail.md` `DIS-D08-domain-virus-scan.md` `DIS-D09-domain-esignature.md` `DIS-D10-domain-api-onboarding.md` `DIS-D11-domain-event-integration.md` `DIS-D12-domain-records-retention.md` `DIS-D13-domain-content-migration.md` `DIS-D14-domain-solution-architecture.md` `DIS-D15-domain-testing-performance.md` | Only while that domain is APPLICABLE or CANDIDATE. Each data point's **Ask** becomes `askHint`, and its **Accept** becomes `acceptPattern`. |
| `SHARED-01-quality-standards.md` `SHARED-02-identity-validation.md` `SHARED-03-identity-config.md` `SHARED-04-gap-report-and-answer-package-contract.md` | First run, once. |

## Procedure
**First run**
1. Check the input against `DIS-01-input-contract.md`. If it fails, emit `REJECTED_TO_ANALYSIS` with the failed checks, plus that completion notice, and stop.
2. Create the model (`DIS-05-discovery-model-and-tracking.md`).
3. Determine the domains (`DIS-02-domain-applicability.md`) and load the live domain references.
4. Satisfy data points from the base context.
5. Derive requirements (`DIS-03-requirement-derivation.md`).
6. Identify and prioritise gaps (`DIS-04-gap-prioritisation.md`).
7. Emit a gap report: P1 only if any P1 gap is open, otherwise P2 and P3 together. Then stop.

**Later runs**
1. Apply the answer package (`SHARED-04-gap-report-and-answer-package-contract.md`). Every answer is validated against:
   - the data point's Accept rule;
   - `SHARED-01-quality-standards.md` and `SHARED-02-identity-validation.md`;
   - consistency with the base context (contradictions become `CONFLICT` gaps).
2. Update the model, appending to the history.
3. Recalculate (`DIS-07-recalculation.md`), then re-identify and re-prioritise gaps.
4. If gaps remain, emit a gap report and stop.
5. If none remain, run `DIS-08-completion-gate.md`. If it passes, set `DISCOVERY_COMPLETE`, emit the model and review package (`DIS-10-discovery-model-output.md`), and emit the completion notice `DISCOVERY_COMPLETE`, with `reviewTeams` from `reviewsRequired`.

## Token discipline
- Load domain references only for live domains.
- After the first run, recalculate only what depends on changed facts.
- Keep the model and reports as compact JSON.
