# DIS-07: Recalculation after each round

Run these steps in order after every round that changed a fact (a discovery answer, a base correction, or a resolved conflict).

1. **Effective facts.** Rebuild the effective view: `baseContext`, overlaid with `baseCorrections`, plus every satisfied data point.
2. **Service applicability.** Re-run `DIS-02-domain-applicability.md` for every rule that reads a changed fact or a changed domain status. DA-24 and DA-26 depend on how many domains are APPLICABLE, so re-run those too.
   - A domain that becomes **APPLICABLE or CANDIDATE**: load its file, satisfy its data points from the effective facts, and add its gaps.
   - A domain that becomes **NOT_APPLICABLE**: set every data point in it to `NOT_REQUIRED`, withdraw its requirements (with reason "domain no longer applicable"), and remove its product specification. Keep the history.
3. **Data point conditions.** Re-evaluate each data point's "required when" against the effective facts. Newly required points become `OPEN`. Points no longer required become `NOT_REQUIRED`.
4. **Requirements.** For every template whose inputs changed, regenerate the requirement, withdrawing the old one as `DIS-03-requirement-derivation.md` rule 7 requires. Generate templates that have just become fully satisfied.
5. **Product specifications.** Rebuild the specification fields that read changed data points.
6. **Gaps.** Re-identify and re-prioritise (`DIS-04-gap-prioritisation.md`).
7. **Loop guard.** If one fact changes a domain's applicability, and a later answer would flip it back, treat that as a P1 conflict and ask the requestor directly. Never let statuses oscillate silently.

Log what changed in the round entry: `{domainsChanged, requirementsAdded, requirementsWithdrawn, dataPointsOpened, dataPointsClosed}`.

## Base corrections (split version)
When a validated answer contradicts the base context, for example the base says 10,000 to 100,000 a month and the answer says 400,000 a month:
- Don't pick one.
- Raise a P1 gap of type `CONFLICT` (`SHARED-04-gap-report-and-answer-package-contract.md`). Its `conflict` object holds the base value and the new value.
- When the answer package resolves it, record the requestor's verbatim choice. If the new value wins, add a `baseCorrections` entry.
- Then re-run this recalculation from step 1.
