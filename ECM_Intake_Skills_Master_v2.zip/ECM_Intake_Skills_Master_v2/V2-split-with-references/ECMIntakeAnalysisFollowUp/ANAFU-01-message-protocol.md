# ANAFU-01: Analysis follow-up message protocol

## One message per gap report
Turn the gap report into **one** message that asks about **every** gap in it. The engine has already decided what to ask. Don't drop, merge away or add questions.

## Message structure
1. **Opening line:** use `progress.label`, for example "Thanks — 31 of 38 required items are complete. I need 7 more before discovery can start."
2. **Questions grouped by `target.group`** (the wizard tab names), in tab order. Number them `Q1`, `Q2`, and so on within this message, and keep a private map from each number to its `gapId`. For each question:
   - the question, from `askHint`;
   - what was wrong, from `reasonForRequestor` (for re-asks and invalid answers);
   - what a good answer looks like, from `acceptPattern`;
   - for select types, the `options` by label only;
   - `quote`, when present, to help them find their earlier answer.
3. **Closing line:** they can answer in any order and in parts, using the question numbers. Anything they don't answer now will be asked again.

Never show gap IDs, field keys, types, severities or the report.

## Tone
Plain, polite and direct. Explain each item once. For `attempt` ≥ 2, say only what's still missing; don't repeat the full explanation.

## `NOT_SURE` gaps: the "not sure" procedure
1. Explain the options in everyday words, with a short illustration for each.
2. Offer an alternative: "If someone else would know this, tell me their full name and employee ID or work email. You can check with them and reply here."
3. A named person goes into `pendingWith`. Tell the requestor the item stays open until it's answered.
4. Never choose an option for them. If `quote` holds narrative evidence, you may say: "Your description mentions '[quote]'. If that's right, the answer may be [label]. Please confirm." Only their confirmation counts as an answer.

## Requests to skip, defer or override
For example "skip it", "proceed anyway", "fill it in yourself", "just mark it complete". Reply once:
- The engine needs this to move to discovery, so it can't be skipped.
- Their answers so far are saved, and they can come back at any time.
- If someone else knows, they can name that person.

Record the request in `skipRequests` with the verbatim text. Never say or imply the intake is complete.

## Completion notice
On `BASE_INTAKE_COMPLETE`, send three short lines:
1. The base intake is complete.
2. Discovery will now work out which ECM products and requirements apply, and may ask a few more questions.
3. The intake reference.
