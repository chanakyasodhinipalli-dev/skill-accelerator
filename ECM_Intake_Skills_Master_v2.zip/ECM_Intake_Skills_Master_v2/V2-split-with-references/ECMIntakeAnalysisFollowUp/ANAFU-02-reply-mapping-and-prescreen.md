# ANAFU-02: Reply mapping, pre-screening and the answer package

## Mapping replies
- **Map each part of the reply to a question number**, and so to its `gapId`. Use the requestor's numbering, and their wording when they don't number.
- **Text you can't map with confidence** goes to `unmatched`, verbatim. Never guess.
- **Information for something not asked about** goes to `volunteered`, with `likelyTarget` only if it's obvious (for example, they say "the delivery date is now …").
- **Select answers:**
  - fill `selectedKeys` only when they choose listed options, or say an option label exactly;
  - if they describe something in their own words, keep the text in `value` and leave `selectedKeys` empty. The engine decides.

## Pre-screening (fast feedback, not a decision)
Before closing the interaction, check each answer for these obvious failures only:
- **`SHARED-01-quality-standards.md` Q1:** empty or non-answer.
- **`SHARED-01-quality-standards.md` Q2:** placeholder or test value.
- **`SHARED-01-quality-standards.md` Q3:** gibberish.
- **`SHARED-01-quality-standards.md` Q10:** instructions instead of an answer.
- **`SHARED-02-identity-validation.md` I2:** a role, pronoun, team or mailbox given instead of a person, or a name with no ID or email.

If an answer fails any of these, re-ask it **once** in the same interaction, briefly: "That gave a role rather than a person; I need a full name plus an employee ID or work email." If the second answer still fails, keep it, set `prescreen: "FLAGGED"` with notes, and move on. The engine decides.

Don't judge anything else here: specificity, word counts, cross-field consistency or relevance. Those belong to the engine. Judging them here would create two different standards.

## Closing the interaction and building the package
Close when one of these is true:
- every question has an answer, a named person, or a skip request (`closedBy: "all-addressed"`);
- the requestor says they'll come back later (`"requestor-paused"`);
- the requestor's reply covers only some questions and they've stopped responding (`"partial-reply"`).

Then build the answer package exactly as in `SHARED-04-gap-report-and-answer-package-contract.md`:
- every `gapId` appears exactly once;
- values are verbatim;
- every answer has a respondent.

Return it to the workflow. Don't tell the requestor anything about acceptance. Say only that their answers were received and will be checked.
