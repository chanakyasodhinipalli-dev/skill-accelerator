# SHARED-04: Gap report and answer package contract

**Used by:** ECMIntakeAnalysis, ECMIntakeAnalysisFollowUp, ECMIntakeDiscovery and ECMIntakeDiscoveryFollowUp, in the split version.

In the split version, each step has two skills:
- The **engine** (ECMIntakeAnalysis or ECMIntakeDiscovery) analyses, validates, decides, and keeps the canonical model. It never talks to the requestor.
- The **follow-up skill** (ECMIntakeAnalysisFollowUp or ECMIntakeDiscoveryFollowUp) talks to the requestor and collects answers. It never decides whether an answer is acceptable, and it never changes the model.

The two skills exchange the three documents below, and the workflow runs the loop:

```
Engine --GapReport--> FollowUp --(talks to requestor)--> AnswerPackage --> Engine --> ... --> Engine: COMPLETE
                                                                                                  |
                                                                    CompletionNotice --> FollowUp (informs requestor)
```

## 1. Gap report (engine to follow-up)

```json
{
  "reportType": "ECMGapReport",
  "schemaVersion": "1.0",
  "step": "analysis | discovery",
  "intakeId": "",
  "round": 2,
  "progress": { "label": "31 of 38 required items complete | 4 ECM services identified, 9 details open", "openGaps": 7 },
  "priorityInThisReport": "ALL | P1 | P2P3",
  "gaps": [
    {
      "gapId": "GAP-0004",
      "type": "MISSING | INVALID | CLARIFY | NOT_SURE | CONFLICT | APPLICABILITY | UNMATCHED",
      "target": { "kind": "field | dataPoint | domain", "id": "sponsoringProductOwner", "group": "1 Requestor and Ownership" },
      "severity": "BLOCKER | CLARIFY",
      "priority": "P1 | P2 | P3 | null",
      "askHint": "Who is the product owner accountable for scope and priority?",
      "reasonForRequestor": "The answer named a role rather than a person.",
      "acceptPattern": "Full name plus employee ID or work email.",
      "inputType": "text | textarea | select | multiselect | date | person | list",
      "options": [ { "label": "", "key": "" } ],
      "quote": "short quote of the earlier answer or narrative evidence, or null",
      "conflict": { "baseValue": null, "newValue": null },
      "respondent": "business | technical",
      "suggestedRespondent": null,
      "attempt": 2,
      "pendingWith": null
    }
  ],
  "unmatchedFromLastRound": [ "verbatim text the engine could not map" ]
}
```

### Engine rules for gap reports
1. **Every open gap, with nothing hidden.** The engine includes every open gap, subject only to the step's priority rule: analysis sends ALL; discovery sends P1 first, then P2 and P3 together.
2. **Plain language only.** `askHint`, `reasonForRequestor` and `acceptPattern` are written in plain language, ready to show the requestor. They contain no rule IDs, issue codes or field keys.
3. **No example data.** `acceptPattern` describes the form of a good answer, never a realistic invented value.
4. **Re-asks are marked.** `attempt` counts how many gap reports have contained this gap. A re-asked gap keeps its `gapId`.
5. **Pending people are passed on.** `pendingWith` carries the person (I1 object) the requestor named for a `NOT_SURE` gap. The gap stays open.

## 2. Answer package (follow-up to engine)

```json
{
  "packageType": "ECMAnswerPackage",
  "schemaVersion": "1.0",
  "step": "analysis | discovery",
  "intakeId": "",
  "round": 2,
  "respondents": [ { "ref": "R1", "fullName": "", "employeeId": null, "email": null, "role": "requestor | nominee" } ],
  "answers": [
    { "gapId": "GAP-0004", "value": "<verbatim answer text or selected labels>", "selectedKeys": null,
      "respondentRef": "R1", "prescreen": "PASSED | FLAGGED", "prescreenNotes": [ "role word only" ], "reaskedInSession": 1 }
  ],
  "pendingWith": [ { "gapId": "GAP-0011", "person": { "fullName": "", "employeeId": null, "email": null } } ],
  "unanswered": [ "GAP-0007" ],
  "skipRequests": [ { "gapId": "GAP-0009", "text": "<verbatim>" } ],
  "unmatched": [ { "text": "<verbatim>" } ],
  "volunteered": [ { "text": "<verbatim>", "likelyTarget": "fieldName | dataPointId | null" } ],
  "closedBy": "all-addressed | requestor-paused | partial-reply"
}
```

### Follow-up rules for answer packages
1. **Verbatim only.** `value` holds the respondent's own words. `selectedKeys` is filled only when the respondent picked listed options, or named an option label exactly. Never paraphrase or complete an answer.
2. **Pre-screening flags, never rejects.** `prescreen` flags obvious failures (non-answers, placeholders, gibberish, role-only people). The engine re-validates every answer, whatever its `prescreen` value.
3. **Account for every gap.** Every `gapId` in the report appears exactly once across `answers`, `pendingWith`, `unanswered` and `skipRequests`.
4. **Respondents are identified.** Every answer has a `respondentRef`. A nominee answering must be identified with a full name plus an ID or email (`SHARED-02-identity-validation.md`). If not, their answers are listed under `unanswered`.

## 3. Completion notice (engine to follow-up, once)

```json
{ "noticeType": "BASE_INTAKE_COMPLETE | DISCOVERY_COMPLETE | REJECTED_TO_ANALYSIS", "intakeId": "", "reviewTeams": [ "team names, discovery only" ] }
```

The follow-up skill sends the requestor a short closing message. For `REJECTED_TO_ANALYSIS` it sends nothing; the workflow routes the intake back to analysis.

## Engine handling of an answer package
- **Every answer is re-validated** with the full rules. The `prescreen` value is ignored for the decision.
- **`skipRequests` and `unanswered`** gaps stay open, with `attempt` incremented in the next report.
- **`pendingWith`** is stored on the gap, which stays open.
- **`volunteered` text** is validated like any update. If its target is uncertain, it becomes an `UNMATCHED` gap in the next report.
- **`closedBy: requestor-paused`** means the engine saves state and emits no new report until the workflow resumes it.
