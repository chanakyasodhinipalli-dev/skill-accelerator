# DISFU-02: Reply mapping, respondents, pre-screening and the answer package

## Respondents
- **The requestor** is respondent `R1`.
- **Anyone else who answers in the session**, such as an engineering lead or architect, is added as a nominee. They must be identified by full name plus employee ID or work email (`SHARED-02-identity-validation.md`) before their answers count. Until then, their answers are listed under `unanswered`, with a note.
- **Never attribute** an answer to someone who didn't give it in the session. "My lead says it's 50 MB", relayed by the requestor, is recorded as the requestor's answer: `respondentRef: R1`, and the text is kept verbatim.

## Mapping replies
These are the same rules as the analysis follow-up:
- map by question number or wording;
- put anything you can't map with confidence in `unmatched`, verbatim;
- put unasked information in `volunteered`;
- fill `selectedKeys` only for exact option choices.

## Units and numbers
If a numeric answer has no unit or period (for example "500" for a volume), re-ask once in the same interaction: "500 per day, per month, or per hour?" If it's still missing, pass it as given, flagged.

## Pre-screening (fast feedback, not a decision)
Re-ask once in the same interaction when an answer fails one of these:
- `SHARED-01-quality-standards.md` Q1, Q2, Q3 or Q10;
- `SHARED-02-identity-validation.md` I2;
- the missing-unit check above.

If it still fails, keep it with `prescreen: "FLAGGED"`. Never judge consistency with the base context, the domain Accept rules, or applicability. Those belong to the engine.

## Closing and building the package
Close the interaction on the same conditions as analysis: all addressed, requestor paused, or partial reply. Build the answer package exactly as in `SHARED-04-gap-report-and-answer-package-contract.md`: every `gapId` appears once, values are verbatim, and every answer has an identified respondent. Tell the requestor only that their answers were received and will be checked.
