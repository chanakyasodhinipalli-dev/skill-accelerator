# DISFU-01: Discovery follow-up message protocol

## One message per gap report
Turn the gap report into **one** message that asks about **every** gap in it. Discovery sends P1 gaps first, then P2 and P3. Don't drop, merge away or add questions.

## Make it contextual
Build each question on what the requestor already said, using `quote`. For example: "You said customers upload documents through the portal. What file types do they upload, and what's the largest file you'd expect?" Quote briefly.

## Message structure
1. **Opening line:** from `progress.label`, for example "Discovery: 4 ECM services identified. I need 9 details to complete their specifications."
2. **Questions grouped by plain-language service name**, derived from `target.group`. Use names like:
   - "Storing and retrieving documents", "Receiving documents", "Reading documents automatically";
   - "Creating documents", "Printing and posting", "Malware scanning", "Electronic signatures";
   - "System connections (APIs)", "System connections (events)";
   - "Keeping and disposing of records", "Moving content from another system";
   - "Overall design", "Testing and performance", "Application setup and access", "Security and data protection".

   Use product names only if the requestor used them first. Number the questions `Q1`, `Q2`, and so on, and keep a private map to each `gapId`. For each question include:
   - `askHint`;
   - one clause on why it's needed, for technical items;
   - `acceptPattern`, including units;
   - `options` by label;
   - `reasonForRequestor` for re-asks.
3. **Technical items** (`respondent: technical`): say who's likely to know. Use `suggestedRespondent` if present; otherwise "your engineering lead or architect".
4. **`CONFLICT` gaps:** "Earlier you said [baseValue]. You've now said [newValue]. Which is right?"
5. **`APPLICABILITY` gaps:** ask the yes/no question with a short description, and ask them to describe briefly if yes.
6. **Closing line:** answer in any order, or forward technical questions to the named person. Nothing proceeds until every question is answered.

Never show gap IDs, data-point IDs, rule IDs or the report.

## `NOT_SURE`, skip and defer
These follow the same procedure as analysis:
- Explain the item once.
- Offer to record a knowledgeable person (full name plus ID or email) in `pendingWith`. The item stays open.
- Never choose for them.

"Whatever ECM recommends" or "use the standard" is not an answer to a question about their own need. Explain that ECM needs their requirement in order to recommend anything, and record it under `skipRequests` if they insist.

## Completion notice
On `DISCOVERY_COMPLETE`, send three short lines:
1. Discovery is complete.
2. The specification now goes to the ECM accountable reviewers. Name the teams from `reviewTeams`, and make no promises about outcomes or dates.
3. The intake reference.
