# ECM Intake: Analysis and Discovery Skills (master package, v2)

**24 Nov 2026 · for the ESAGE workflow in iDocs Canvas AI Hub**

This package contains the analysis and discovery skills for the ECM intake workflow, in **four versions**. It also includes the Step 1 data capture workbook, the test scenarios, JSON output samples, and illustrations of each skill's internal workflow.

## What changed from the previous package

| # | Your comment | How it's handled |
|---|---|---|
| 1 | No JSON files, no subfolders, no shared references inside skills | Every skill folder is **flat**: `SKILL.md` plus individual reference `.md` files. The field catalog is now `ANA-01-field-catalog.md`. Field rules and domain files are individual `.md` files. |
| 2 | Use the exact reference names inside the skill | Every `SKILL.md` names each reference by its exact file name, in a "when to load" table. A build check confirmed that every name used resolves to a real file and that every file is listed. |
| 3 | Shared references kept separately | `shared-references/` (`SHARED-01` … `SHARED-04`) sits beside the skills, not inside them. |
| 4 | Positive and negative test scenarios in Excel | `test-scenarios/ECM_Intake_Skill_Test_Scenarios.xlsx`: 9 analysis and 7 discovery scenarios, with answers populated per field catalog, replies per round, and expected results. |
| 5 | JSON samples for happy and failure outputs | `samples/`: 12 JSON files covering analysis and discovery, happy and failure, plus the split-version gap reports, answer packages and completion notices. |
| 6 | Four versions | V1 integrated with references · V2 split with references · V3 integrated, single file · V4 split, single file. |
| 7 | Illustrations of the internal workflow | `illustrations/`: 6 diagrams (PNG and SVG) and `WORKFLOW-ILLUSTRATIONS.md`, with a step-by-step table for each skill. |

## The four versions

| Version | Skills | Who talks to the requestor | Reference files |
|---|---|---|---|
| **V1-integrated-with-references** | ECMIntakeAnalysis, ECMIntakeDiscovery | Each skill asks its own contextual follow-ups | `SKILL.md` + flat `ANA-*` / `DIS-*` files + `shared-references/` (SHARED-01–03) |
| **V2-split-with-references** | ECMIntakeAnalysis (engine), ECMIntakeAnalysisFollowUp, ECMIntakeDiscovery (engine), ECMIntakeDiscoveryFollowUp | Only the follow-up skills; the engines analyse and emit gap reports | `SKILL.md` + flat `ANA-*` / `ANAFU-*` / `DIS-*` / `DISFU-*` files + `shared-references/` (SHARED-01–04) |
| **V3-integrated-single-file** | Same as V1 | Same as V1 | None. One `SKILL.md` per skill, with every reference embedded as Part 2 sections |
| **V4-split-single-file** | Same as V2 | Same as V2 | None. One `SKILL.md` per skill, with every reference embedded |

All four versions come from the same source text, so the rules are identical. They differ only in who talks to the requestor (integrated or split) and how the material is packaged (references or a single file).

**Choosing between them**
- **References (V1/V2):** cheaper on tokens, because only what a round needs is loaded. For example, discovery loads only the domain references for products that apply. They are also easier to maintain, since one rule lives in one file.
- **Single file (V3/V4):** simplest to deploy where references can't be attached, but every invocation carries the whole skill:

  | Version | Lines per SKILL.md |
  |---|---|
  | V3 analysis | ~1,200 |
  | V3 discovery | ~1,300 |
  | V4 engines | ~1,250–1,350 |
  | V4 follow-up skills | ~390 |
- **Integrated (V1/V3):** fewer workflow nodes, and the follow-up wording can use everything the skill knows.
- **Split (V2/V4):** the engine stays the single judge of validity, and the conversation can be redesigned or localised without touching the rules. The workflow runs the loop: engine → gap report → follow-up → answer package → engine.

## Reference naming

Reference names are flat and unique across all skills, so they can sit side by side in a library:

| Prefix | Owner | Files |
|---|---|---|
| `ANA-` | ECMIntakeAnalysis | `ANA-00-intake-config.md`, `ANA-01-field-catalog.md`, `ANA-02-T1…T6-field-rules-*.md`, `ANA-03-cross-field-rules.md`, `ANA-04-follow-up-protocol.md` (V1 only), `ANA-05-intake-record-and-tracking.md`, `ANA-06-completion-gate.md`, `ANA-07-normalized-discovery-context.md`, `ANA-08-grounding-rules.md` |
| `ANAFU-` | ECMIntakeAnalysisFollowUp (V2) | `ANAFU-01-message-protocol.md`, `ANAFU-02-reply-mapping-and-prescreen.md` |
| `DIS-` | ECMIntakeDiscovery | `DIS-00` … `DIS-11` (`DIS-06-follow-up-protocol.md` is V1 only), `DIS-D01` … `DIS-D15-domain-*.md` |
| `DISFU-` | ECMIntakeDiscoveryFollowUp (V2) | `DISFU-01-message-protocol.md`, `DISFU-02-reply-mapping-and-prescreen.md` |
| `SHARED-` | Shared library | `SHARED-01-quality-standards.md`, `SHARED-02-identity-validation.md`, `SHARED-03-identity-config.md`, `SHARED-04-gap-report-and-answer-package-contract.md` (V2 only) |

## Installing in iDocs Canvas AI Hub / ESAGE
1. **V1 or V2:** for each skill, upload its `SKILL.md` and every `.md` in its folder as references. Then attach the `shared-references/` files that its `SKILL.md` lists. Shared files are identical for every skill in the same version.
2. **V3 or V4:** upload the single `SKILL.md` for each skill. There are no references.
3. Wire the workflow:
   - **V1/V3:** analysis loops with the requestor until `BASE_INTAKE_COMPLETE`, then discovery loops until `DISCOVERY_COMPLETE`, then Human / Accountable Reviews.
   - **V2/V4:** per step, the engine produces a gap report, the follow-up skill collects answers, and the answer package goes back to the engine, repeating until the engine emits its output and a completion notice.

## Before go-live (configuration)
- **`SHARED-03-identity-config.md`:**
  - corporate email domains;
  - employee ID pattern;
  - directory tool;
  - session identity source.
- **`ANA-00-intake-config.md`:** tracking-ID formats (SHRP, corrective action, incident, audit, regulatory).
- **`DIS-00-platform-config.md`:** the 14 UNSET platform values. Until they are set, the dependent requirements are flagged `FIT_CHECK_PENDING` for reviewers.
- **Single-file versions:** these values are embedded, so set them inside each `SKILL.md` as well.
- **Workbook:** confirm the option lists that were inferred from cropped screenshots (see the workbook's "Option Key Changes" tab).

## Package contents
```
data-capture/              Step 1 questionnaire workbook (v6.0)
V1-integrated-with-references/
V2-split-with-references/
V3-integrated-single-file/
V4-split-single-file/
test-scenarios/            ECM_Intake_Skill_Test_Scenarios.xlsx
samples/                   12 JSON output samples (happy and failure)
illustrations/             6 workflow diagrams + WORKFLOW-ILLUSTRATIONS.md
```
