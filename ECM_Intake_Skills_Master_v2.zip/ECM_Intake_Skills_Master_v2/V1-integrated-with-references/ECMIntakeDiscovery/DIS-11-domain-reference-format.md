# DIS-11: Domain references: format

Each domain reference has the same sections. Load a domain reference only when its status is APPLICABLE or CANDIDATE.

1. **Purpose**: one line.
2. **Applicability question**: asked as P1 only when the domain is a CANDIDATE. A "yes" with a specific description makes the domain APPLICABLE. A "no" makes it NOT_APPLICABLE. "Not sure" follows the not-sure procedure.
3. **Data points**: a table with these columns:
   - `ID`
   - `Need`: what we must know.
   - `Base reuse`: the context path that can satisfy it; `—` if none.
   - `Ask`: the plain-language question.
   - `Accept`: the validation rule. The shared quality and identity standards always apply in addition.
   - `Resp`: `business` (the requestor) or `technical` (the engineering lead, the architect, or a nominee).
   - `Required when`: `always` (while the domain is live) or a condition.
   - `Gate`: `yes` if the answer can change applicability or other data points; asked as P1.

   A data point is `SATISFIED_FROM_BASE` only when the base value fully meets its `Accept` rule. Otherwise ask for the missing part, and quote the base value as context.
4. **Requirement templates**: `TR-<code>-<nn>`, with type, statement, inputs, condition and fit-check key.
5. **Product specification**: the fields to fill. Mandatory fields are marked `*`.
6. **Reviews triggered**: the reviews to add to `reviewsRequired`, with their conditions.

Lists ("for each X") are answered as one entry per item. Each entry is validated on its own.
Numbers must include their unit and period, for example "per month", "per hour" or "MB". If an answer gives a number without a unit, it gets a CLARIFY.
