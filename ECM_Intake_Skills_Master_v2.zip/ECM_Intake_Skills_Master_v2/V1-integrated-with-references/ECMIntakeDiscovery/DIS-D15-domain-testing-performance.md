# DIS-D15: Domain: Testing and performance (`testingSupport`)

**Purpose:** the test phases, test data, volume assessment and load testing needed before go-live.

**Applicability question (CANDIDATE only):** "Do you need ECM to support testing, such as system, user acceptance or performance testing?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-TP-01 | Test phases | — | "Which test phases need ECM's involvement, and who runs each one?" | For each phase: a name plus an owning team | technical | always | no |
| DP-TP-02 | Test data | `content.sensitivity` | "Where will the test data come from? Will any of it be real customer or sensitive data? If so, who approved its use?" | The source, plus "synthetic" or "production-derived". Production-derived data needs a named approver (I1). | technical | always | no |
| DP-TP-03 | Performance targets | DP-REP-05, DP-API-03 (as context) | "For performance testing, what throughput and response times must be proven?" | Numbers with units, consistent with the volumes already given | technical | the ICMP repository, API onboarding or event integration domain is APPLICABLE | no |
| DP-TP-04 | UAT sign-off | — | "Who signs off user acceptance testing?" | An I1 contact | business | always | no |

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-TP-01 | operational | ECM shall support these test phases: {phases}, owned by {teams}. | DP-TP-01 | — |
| TR-TP-02 | security | Test data shall be {synthetic / production-derived, approved by {approver}}. | DP-TP-02 | — |
| TR-TP-03 | non-functional | Volumes shall be assessed through IVaaS, and load testing (SPLI) shall prove {targets}. The SPLI ticket shall be raised in project {DP-CORE-05 project key}. | DP-TP-03, DP-CORE-05 | `VOLUME_BAND_TIER_THRESHOLD` |
| TR-TP-04 | operational | User acceptance shall be signed off by {approver}. | DP-TP-04 | — |

TR-TP-03 needs DP-CORE-05 to have a real project key. If no scrum team is allocated, TR-TP-03 isn't generated, and R-CORE-3 covers the gap.

## Product specification (`testingSupport`)
`phases*`, `testData*`, `performanceTargets`, `uatApprover*`.

## Reviews triggered
- **R-TP-1 ECM performance and testing lead:** when DP-TP-03 is required.
- **R-TP-2 Data protection:** when DP-TP-02 is production-derived.
