# DIS-D08: Domain: Virus scanning (`virusScan`)

**Purpose:** scanning incoming content for malware before it is used.

**Applicability question (CANDIDATE only, through DA-29):** "Will other applications upload documents into ECM? If so, those documents need malware scanning. Please confirm."

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-VS-01 | Entry points to scan | `content.arrival` | "Content arrives by [channels]. Should every one of these be scanned? If any shouldn't, why not?" | Confirmation of each channel. Any exclusion needs a stated reason **and** is flagged for security review. | business | always | no |
| DP-VS-02 | Action on detection | — | "If a file is found to contain malware, who must be told? Should the sender be told?" | A team plus a named contact (I1), plus "notify the sender" yes or no | business | always | no |
| DP-VS-03 | Waiting for the scan | — | "Can documents wait to be scanned before they're available, or must they be usable immediately?" | "Can wait", or "must be immediate" plus the reason | business | always | no |

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-VS-01 | security | Content arriving through {channels} shall be scanned for malware before it is made available. | DP-VS-01 | `VIRUS_SCAN_BEHAVIOUR` |
| TR-VS-02 | security | When malware is detected, {contact} shall be notified{, and the sender shall be informed}. | DP-VS-02 | `VIRUS_SCAN_BEHAVIOUR` |
| TR-VS-03 | non-functional | Availability timing relative to scanning: {DP-VS-03}. | DP-VS-03 | `VIRUS_SCAN_BEHAVIOUR` |

## Product specification (`virusScan`)
`entryPoints*`, `exclusions[] {channel, reason}`, `detectionContact*`, `notifySender*`, `availabilityTiming*`.

## Reviews triggered
- **R-VS-1 Information security:** always when DP-VS-01 has any exclusion; otherwise only when the content is sensitive.
