# DIS-D01: Domain: Core onboarding (always applicable)

**Purpose:** application identity, Jira linkage, team allocation, environments, access and certificates, which every ECM engagement needs.

**Applicability question:** none. This domain always applies.

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-CORE-01 | Business application name | `content.existingEcmDetails` (if it names the application) | "What is the name of the business application this content belongs to?" | A specific application name, not "our app" or "the system" | business | always | no |
| DP-CORE-02 | BAM App ID | — | "What is the application's BAM App ID?" | An ID that isn't a placeholder, or "not yet registered". "Not yet registered" is accepted, but raises reviewer item R-CORE-2 | technical | always | no |
| DP-CORE-03 | Remedy ID | — | "What is the application's Remedy ID?" | The same rules as DP-CORE-02 | technical | always | no |
| DP-CORE-04 | ECM intake Jira key | — | "Has an ECM intake already been raised in Jira? If so, what's the key?" | Matches `^LJKX-\d+$`, or "not raised yet" | business | always | no |
| DP-CORE-05 | Allocated scrum team | — | "Has a scrum team been allocated to deliver this? If so, which team, and what's its Jira project key?" | A team name plus a project key that is **not** LJKX, or "no team allocated" | technical | always | **yes** |
| DP-CORE-06 | Target environments | — | "Which environments do you need: Innovation, Non-Prod, Production?" | Must follow `ENV_LADDER`. Production requires Non-Prod, and Non-Prod requires Innovation. If DP-CORE-05 = "no team allocated", **only** Innovation is accepted; explain `ENV_NO_SCRUM_TEAM`. Never offer ProdFix. | business | always | **yes** |
| DP-CORE-07 | Date Production must be ready | `timeline.requestedDeliveryDate` | "When must Production be ready?" | A future ISO date | business | Production is in DP-CORE-06 | no |
| DP-CORE-08 | Systems needing service accounts | `systems.impactedSystems` | "Which applications will connect to ECM directly (not people), and in which environments?" | For each: an application name plus its environments | technical | `content.arrival` has `api`, `event` or `batch`, or `content.consumers` has `systemApi` or `systemEvent` | no |
| DP-CORE-09 | Human user groups | — | "Which groups of people need to use ECM screens, roughly how many people are in each, and in which environments?" | For each: a group name, a number of users, and environments | business | `content.consumers` has `employeeUi` | no |
| DP-CORE-10 | Certificate owner for integrating applications | — | "Who manages certificates for [applications from DP-CORE-08]?" | For each application: a team plus a named contact (I1) | technical | DP-CORE-08 required | no |
| DP-CORE-11 | Production support contact | — | "Who will support this in Production on your side? Please give a team and a named contact." | A team plus a contact (I1) | business | Production is in DP-CORE-06 | no |

## Requirement templates
| ID | Type | Statement | Inputs | Condition |
|---|---|---|---|---|
| TR-CORE-01 | environment | The onboarding shall progress through {DP-CORE-06} in the order Innovation → Non-Prod → Production, without skipping an environment. | DP-CORE-06 | always |
| TR-CORE-02 | environment | Onboarding shall be limited to Innovation until a scrum team is allocated. | DP-CORE-05 | DP-CORE-05 = no team |
| TR-CORE-03 | operational | The onboarding shall be registered against BAM App ID {DP-CORE-02} and Remedy ID {DP-CORE-03}. | DP-CORE-02, DP-CORE-03 | both are real IDs |
| TR-CORE-04 | security | Service accounts for {DP-CORE-08} shall be requested through ART, using the QAEnt service account in Innovation and Non-Prod and the production account in Production. | DP-CORE-08 | DP-CORE-08 required |
| TR-CORE-05 | security | Human user access for {DP-CORE-09} shall be requested through ART for QAEnt and through AIMS for ADEnt. | DP-CORE-09 | DP-CORE-09 required |
| TR-CORE-06 | security | Certificates for {DP-CORE-08 applications} shall be issued through Venafi, owned by {DP-CORE-10}. | DP-CORE-08, DP-CORE-10 | DP-CORE-10 required |
| TR-CORE-07 | operational | Production support for this onboarding shall be provided by {DP-CORE-11}. | DP-CORE-11 | Production targeted |

## Product specification (`coreOnboarding`)
`applicationName*`, `bamAppId*`, `remedyId*`, `intakeKey`, `scrumTeam* {name, projectKey}|null`, `targetEnvironments*`, `productionReadyDate`, `serviceAccounts[] {application, environments}`, `humanAccessGroups[] {group, users, environments}`, `certificateOwners[]`, `productionSupport`.

## Reviews triggered
- **R-CORE-1 ECM onboarding lead:** always.
- **R-CORE-2 Application registration:** when DP-CORE-02 or DP-CORE-03 is "not yet registered".
- **R-CORE-3 Scrum team allocation:** when DP-CORE-05 = no team allocated.
