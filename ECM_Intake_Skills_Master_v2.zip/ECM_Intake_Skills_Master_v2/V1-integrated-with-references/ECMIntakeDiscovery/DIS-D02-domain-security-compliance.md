# DIS-D02: Domain: Security and compliance (always applicable)

**Purpose:** how the content is classified, who may see it, and which protections and audit trails are required.

**Applicability question:** none. This domain always applies. Its depth depends on `content.sensitivity`.

"Sensitive" below means `content.sensitivity` contains any of `customerPii`, `employeePii`, `financial`, `health` or `legalPrivileged`.

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-SEC-01 | Data classification label | — | "Under your organisation's data classification policy, which classification applies to this content?" | The label exactly as the policy names it, plus the name of the policy. "Confidential-ish" and "normal" are rejected. | business | always | no |
| DP-SEC-02 | Who may access the content | `ownership.businessTeams` | "Who should be allowed to see this content, and are there restrictions, for example by region, branch or role?" | Named user populations, plus any restrictions or an explicit "no further restrictions" | business | always | no |
| DP-SEC-03 | Customer authentication before viewing | — | "Before customers can see their documents, which system confirms who they are?" | A named system or application | technical | `content.consumers` has `customerChannel` | no |
| DP-SEC-04 | Location or residency restrictions | — | "Must this content stay in a particular country or region?" | "No restriction", or the named locations plus the rule that requires it | business | sensitive | no |
| DP-SEC-05 | Masking or redaction | — | "Should any information be hidden from some viewers, for example account numbers?" | "None", or a list of fields with the viewers who must not see them | business | sensitive | no |
| DP-SEC-06 | Access audit trail | — | "Do you need a record of who viewed or changed each document? If so, who uses that record?" | "Not needed", or "needed" plus the purpose plus the user | business | sensitive, or the category is legal, audit or regulatory | no |
| DP-SEC-07 | Legal hold | — | "Might documents need to be put on legal hold so they can't be deleted?" | Yes or no; if yes, who places and lifts the hold (team plus contact) | business | `legalPrivileged` in sensitivity, or category `legalRequirement` | no |

## Requirement templates
| ID | Type | Statement | Inputs | Condition |
|---|---|---|---|---|
| TR-SEC-01 | security | Content shall be classified as {DP-SEC-01} under {policy name}, and protected accordingly. | DP-SEC-01 | always |
| TR-SEC-02 | security | Access shall be limited to {DP-SEC-02 populations}, with these restrictions: {restrictions}. | DP-SEC-02 | always |
| TR-SEC-03 | security | Customer access shall be allowed only after authentication by {DP-SEC-03}. | DP-SEC-03 | DP-SEC-03 required |
| TR-SEC-04 | data | Content shall be stored only in {DP-SEC-04 locations}, as required by {rule}. | DP-SEC-04 | a restriction is given |
| TR-SEC-05 | security | {fields} shall be hidden from {viewers}. | DP-SEC-05 | masking is required |
| TR-SEC-06 | security | Views and changes of each document shall be recorded for {purpose}, and made available to {user}. | DP-SEC-06 | the audit trail is needed |
| TR-SEC-07 | operational | Authorised users in {team} shall be able to place and lift a legal hold that prevents deletion. | DP-SEC-07 | yes |

## Product specification (`securityCompliance`)
`classification* {label, policy}`, `accessPopulations*`, `accessRestrictions*`, `customerAuthSystem`, `residency`, `masking[]`, `auditTrail`, `legalHold`.

## Reviews triggered
- **R-SEC-1 Information security / data protection:** when the content is sensitive.
- **R-SEC-2 Governance stakeholders:** the teams in `ownership.governanceStakeholders`, when that list isn't empty.
- **R-SEC-3 Legal:** when DP-SEC-07 = yes.
