# DIS-D07: Domain: Print and mail (`printMail`)

**Purpose:** physically printing and posting documents.

**Applicability question (CANDIDATE only):** "Do any documents need to be printed and posted to people?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-PM-01 | Mail volumes | — | "How many items will be posted per month, and at the peak?" | Numbers with units | business | always | no |
| DP-PM-02 | Destinations | — | "Are items posted only within the country, or internationally too? If internationally, to which countries?" | Domestic, or a list of countries | business | always | no |
| DP-PM-03 | Speed and service level | — | "How quickly must items be posted after they are created, and is there a delivery-speed requirement?" | A duration with its unit, plus the speed need or "standard" | business | always | no |
| DP-PM-04 | Enclosures | — | "Do mailings include inserts or enclosures? If so, which ones?" | "None", or a list | business | always | no |
| DP-PM-05 | Address source | — | "Which system holds the mailing addresses?" | A named system | technical | always | no |
| DP-PM-06 | Returned mail | — | "What should happen to returned mail, and who handles it?" | An action, plus a team and contact (I1) | business | always | no |
| DP-PM-07 | Proof of mailing | — | "Do you need proof that an item was posted? If so, for what purpose?" | Yes plus the purpose, or no | business | always | no |

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-PM-01 | non-functional | Print and mail shall support {volumes}. | DP-PM-01 | `PRINT_MAIL_CAPABILITIES` |
| TR-PM-02 | functional | Mail shall be sent to {destinations}. | DP-PM-02 | `PRINT_MAIL_CAPABILITIES` |
| TR-PM-03 | non-functional | Items shall be posted within {duration} of creation, at {speed}. | DP-PM-03 | `PRINT_MAIL_CAPABILITIES` |
| TR-PM-04 | functional | Mailings shall include {enclosures}. | DP-PM-04 | only when any |
| TR-PM-05 | integration | Addresses shall be sourced from {system}. | DP-PM-05 | — |
| TR-PM-06 | operational | Returned mail shall be {action}, handled by {team}. | DP-PM-06 | — |
| TR-PM-07 | functional | Proof of mailing shall be retained for {purpose}. | DP-PM-07 | only when yes |

## Product specification (`printMail`)
`volumes*`, `destinations*`, `postingWindow*`, `speed*`, `enclosures*`, `addressSource*`, `returnedMail*`, `proofOfMailing*`.

## Reviews triggered
- **R-PM-1 Print and mail product team:** always.
