# DIS-D10: Domain: API onboarding (`apiOnboarding`)

**Purpose:** applications that call ECM APIs through the Apigee marketplace.

**Applicability question (CANDIDATE only):** "Will any application call ECM directly, for example to send documents, search for them or fetch them?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-API-01 | Calling applications | `systems.impactedSystems` | "Which applications will call ECM? What is each one's BAM App ID?" | For each: a name plus a BAM App ID, or "not yet registered" (raises R-CORE-2) | technical | always | no |
| DP-API-02 | Operations | — | "For each application, what will it do: send or upload documents, search, fetch, update document details, or delete?" | For each application: a list of operations | technical | always | **yes** |
| DP-API-03 | Call volumes | DP-REP-05 (as context) | "For each operation, roughly how many calls per hour on average and at the peak?" | Numbers with a unit, for each operation | technical | always | no |
| DP-API-04 | Response needs | — | "How fast must each operation respond?" | A duration with its unit, for each operation | technical | always | no |
| DP-API-05 | Largest document sent through the API | DP-CAP-02 (if present) | "What's the largest document sent through the API?" | A size with its unit | technical | DP-API-02 includes upload | no |
| DP-API-06 | Environments for subscription | DP-CORE-06 | "In which environments does each application need API access?" | A subset of DP-CORE-06 | technical | always | no |
| DP-API-07 | Subscription owner | — | "Who owns the Apigee subscription for each calling application?" | For each: an I1 contact | technical | always | no |
| DP-API-08 | Error and retry ownership | — | "When a call fails, which team owns retrying and fixing it?" | A team plus a contact | technical | always | no |

**Recalculation note:** if DP-API-02 includes upload and the virus-scan domain isn't already APPLICABLE, it becomes a CANDIDATE (DA-29). Also raise a P1 conflict, because uploads through the API mean content arrives by API, which `content.arrival` should reflect (a base correction).

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-API-01 | integration | {application} shall consume ECM APIs through an Apigee marketplace subscription owned by {owner}, in {environments}. | DP-API-01, DP-API-06, DP-API-07 | `APIGEE_PRODUCTS` |
| TR-API-02 | functional | {application} shall be able to {operations}. | DP-API-02 | `APIGEE_PRODUCTS` |
| TR-API-03 | non-functional | APIs shall support {average} calls per hour and peaks of {peak} for {operation}. | DP-API-03 | `API_RATE_LIMITS` |
| TR-API-04 | non-functional | {operation} shall respond within {duration}. | DP-API-04 | `REPOSITORY_SLA` |
| TR-API-05 | functional | The upload API shall accept documents up to {size}. | DP-API-05 | `MAX_FILE_SIZE` |
| TR-API-06 | operational | Failed calls shall be retried and resolved by {team}. | DP-API-08 | — |

## Product specification (`apiOnboarding`)
`consumers* [ {application, bamAppId, operations, environments, subscriptionOwner} ]`, `callVolumes*`, `responseNeeds*`, `maxPayload`, `errorOwnership*`.

## Reviews triggered
- **R-API-1 ECM integration architect:** always.
