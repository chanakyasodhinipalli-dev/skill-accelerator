# DIS-01: Input contract

Discovery starts only when **every** check below passes on the input it receives.

| # | Check |
|---|---|
| IC1 | `modelType = "ECMNormalizedDiscoveryContext"` and `schemaVersion = "1.0"` |
| IC2 | `status = "BASE_INTAKE_COMPLETE"` |
| IC3 | `intakeId` is present |
| IC4 | Every discovery-critical value is present and isn't an "unknown" value: `request.primaryCategory`, `request.currentBusinessApproach`, `request.needAndOutcome`, `ownership.requestor`, `ownership.productOwner`, `ownership.requestingLob`, and `content.types`, `content.actions`, `content.arrival`, `content.consumers`, `content.existingEcmUsage`, `content.monthlyVolumeBand`, `content.sensitivity`, `content.retentionRequired`, and `systems.hasNonEcmSystems`. |
| IC5 | When `systems.hasNonEcmSystems = "yes"`, `systems.impactedSystems` is non-empty and `systems.crossSystemFlow` is present. |
| IC6 | Every person object has a `fullName` plus an `employeeId` or `email`. |

## If a check fails
- Don't start discovery, and don't ask the requestor anything.
- Return to the workflow: `{ "result": "REJECTED_TO_ANALYSIS", "intakeId": "...", "failedChecks": ["IC4: content.actions missing"] }`.
- The workflow sends the intake back to ECMIntakeAnalysis. Discovery never edits or completes base fields to get past this contract.

## If every check passes
Copy the context unchanged into `baseContext` in the discovery model. `baseContext` is read-only. Corrections discovered later go to `baseCorrections` (see `DIS-06-follow-up-protocol.md`).
