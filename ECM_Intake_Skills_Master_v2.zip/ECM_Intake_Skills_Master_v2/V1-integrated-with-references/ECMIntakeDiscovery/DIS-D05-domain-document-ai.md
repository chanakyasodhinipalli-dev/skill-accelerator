# DIS-D05: Domain: Document AI / iDocs (`idocsAi`)

**Purpose:** classifying documents automatically and pulling data out of them.

**Applicability question (CANDIDATE only):** "Should ECM automatically recognise what each document is, or pull information out of it, so people don't have to key it in?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-AI-01 | Document kinds to classify | DP-REP-01, if satisfied | "Which kinds of document should be recognised automatically?" | Specific document names | business | always | no |
| DP-AI-02 | Fields to extract | — | "For each document kind, which pieces of information should be pulled out?" | For each kind: a list of field names, or "classification only" | business | always | no |
| DP-AI-03 | Use of the extracted data | `systems.impactedSystems` | "Where does the extracted information go, and what is it used for?" | A named system or process, plus its purpose | business | DP-AI-02 has fields | no |
| DP-AI-04 | Human review when confidence is low | — | "When the system isn't sure about a document or a value, who checks it?" | A team plus a named contact (I1) | business | always | no |
| DP-AI-05 | Language and handwriting | — | "Which languages appear in these documents? Is any of the content handwritten?" | A list of languages, plus handwriting yes or no (and where it appears) | business | always | no |
| DP-AI-06 | Sample availability | — | "Can you provide sample documents of each kind, approved for sharing under your data policy, so the classification can be trained? Who will provide them?" | Yes plus a contact (I1), or no plus the reason | business | always | no |

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-AI-01 | functional | The solution shall classify these document kinds automatically: {DP-AI-01}. Untrusted content shall be classified by iDocs using the DKE maintained by Imaging Governance. | DP-AI-01 | `IDOCS_CAPABILITIES` |
| TR-AI-02 | functional | The solution shall extract {fields} from {kind}. | DP-AI-02 | `IDOCS_CAPABILITIES` |
| TR-AI-03 | integration | Extracted data shall be delivered to {system or process} for {purpose}. | DP-AI-03 | — |
| TR-AI-04 | operational | Low-confidence results shall be routed to {team or contact} for review. | DP-AI-04 | — |
| TR-AI-05 | functional | Processing shall support {languages}, and handwriting where it appears ({where}). | DP-AI-05 | `IDOCS_CAPABILITIES` |
| TR-AI-06 | operational | Sample documents for training shall be provided by {contact}. | DP-AI-06 | — |

## Product specification (`idocsAi`)
`documentKinds*`, `extractionFields* {kind: [fields]}`, `extractedDataTarget`, `humanReview*`, `languages*`, `handwriting*`, `samples*`.

## Reviews triggered
- **R-AI-1 Imaging Governance:** always (trust decision and DKE).
- **R-AI-2 iDocs product team:** always.
