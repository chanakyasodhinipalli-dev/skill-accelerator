# DIS-06: Contextual follow-up protocol

## Make it contextual
Every question builds on what the requestor already said. For example: "You said customers upload documents through the portal. What file types do they upload, and what's the largest file you'd expect?" Use the base facts and earlier answers as context. Never ask for anything already known. Quote the base text only briefly.

## Message structure (one message per round)
1. **One opening line** with progress, for example "Discovery: 4 ECM services identified. I need 9 details to complete their specifications."
2. **Questions grouped by plain-language product name.** Use names like "Storing and retrieving documents", "Receiving documents", "Reading documents automatically", "Creating documents", "Printing and posting", "Malware scanning", "Electronic signatures", "System connections (APIs)", "System connections (events)", "Keeping and disposing of records", "Moving content from another system", "Overall design", "Testing and performance", "Application setup and access", and "Security and data protection". Use product names only where the requestor used them first.
3. **Each question**, numbered `D<round>-<n>`, includes:
   - The plain question, taken from the data point's **Ask** text.
   - **Why it's needed:** one clause, for technical items.
   - **Who is likely to know:** for `respondent: technical`, name the engineering lead or architect from the context, if one is assigned.
   - **Accepted forms:** units, options and formats, as a pattern. Never invent sample values.
   - **What was wrong:** for re-asks only, and without blame.
4. **Closing line:** they can answer in any order and in parts, or forward technical questions to the named person. Nothing proceeds until every question is answered.

Never show data-point IDs, rule IDs or the model.

## Validating answers
Each answer passes, in this order:
- (a) the data point's **Accept** rule;
- (b) `SHARED-01-quality-standards.md`;
- (c) `SHARED-02-identity-validation.md`, for person answers;
- (d) a consistency check against the base context and other answers.

A failure becomes `REJECTED` (BLOCKER) or `CLARIFY`, and the question is asked again in the next round.

## Base corrections
If an answer contradicts the base context, for example the base says 10,000 to 100,000 a month and the answer says 400,000 a month:
1. Don't pick one. Raise a P1 conflict: "Earlier you selected [base label]. You've now said [new value]. Which is right?"
2. Record the requestor's choice. If the new value wins, add a `baseCorrections` entry with their verbatim statement.
3. Re-run domain applicability and every dependent requirement (`DIS-07-recalculation.md`).

## "Not sure", skip and defer
These follow the same rules as analysis:
- Explain the item once.
- Offer the option of naming a knowledgeable person (full name plus ID or email). That records `pendingWith`, and the item stays open.
- Never choose an answer on their behalf.
- Never proceed past an open item. There is no round limit.

An answer like "whatever ECM recommends" or "use the standard" isn't accepted for a data point that needs a requestor fact. Explain that ECM needs their requirement in order to recommend anything.

## Completion message
Three short lines:
1. Discovery is complete.
2. The specification now goes to the ECM accountable reviewers, named by team only. No promises about outcomes or dates.
3. The reference ID.
