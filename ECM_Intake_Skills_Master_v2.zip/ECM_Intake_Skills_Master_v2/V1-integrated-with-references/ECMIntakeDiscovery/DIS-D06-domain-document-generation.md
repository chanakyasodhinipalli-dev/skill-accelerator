# DIS-D06: Domain: Document generation (`documentGeneration`)

**Purpose:** creating documents (letters, statements, notices) from templates and data.

**Applicability question (CANDIDATE only):** "Should ECM create documents, such as letters or statements, from templates and data as part of this request?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-GEN-01 | Documents to generate | — | "Which documents need to be created? Roughly how many different templates are there?" | Named documents, plus a template count | business | always | no |
| DP-GEN-02 | Data sources | `systems.impactedSystems` | "Which systems provide the information that goes into these documents?" | Named systems | technical | always | no |
| DP-GEN-03 | Trigger | — | "What causes a document to be created: a user request, a business event, or a scheduled run?" | `on-demand`, `event` (name the event) or `scheduled` (give the frequency) | business | always | no |
| DP-GEN-04 | Outputs and channels | — | "In what form are the documents produced, and how do they reach people (print, email, portal)?" | Formats plus channels | business | always | **yes** |
| DP-GEN-05 | Volumes | — | "How many of each document a month, and at the peak?" | Numbers with units, for each document | business | always | no |
| DP-GEN-06 | Language, branding and accessibility | — | "Which languages are needed? Are there branding or accessibility requirements?" | Languages, plus requirements or "none" | business | always | no |
| DP-GEN-07 | Template owner and approver | — | "Who owns the wording of these templates, and who must approve changes?" | Owner plus approver (I1 each) | business | always | no |
| DP-GEN-08 | Keep generated documents | — | "Must the generated documents be stored in ECM afterwards?" | Yes or no | business | always | **yes** |

**Recalculation notes:**
- If DP-GEN-04 includes print, the print-mail domain becomes a CANDIDATE.
- If DP-GEN-08 = yes, the ICMP repository domain becomes a CANDIDATE.

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-GEN-01 | functional | The solution shall generate {documents} from {count} templates. | DP-GEN-01 | `DOCGEN_CAPABILITIES` |
| TR-GEN-02 | integration | Document content shall be sourced from {systems}. | DP-GEN-02 | — |
| TR-GEN-03 | functional | Generation shall be triggered {trigger}. | DP-GEN-03 | — |
| TR-GEN-04 | functional | Documents shall be produced as {formats} and delivered by {channels}. | DP-GEN-04 | `DOCGEN_CAPABILITIES` |
| TR-GEN-05 | non-functional | Generation shall support {volumes}. | DP-GEN-05 | — |
| TR-GEN-06 | functional | Documents shall support {languages}, and {branding or accessibility}. | DP-GEN-06 | — |
| TR-GEN-07 | operational | Template changes shall be approved by {approver}. Content is owned by {owner}. | DP-GEN-07 | — |
| TR-GEN-08 | functional | Generated documents shall be stored in ECM. | DP-GEN-08 | only when yes |

## Product specification (`documentGeneration`)
`documents*`, `templateCount*`, `dataSources*`, `trigger*`, `outputs*`, `channels*`, `volumes*`, `languages*`, `branding`, `accessibility`, `templateOwner*`, `templateApprover*`, `storeGenerated*`.

## Reviews triggered
- **R-GEN-1 Document generation product team:** always.
- **R-GEN-2 Compliance wording review:** when the category is legal, regulatory or audit.
