# DIS-10: Discovery model output (handover to reviews)

Emit this once, when the completion gate passes. It is the final, canonical `ECMDiscoveryModel`, as described in `DIS-05-discovery-model-and-tracking.md`, with `status = DISCOVERY_COMPLETE`, plus this review package:

```json
{
  "reviewPackage": {
    "intakeId": "",
    "summary": {
      "title": "<baseContext.request.title>",
      "requestingLob": "",
      "primaryCategory": "<key>",
      "businessImpactLevel": "<key>",
      "requestedDeliveryDate": "YYYY-MM-DD | null",
      "productsRequired": [ { "productKey": "", "evidence": [ "DA-04: content.arrival=scan" ] } ],
      "productsConsideredNotRequired": [ { "productKey": "", "reason": "" } ]
    },
    "technicalRequirements": [ "...ACTIVE requirements, grouped by productKey..." ],
    "withdrawnRequirements": [ "...WITHDRAWN requirements with reasons..." ],
    "productSpecifications": { "<productKey>": { } },
    "environmentPlan": {
      "ladder": ["Innovation", "Non-Prod", "Production"],
      "targetEnvironments": [ "<from DP-CORE answers>" ],
      "restrictions": [ "<e.g. Innovation only — no scrum team allocated (ENV_NO_SCRUM_TEAM)>" ]
    },
    "fitChecks": [ { "requirementId": "", "configKey": "", "need": "" } ],
    "uncoveredNeeds": [ ],
    "baseCorrections": [ ],
    "reviewsRequired": [
      { "review": "<from domain references' 'Reviews triggered' sections>", "reason": "", "items": [ "requirement or spec ids" ] }
    ],
    "openRisksStatedByRequestor": [ "<verbatim from answers, if any>" ],
    "discoveryStats": { "rounds": 0, "questionsAsked": 0, "domainsEvaluated": 0, "requirementsActive": 0, "fitChecks": 0 }
  }
}
```

## Rules
- `reviewsRequired` is the union of each APPLICABLE domain's "Reviews triggered" section, with its conditions evaluated. Don't add any review that isn't defined there.
- Requirements and specifications appear exactly as they are in the model. Don't summarise or reword them.
- `openRisksStatedByRequestor` contains only risks the requestor stated. Never add your own risk assessment.
- After emitting the output, the skill takes no further action on this intake unless the workflow reopens discovery.
