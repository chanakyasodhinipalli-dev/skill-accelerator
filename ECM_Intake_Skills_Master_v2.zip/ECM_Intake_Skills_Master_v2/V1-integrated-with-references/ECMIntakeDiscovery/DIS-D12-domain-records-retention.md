# DIS-D12: Domain: Records and retention (`recordsRetention`)

**Purpose:** keeping content for the required period, holds, and controlled disposal.

**Applicability question (CANDIDATE only):** "Must any of these documents be kept for a set period because of a legal, regulatory or business rule?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-REC-01 | Record classes | — | "Under your organisation's records schedule, which record class or code applies to each document kind? A records management contact can confirm." | For each document kind: a class name or code, plus the schedule name | business | always | no |
| DP-REC-02 | Retention period and trigger | — | "For each document kind, how long must it be kept, and from when (for example, from account closure)?" | For each kind: a duration with its unit, a trigger event, and the source rule | business | always | no |
| DP-REC-03 | Disposal approval | — | "Who must approve destroying documents when the period ends?" | A team plus a named approver (I1), or "automatic disposal" plus the rule allowing it | business | always | no |
| DP-REC-04 | Holds | `ownership.governanceStakeholders` | "Can documents be put on hold to stop disposal, for example for litigation or audit? Who places and lifts holds?" | Yes plus a team and contact, or no | business | always | no |
| DP-REC-05 | Unchangeable storage | — | "Must documents be stored so they can never be changed? If so, which rule requires it?" | No, or yes plus a named rule | business | always | no |

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-REC-01 | data | {kind} shall be classified as {record class} under {schedule}. | DP-REC-01 | `RECORDS_SCHEDULE_SOURCE` |
| TR-REC-02 | data | {kind} shall be retained for {duration} from {trigger}, as required by {rule}. | DP-REC-02 | `RECORDS_SCHEDULE_SOURCE` |
| TR-REC-03 | operational | Disposal shall {require approval by {approver} / occur automatically under {rule}}. | DP-REC-03 | — |
| TR-REC-04 | functional | {team} shall be able to place and lift holds that prevent disposal. | DP-REC-04 | only when yes |
| TR-REC-05 | data | {kind} shall be stored unalterably, as required by {rule}. | DP-REC-05 | only when yes |

## Product specification (`recordsRetention`)
`recordClasses*`, `retention* [ {kind, duration, trigger, rule} ]`, `disposalApproval*`, `holds*`, `immutability*`.

## Reviews triggered
- **R-REC-1 Records management:** always.
- **R-REC-2 Legal:** when DP-REC-04 = yes or DP-REC-05 = yes.
