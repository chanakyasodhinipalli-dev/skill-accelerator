# ANA-02-T1: Field rules, tab 1: Requestor and Ownership

### requestorName
- **Class:** DC · **Type:** person
- **Accept:** a full name (given name plus family name) **and** an employee ID or corporate email, passing `SHARED-02-identity-validation.md`. It may be prefilled from the session identity (`source: "session-identity"`). That still counts as valid, but if the requestor replaces it, the replacement is validated in full.
- **Reject:** see `SHARED-02-identity-validation.md`. In particular, reject a role, team, pronoun, single name, or a name without an ID or email.
- **Clarify:** a different person from the session identity is entered, but no reason is given for submitting on their behalf. Ask whether they are submitting on someone else's behalf, and record the answer.
- **Ask:** "Please give the primary requestor's full name and their employee ID or work email."

### requestorRole
- **Class:** REQ · **Type:** text
- **Accept:** a specific role on this initiative, for example "Product Owner, Retail Lending Onboarding". At least 2 meaningful words.
- **Reject:** a single generic word on its own ("manager", "lead", "staff", "user", "employee"). Placeholders.
- **Clarify:** —
- **Ask:** "What is the requestor's role on this initiative? Please give the title and the area, not just a single word like 'manager'."

### requestingLob
- **Class:** DC · **Type:** text
- **Accept:** a named line of business, business area, product or program. It should be specific enough to tell it apart from other LOBs, for example "Consumer Banking – Mortgage Servicing".
- **Reject:** "business", "the business", "internal", "IT", "operations", "N/A", "our team", or any single generic word.
- **Clarify:** it names only a parent organisation that has several LOBs, for example only "Consumer Banking". Ask which business area within it.
- **Ask:** "Which specific line of business, business area, product or program is asking for this work?"

### sponsoringProductOwner
- **Class:** DC · **Type:** person
- **Accept:** a full name with an employee ID or corporate email (`SHARED-02-identity-validation.md`).
- **Reject:** a role or title ("Product Owner", "PO", "my manager"), "TBD", or "not assigned". This field is required, so an unassigned owner blocks completion.
- **Clarify:** the same person as `requestorName`. That is allowed, but confirm the requestor is also accountable for scope and priority.
- **Ask:** "Who is the product owner accountable for scope and priority? Please give their full name and employee ID or work email. If no one is assigned yet, this needs to be resolved before discovery can start."

### sponsoringArchitect
- **Class:** OPT · **Type:** person
- **Accept:** blank, the explicit option "Not yet assigned", or a full name with an employee ID or corporate email.
- **Reject:** a role or title ("architect", "LOB architect", "solution architect"), or a name without an ID or email.
- **Clarify:** —
- **Ask:** "If a sponsoring architect is assigned, please give their full name and employee ID or work email. If not, reply 'not yet assigned'."

### sponsoringEngineeringLead
- **Class:** OPT · **Type:** person
- **Accept / Reject / Ask:** the same as `sponsoringArchitect`, applied to the engineering lead.
- **Clarify:** `hasNonEcmSystems = yes`, or tab 3 has `contentArrival` including `api` or `event`, and this field is blank or "not yet assigned". Raise CLARIFY: "Integration work usually needs an engineering lead. Is one assigned?" The requestor can confirm "not yet assigned"; that is accepted and logged as INFO for reviewers.

### businessTeams
- **Class:** OPT · **Type:** textarea (list)
- **Accept:** blank, or a list in which every entry is a specific team or group name **and** at least one named contact with an ID or email (`SHARED-02-identity-validation.md`, team rules).
- **Reject:** generic entries ("business", "ops", "SMEs", "users", "stakeholders", "the team"). Contacts given only as roles.
- **Clarify:** —
- **Ask:** "For each business team that needs to take part, please give the team's name and one contact's full name with their employee ID or work email."

### governanceStakeholders
- **Class:** COND · **Type:** textarea (list)
- **Required when:** `contentSensitivity` contains any of `customerPii`, `employeePii`, `financial`, `health` or `legalPrivileged`; **or** `retentionRequired = yes`; **or** `primaryRequestCategory` is one of `legalRequirement`, `auditCommitment`, `regulatoryCommitment` or `riskRemediation`. Otherwise OPT.
- **Accept:** a list in which every entry is a specific governance function or team, for example "Enterprise Records Management" or "Information Security – Data Protection Office", **and** a named contact with an ID or email.
- **Reject:** a single generic word on its own ("Risk", "Compliance", "Legal", "Security") with no specific team or contact. "TBD". "All relevant teams".
- **Clarify:** the requirement condition is true, but none of the listed teams relate to that condition. For example, `contentSensitivity` contains `health` and no privacy or data-protection function is listed. Ask whether one is involved.
- **Ask:** "Because this request involves [condition in plain words], please name the governance or control teams that must review it, with a named contact (full name plus employee ID or work email) for each."

### ecmTechnicalTeams
- **Class:** OPT · **Type:** textarea (list)
- **Accept:** blank, or a list of specific ECM team names. A contact is optional here; if one is given, it must pass identity rules.
- **Reject:** "ECM", "ECM team" or "platform team" on its own.
- **Ask:** "If you already know which ECM teams should be involved, please give their specific team names. Otherwise leave this blank and ECM will confirm the teams during discovery."
