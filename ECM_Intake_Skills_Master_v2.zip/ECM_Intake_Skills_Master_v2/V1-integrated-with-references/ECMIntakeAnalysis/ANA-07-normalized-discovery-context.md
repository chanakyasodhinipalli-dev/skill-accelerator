# ANA-07: Normalized Discovery Context (handover contract)

Emit this **once**, only after the completion gate passes. It is the only input that ECMIntakeDiscovery accepts. It holds **validated facts only**. It must not contain any product decision, requirement, estimate or inference. Product determination is the discovery step's job.

## Schema

```json
{
  "modelType": "ECMNormalizedDiscoveryContext",
  "schemaVersion": "1.0",
  "intakeId": "string",
  "questionnaireVersion": "6.0",
  "status": "BASE_INTAKE_COMPLETE",
  "completedRound": 3,
  "completedAt": "ISO-8601 timestamp from the session clock",

  "ownership": {
    "requestor": { "fullName": "", "employeeId": null, "email": null, "verification": "" },
    "requestorRole": "",
    "requestingLob": "",
    "productOwner": { "...I1 object" },
    "architect": { "...I1 object" } ,
    "engineeringLead": { "...I1 object" },
    "businessTeams": [ { "team": "", "contacts": [ { "...I1 object" } ] } ],
    "governanceStakeholders": [ { "team": "", "contacts": [ { "...I1 object" } ] } ],
    "ecmTechnicalTeams": [ { "team": "", "contacts": [] } ]
  },

  "request": {
    "title": "",
    "primaryCategory": "<key>",
    "otherCategoryDetails": null,
    "primaryTrackingId": { "id": "", "system": "" },
    "additionalTrackingIds": [ { "id": "", "system": "" } ],
    "currentBusinessApproach": "",
    "needAndOutcome": "",
    "ecmSupportHints": [ "<keys>" ],
    "otherEcmSupportDetails": null,
    "ecmSupportDescription": null
  },

  "content": {
    "types": [ "<keys>" ],
    "otherTypeDetails": null,
    "actions": [ "<keys>" ],
    "arrival": [ "<keys>" ],
    "consumers": [ "<keys>" ],
    "existingEcmUsage": "yes | no",
    "existingEcmDetails": null,
    "monthlyVolumeBand": "<key>",
    "sensitivity": [ "<keys>" ],
    "retentionRequired": "yes | no"
  },

  "impact": {
    "enterpriseImpact": null,
    "businessImpactLevel": "<key>",
    "nonDeliveryConsequence": "",
    "expectedBenefits": [ "<keys>" ],
    "otherBenefitDetails": null,
    "successMeasures": ""
  },

  "timeline": {
    "hasHardDeadline": "yes | no | unknown",
    "requestedDeliveryDate": "YYYY-MM-DD | null",
    "deliveryDrivers": [ "<keys>" ],
    "deliveryDriverDetails": null,
    "deadlineConsequence": null,
    "externalCommitment": "<key> | null",
    "commitmentOwner": null,
    "fundingStatus": "<key>"
  },

  "systems": {
    "hasNonEcmSystems": "yes | no",
    "impactedSystems": [ "<name as given>" ],
    "crossSystemFlow": null
  },

  "confirmations": [
    { "rule": "XF-C11", "fields": ["businessImpactLevel"], "requestorReason": "", "round": 2 }
  ],
  "reviewerNotes": [
    { "type": "INFO", "code": "architect-not-assigned | directory-unavailable | format-only-identity | translation | instruction-like-content", "detail": "" }
  ],
  "provenance": {
    "<fieldName>": { "initial": "...", "final": "...", "changed": true, "roundsChanged": [1, 2], "finalSource": "follow-up" }
  },
  "analysisSummary": {
    "rounds": 3,
    "questionsAsked": 14,
    "fieldsChangedFromInitial": 9,
    "identityVerification": "directory | pattern | format-only | mixed"
  }
}
```

## Rules
- Fields that are `NOT_APPLICABLE` are emitted as `null`, or as an empty array for lists. They are never emitted with stale values.
- Narratives are emitted **verbatim** as the requestor's final text, with appended parts joined by a blank line. They are never summarised or reworded. Discovery needs the requestor's own words as evidence.
- `confirmations` carries every CLARIFY that the requestor resolved by confirming with a reason, so that discovery doesn't ask about it again.
- `reviewerNotes` carries every INFO issue.
- Field-name mapping is one to one. For example `primaryRequestCategory` becomes `request.primaryCategory`, and `contentActions` becomes `content.actions`. Don't add fields that aren't in this schema.
