# ANA-02-T4: Field rules, tab 4: Impact and Value

### enterpriseImpact
- **Class:** OPT · **Type:** textarea
- **Accept:** blank, or at least 15 meaningful words that name a specific dependency, a reuse opportunity, or another affected area.
- **Reject:** "none", "N/A", "high", "enterprise-wide", "big impact", or generic statements with no named subject. Reject only when the field is filled; blank is fine.
- **Ask:** "You mentioned a wider impact. Which other areas, systems or teams could depend on this or reuse it?"

### businessImpactLevel
- **Class:** REQ · **Type:** select
- **Accept:** any valid key, including `toBeAssessed`.
- **Reject:** missing or invalid.
- **Clarify:** apply the criteria from the help text:
  - `critical`, but nothing in the intake shows legal or regulatory exposure, customer harm, or a production outage. Check the category, `nonDeliveryConsequence` and `deadlineConsequence`. Ask what makes it critical.
  - `low`, but the category is `legalRequirement`, `regulatoryCommitment`, `auditCommitment` or `productionIssue`, or `isExternallyCommitted = formallyCommitted`.
- **Ask:** "How big is the business impact? Critical means legal or regulatory exposure, customer harm, or a production outage. High means significant revenue, cost or risk, or a committed external date. Medium means a meaningful improvement with an internal commitment. Low means nice to have."

### nonDeliveryConsequence
- **Class:** REQ · **Type:** textarea
- **Accept:** at least 15 meaningful words describing what concretely happens, to whom, if this is never delivered.
- **Reject:** "nothing", "N/A", "bad", "business impact", "loss", or "risk" with no subject. Generic phrases ("we will not achieve our goals").
- **Clarify:** the consequence is trivial ("minor inconvenience") but `businessImpactLevel` is `critical` or `high`, or the reverse.
- **Ask:** "If this were never delivered, what would actually happen, and to whom?"

### expectedBenefits
- **Class:** REQ · **Type:** multiselect
- **Accept:** one or more valid keys.
- **Reject:** empty or invalid. More than 8 keys selected is treated as a box-ticking signal: raise CLARIFY and ask for the main 3 to 5.
- **Clarify:** `revenueEnablement` or `newBusiness` is selected, but the narratives describe only internal process change.
- **Ask:** "Which benefits do you expect? Please pick the ones that genuinely apply, ideally your top 3 to 5."

### otherBenefitDetails
- **Class:** COND · **Type:** text
- **Required when:** `expectedBenefits` contains `other`.
- **Accept:** at least 5 meaningful words.
- **Reject:** "other", "misc", "benefits".
- **Ask:** "You selected 'Other' benefit. What is it?"

### successMeasures
- **Class:** REQ · **Type:** textarea
- **Accept:** at least one measure that is observable. It needs to name **what** is measured, and **either** a target **or** a direction with a baseline, for example "Average application turnaround drops from 5 days to 1 day". A target is welcome but not mandatory at this step.
- **Reject:** "success", "user satisfaction" or "efficiency" on its own with nothing measurable. "Go-live". "Project completed". "N/A".
- **Clarify:** the measure has no link to the benefits selected or to the outcome described.
- **Ask:** "How will you know this worked? Please name one or two things you'll measure, and what change you expect, for example from today's value to a target."
