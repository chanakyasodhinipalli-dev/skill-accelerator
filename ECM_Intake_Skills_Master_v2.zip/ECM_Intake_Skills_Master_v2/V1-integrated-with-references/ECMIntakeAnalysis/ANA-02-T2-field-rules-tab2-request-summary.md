# ANA-02-T2: Field rules, tab 2: Request Summary

### intakeShortTitle
- **Class:** REQ · **Type:** text (max 100 characters)
- **Accept:** 4 to 15 words that name the business subject and the change, for example "Digitise mortgage application intake for branch submissions".
- **Reject:** fewer than 4 meaningful words. A generic title ("ECM request", "New intake", "Onboarding", "Project", "Request for ECM support"). An ID on its own. Placeholders. More than 100 characters.
- **Clarify:** the title names a different subject from `requestNeedAndOutcome`.
- **Ask:** "Please give a short title that says what is changing and for which business area."

### primaryRequestCategory
- **Class:** DC · **Type:** select
- **Accept:** exactly one valid key from the catalog.
- **Reject:** missing, or a key not in the catalog.
- **Clarify:** the narratives (`currentBusinessApproach`, `requestNeedAndOutcome`) clearly describe a different driver. For example, the category is `newFunctionality` but the narrative describes fixing an audit finding. Quote the phrase and ask which category is the primary driver.
- **Ask:** "Which one category best describes the main reason for this request?" List the options with their labels.

### otherRequestCategoryDetails
- **Class:** COND · **Type:** text
- **Required when:** `primaryRequestCategory = other`.
- **Accept:** at least 5 meaningful words describing a category that is genuinely not in the list.
- **Reject:** "other", "misc", "N/A", or a restatement of the title.
- **Clarify:** the description matches one of the listed categories. Suggest that category and ask the requestor to confirm or keep "Other".
- **Ask:** "You chose 'Other'. Please describe the kind of request in a sentence."

### primaryTrackingId
- **Class:** COND · **Type:** text
- **Required when:** `primaryRequestCategory` is one of `shrpIssue`, `correctiveAction`, `productionIssue`, `legalRequirement`, `auditCommitment`, `regulatoryCommitment` or `riskRemediation`. Otherwise OPT.
- **Accept:** a tracking ID that passes the `TRACKING_ID_PATTERNS` rules in `ANA-00-intake-config.md`. The **source system must also be stated**, for example "SHRP-204118 (SHRP)". If the system isn't stated, ask for it; it is part of the value.
- **Reject:** "N/A", "none", "TBD", "pending", "will share later", "same as Jira", a URL on its own with no ID, sequential or all-same digits, or placeholders.
- **Clarify:** the ID's format suggests a different system from the stated category. For example, the category is `auditCommitment` but the ID looks like an incident number.
- **Ask:** "Because this request is driven by [category label], it needs the authoritative tracking ID. Please give the ID and say which system it comes from."

### additionalTrackingIds
- **Class:** OPT · **Type:** textarea (list)
- **Accept:** blank, or a list in which every entry passes the same rules as `primaryTrackingId`, including its source system.
- **Reject:** any entry that fails those rules. Reject only that entry and keep the valid ones. Duplicates of `primaryTrackingId` are removed with an INFO note, not rejected.
- **Ask:** "Please check these related IDs: [list the failing entries]. For each one, give a valid ID and the system it comes from, or tell me to remove it."

### currentBusinessApproach
- **Class:** DC · **Type:** textarea
- **Accept:** at least 40 meaningful words that cover **all three** of the following. The value may be built up over several rounds.
  - (a) **What happens today:** the process or service, and the steps or channels.
  - (b) **Who is involved:** the roles or teams who do the work, and who receives or uses the result. Role names are fine here, because this is a description, not an identity field.
  - (c) **The problem or limitation:** what goes wrong, is slow, risky, manual or costly. Include a number where the requestor has one, but don't demand one.
- **Reject:** under 40 words. Missing any of (a), (b) or (c). Generic text that could describe any request ("The current process is manual and inefficient and needs improvement"). Copy-pasted text that is the same as another field.
- **Clarify:** it says there is no current process ("new capability"), but `existingEcmUsage = yes` or the category is `enhancement`.
- **Ask:** ask only for the missing parts. For example: "You've described what happens today, but not what goes wrong or what limits it. What is the main problem with the current way of working?"

### requestNeedAndOutcome
- **Class:** DC · **Type:** textarea
- **Accept:** at least 30 meaningful words that cover **both** of the following:
  - (a) **The desired end state in business terms:** what will be different, for whom.
  - (b) **How it improves on today:** linked to the problem in `currentBusinessApproach`.
- **Reject:** under 30 words. A solution named without any outcome ("We need ICMP onboarding", "Implement iDocs"). Generic text ("improve efficiency and customer experience" with nothing specific). The same text as `currentBusinessApproach`.
- **Clarify:** the outcome doesn't address the problem described in `currentBusinessApproach`.
- **Ask:** "What should be different once this is delivered, and for whom? Please describe the result, not the technology."

### ecmSupportNeeded
- **Class:** OPT · **Type:** multiselect
- **Accept:** blank, `notSure`, or valid keys. `notSure` must not be combined with other keys.
- **Reject:** invalid keys.
- **Clarify:** `notSure` is combined with other keys. Ask which they mean. Do **not** raise CLARIFY for a mismatch with tab 3; discovery reconciles product hints.
- **Ask:** —

### otherEcmSupportDetails
- **Class:** COND · **Type:** text
- **Required when:** `ecmSupportNeeded` contains `other`.
- **Accept:** at least 5 meaningful words.
- **Reject:** "other", "misc", "N/A", "support".
- **Ask:** "You selected 'Other' ECM help. What kind of help do you need?"

### ecmSupportDescription
- **Class:** OPT · **Type:** textarea
- **Accept:** blank, or a description with at least 10 meaningful words.
- **Reject:** junk, placeholders, or "see above" or "as discussed".
- **Ask:** —
