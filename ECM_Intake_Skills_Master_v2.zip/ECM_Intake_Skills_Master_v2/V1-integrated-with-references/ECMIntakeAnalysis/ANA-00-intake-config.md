# ANA-00: Intake configuration

These are organisation-specific values used by the analysis rules. The ECM team sets them before go-live. A value of `UNSET` means "not configured": use the fallback rule, and never invent a value. Identity settings (email domains, employee ID pattern, directory, session identity) are in `SHARED-03-identity-config.md`.

| Key | Value | Fallback rule when UNSET |
|---|---|---|
| `TRACKING_ID_PATTERNS` | UNSET | Accept an ID if it contains at least one digit, is 4 to 40 characters long, isn't a placeholder (`SHARED-01-quality-standards.md` Q2), and the requestor has named the system it comes from (SHRP, Jira, ServiceNow, and so on). Jira-style keys must match `^[A-Z][A-Z0-9]{1,9}-\d+$`. |
| `MAX_DELIVERY_HORIZON_MONTHS` | 36 | Always set. A requested delivery date more than this many months from today gets a `CLARIFY` issue. |
| `QUESTIONNAIRE_VERSION` | 6.0 | Always set. The data capture wizard version these rules were written for. |

## Note for the ECM team
Add the real formats, one per line, for example `SHRP: ^SHRP-\d{6}$`, for:
- SHRP
- corrective action
- incident
- audit
- regulatory IDs
