# ANA-01: Field catalog

This is the authoritative list of the 46 Step 1 fields, generated from `ECM_Business_Intake_Step1_Triage_v6_0.xlsx`. Regenerate it from the workbook whenever the questionnaire changes; don't edit it by hand. Option values are written `label → key`; the record and every rule use the **key**.

## Field classes

| Class | Meaning |
|---|---|
| `DC` | Discovery-critical. Must be valid and specific. "Not sure" or "unknown" is never accepted. |
| `REQ` | Always required. |
| `COND` | Required only while its condition (an `XF-R` rule in `ANA-03-cross-field-rules.md`) is true. Otherwise `NOT_APPLICABLE`. |
| `OPT` | May be blank. A value that is given must still pass every rule. |

## How the field-rule references are written

Each field-rule reference (one per wizard tab, listed in the table below) has one block per field, in wizard order. Every block uses these labels:

- **Class**
  - `DC`: discovery-critical. The value must be valid and specific. "Not sure" or "unknown" is never accepted, and the field blocks completion until it is resolved.
  - `REQ`: always required. Accepted options include any honest "unknown"-type option that the field block explicitly allows.
  - `COND`: required only when its condition is true. When the condition is false, the field's status is `NOT_APPLICABLE`, and any value it holds is kept in history but excluded from the normalized output.
  - `OPT`: may be blank. If a value is given, it must pass every quality and identity rule, because junk is never accepted, even in optional fields.
- **Type**: as in this catalog.
- **Accept**: what a valid value looks like.
- **Reject (BLOCKER)**: conditions that make the value unacceptable.
- **Clarify (CLARIFY)**: conditions that need confirmation or correction.
- **Ask**: the plain-language follow-up to adapt. Never include example values that could be mistaken for the requestor's real data.

The general rules in `SHARED-01-quality-standards.md` (junk, placeholders, fakes, duplicates, label echoes) apply to every text field, in addition to the rules here. The person rules in `SHARED-02-identity-validation.md` apply to every `person` field and to every named contact inside a team field.

Word counts mean meaningful words. Stop-words, filler phrases and repeated words don't count.

## Field list

| # | Field | Tab | Type | Class | Required rule | Shown when | Depends on (re-validate when these change) | Rules in |
|---|---|---|---|---|---|---|---|---|
| 1 | `requestorName` | 1 Requestor and Ownership | person | DC | — | always | — | `ANA-02-T1-field-rules-tab1-requestor-ownership.md` |
| 2 | `requestorRole` | 1 Requestor and Ownership | text | REQ | — | always | — | `ANA-02-T1-field-rules-tab1-requestor-ownership.md` |
| 3 | `requestingLob` | 1 Requestor and Ownership | text | DC | — | always | — | `ANA-02-T1-field-rules-tab1-requestor-ownership.md` |
| 4 | `sponsoringProductOwner` | 1 Requestor and Ownership | person | DC | — | always | — | `ANA-02-T1-field-rules-tab1-requestor-ownership.md` |
| 5 | `sponsoringArchitect` | 1 Requestor and Ownership | person | OPT | — | always | — | `ANA-02-T1-field-rules-tab1-requestor-ownership.md` |
| 6 | `sponsoringEngineeringLead` | 1 Requestor and Ownership | person | OPT | — | always | `contentArrival`, `contentConsumers`, `hasNonEcmSystems` | `ANA-02-T1-field-rules-tab1-requestor-ownership.md` |
| 7 | `businessTeams` | 1 Requestor and Ownership | textarea | OPT | — | always | — | `ANA-02-T1-field-rules-tab1-requestor-ownership.md` |
| 8 | `governanceStakeholders` | 1 Requestor and Ownership | textarea | COND | XF-R11 | always | `contentSensitivity`, `primaryRequestCategory`, `retentionRequired` | `ANA-02-T1-field-rules-tab1-requestor-ownership.md` |
| 9 | `ecmTechnicalTeams` | 1 Requestor and Ownership | textarea | OPT | — | always | — | `ANA-02-T1-field-rules-tab1-requestor-ownership.md` |
| 10 | `intakeShortTitle` | 2 Request Summary | text | REQ | — | always | `requestNeedAndOutcome` | `ANA-02-T2-field-rules-tab2-request-summary.md` |
| 11 | `primaryRequestCategory` | 2 Request Summary | select | DC | — | always | `additionalTrackingIds`, `businessImpactLevel`, `contentSensitivity`, `crossSystemImpactSummary`, `currentBusinessApproach`, `deadlineConsequence`, `deliveryDriver`, `deliveryDriverDetails`, `deliveryFundingStatus`, `ecmSupportDescription`, `enterpriseImpact`, `governanceStakeholders`, `isExternallyCommitted`, `nonDeliveryConsequence`, `primaryTrackingId`, `requestNeedAndOutcome`, `retentionRequired` | `ANA-02-T2-field-rules-tab2-request-summary.md` |
| 12 | `otherRequestCategoryDetails` | 2 Request Summary | text | COND | XF-R1 | primaryRequestCategory = other | `primaryRequestCategory` | `ANA-02-T2-field-rules-tab2-request-summary.md` |
| 13 | `primaryTrackingId` | 2 Request Summary | text | COND | XF-R2 | always | `additionalTrackingIds`, `deliveryDriver`, `primaryRequestCategory` | `ANA-02-T2-field-rules-tab2-request-summary.md` |
| 14 | `additionalTrackingIds` | 2 Request Summary | textarea | OPT | — | always | `deliveryDriver`, `primaryRequestCategory`, `primaryTrackingId` | `ANA-02-T2-field-rules-tab2-request-summary.md` |
| 15 | `currentBusinessApproach` | 2 Request Summary | textarea | DC | — | always | `contentSensitivity`, `crossSystemImpactSummary`, `deliveryDriverDetails`, `ecmSupportDescription`, `enterpriseImpact`, `existingEcmUsage`, `hasNonEcmSystems`, `monthlyVolumeBand`, `primaryRequestCategory`, `requestNeedAndOutcome` | `ANA-02-T2-field-rules-tab2-request-summary.md` |
| 16 | `requestNeedAndOutcome` | 2 Request Summary | textarea | DC | — | always | `contentSensitivity`, `crossSystemImpactSummary`, `currentBusinessApproach`, `deliveryDriverDetails`, `ecmSupportDescription`, `enterpriseImpact`, `existingEcmUsage`, `hasNonEcmSystems`, `intakeShortTitle`, `monthlyVolumeBand`, `primaryRequestCategory` | `ANA-02-T2-field-rules-tab2-request-summary.md` |
| 17 | `ecmSupportNeeded` | 2 Request Summary | multiselect | OPT | — | always | — | `ANA-02-T2-field-rules-tab2-request-summary.md` |
| 18 | `otherEcmSupportDetails` | 2 Request Summary | text | COND | XF-R3 | ecmSupportNeeded contains other | `ecmSupportNeeded` | `ANA-02-T2-field-rules-tab2-request-summary.md` |
| 19 | `ecmSupportDescription` | 2 Request Summary | textarea | OPT | — | always | `contentSensitivity`, `crossSystemImpactSummary`, `currentBusinessApproach`, `deliveryDriverDetails`, `enterpriseImpact`, `existingEcmUsage`, `hasNonEcmSystems`, `monthlyVolumeBand`, `primaryRequestCategory`, `requestNeedAndOutcome` | `ANA-02-T2-field-rules-tab2-request-summary.md` |
| 20 | `contentTypes` | 3 Content and Usage | multiselect | DC | — | always | `contentActions`, `contentArrival` | `ANA-02-T3-field-rules-tab3-content-usage.md` |
| 21 | `otherContentTypeDetails` | 3 Content and Usage | text | COND | XF-R4 | contentTypes contains other | `contentTypes` | `ANA-02-T3-field-rules-tab3-content-usage.md` |
| 22 | `contentActions` | 3 Content and Usage | multiselect | DC | — | always | `contentTypes`, `retentionRequired` | `ANA-02-T3-field-rules-tab3-content-usage.md` |
| 23 | `contentArrival` | 3 Content and Usage | multiselect | DC | — | always | `contentConsumers`, `contentTypes`, `hasNonEcmSystems`, `sponsoringEngineeringLead` | `ANA-02-T3-field-rules-tab3-content-usage.md` |
| 24 | `contentConsumers` | 3 Content and Usage | multiselect | DC | — | always | `contentArrival`, `hasNonEcmSystems`, `sponsoringEngineeringLead` | `ANA-02-T3-field-rules-tab3-content-usage.md` |
| 25 | `existingEcmUsage` | 3 Content and Usage | select | DC | — | always | `crossSystemImpactSummary`, `currentBusinessApproach`, `deliveryDriverDetails`, `ecmSupportDescription`, `enterpriseImpact`, `requestNeedAndOutcome` | `ANA-02-T3-field-rules-tab3-content-usage.md` |
| 26 | `existingEcmDetails` | 3 Content and Usage | textarea | COND | XF-R5 | existingEcmUsage = yes | `existingEcmUsage` | `ANA-02-T3-field-rules-tab3-content-usage.md` |
| 27 | `monthlyVolumeBand` | 3 Content and Usage | select | DC | — | always | `crossSystemImpactSummary`, `currentBusinessApproach`, `deliveryDriverDetails`, `ecmSupportDescription`, `enterpriseImpact`, `requestNeedAndOutcome` | `ANA-02-T3-field-rules-tab3-content-usage.md` |
| 28 | `contentSensitivity` | 3 Content and Usage | multiselect | DC | — | always | `crossSystemImpactSummary`, `currentBusinessApproach`, `deliveryDriverDetails`, `ecmSupportDescription`, `enterpriseImpact`, `governanceStakeholders`, `primaryRequestCategory`, `requestNeedAndOutcome`, `retentionRequired` | `ANA-02-T3-field-rules-tab3-content-usage.md` |
| 29 | `retentionRequired` | 3 Content and Usage | select | DC | — | always | `contentActions`, `contentSensitivity`, `governanceStakeholders`, `primaryRequestCategory` | `ANA-02-T3-field-rules-tab3-content-usage.md` |
| 30 | `enterpriseImpact` | 4 Impact and Value | textarea | OPT | — | always | `contentSensitivity`, `crossSystemImpactSummary`, `currentBusinessApproach`, `deliveryDriverDetails`, `ecmSupportDescription`, `existingEcmUsage`, `hasNonEcmSystems`, `monthlyVolumeBand`, `primaryRequestCategory`, `requestNeedAndOutcome` | `ANA-02-T4-field-rules-tab4-impact-value.md` |
| 31 | `businessImpactLevel` | 4 Impact and Value | select | REQ | — | always | `deadlineConsequence`, `isExternallyCommitted`, `nonDeliveryConsequence`, `primaryRequestCategory` | `ANA-02-T4-field-rules-tab4-impact-value.md` |
| 32 | `nonDeliveryConsequence` | 4 Impact and Value | textarea | REQ | — | always | `businessImpactLevel`, `deadlineConsequence`, `isExternallyCommitted`, `primaryRequestCategory` | `ANA-02-T4-field-rules-tab4-impact-value.md` |
| 33 | `expectedBenefits` | 4 Impact and Value | multiselect | REQ | — | always | `successMeasures` | `ANA-02-T4-field-rules-tab4-impact-value.md` |
| 34 | `otherBenefitDetails` | 4 Impact and Value | text | COND | XF-R6 | expectedBenefits contains other | `expectedBenefits` | `ANA-02-T4-field-rules-tab4-impact-value.md` |
| 35 | `successMeasures` | 4 Impact and Value | textarea | REQ | — | always | `expectedBenefits` | `ANA-02-T4-field-rules-tab4-impact-value.md` |
| 36 | `hasHardDeadline` | 5 Timeline and Funding | select | REQ | — | always | `deliveryDriver`, `isExternallyCommitted` | `ANA-02-T5-field-rules-tab5-timeline-funding.md` |
| 37 | `requestedDeliveryDate` | 5 Timeline and Funding | date | COND | XF-R7 | always | `hasHardDeadline` | `ANA-02-T5-field-rules-tab5-timeline-funding.md` |
| 38 | `deliveryDriver` | 5 Timeline and Funding | multiselect | COND | XF-R8 | requestedDeliveryDate is not empty | `additionalTrackingIds`, `hasHardDeadline`, `isExternallyCommitted`, `primaryRequestCategory`, `primaryTrackingId`, `requestedDeliveryDate` | `ANA-02-T5-field-rules-tab5-timeline-funding.md` |
| 39 | `deliveryDriverDetails` | 5 Timeline and Funding | textarea | COND | XF-R8 | requestedDeliveryDate is not empty | `contentSensitivity`, `crossSystemImpactSummary`, `currentBusinessApproach`, `ecmSupportDescription`, `enterpriseImpact`, `existingEcmUsage`, `hasNonEcmSystems`, `monthlyVolumeBand`, `primaryRequestCategory`, `requestNeedAndOutcome`, `requestedDeliveryDate` | `ANA-02-T5-field-rules-tab5-timeline-funding.md` |
| 40 | `deadlineConsequence` | 5 Timeline and Funding | textarea | COND | XF-R7 | hasHardDeadline = yes | `businessImpactLevel`, `hasHardDeadline`, `isExternallyCommitted`, `nonDeliveryConsequence`, `primaryRequestCategory` | `ANA-02-T5-field-rules-tab5-timeline-funding.md` |
| 41 | `isExternallyCommitted` | 5 Timeline and Funding | select | COND | XF-R8 | requestedDeliveryDate is not empty | `businessImpactLevel`, `deadlineConsequence`, `deliveryDriver`, `hasHardDeadline`, `nonDeliveryConsequence`, `primaryRequestCategory`, `requestedDeliveryDate` | `ANA-02-T5-field-rules-tab5-timeline-funding.md` |
| 42 | `deliveryCommitmentOwner` | 5 Timeline and Funding | person | COND | XF-R9 | isExternallyCommitted in (formallyCommitted, informallyCommunicated) | `isExternallyCommitted` | `ANA-02-T5-field-rules-tab5-timeline-funding.md` |
| 43 | `deliveryFundingStatus` | 5 Timeline and Funding | select | REQ | — | always | `primaryRequestCategory` | `ANA-02-T5-field-rules-tab5-timeline-funding.md` |
| 44 | `hasNonEcmSystems` | 6 Connected Systems | select | DC | — | always | `contentArrival`, `contentConsumers`, `crossSystemImpactSummary`, `currentBusinessApproach`, `deliveryDriverDetails`, `ecmSupportDescription`, `enterpriseImpact`, `requestNeedAndOutcome`, `sponsoringEngineeringLead` | `ANA-02-T6-field-rules-tab6-connected-systems.md` |
| 45 | `impactedSystemNames` | 6 Connected Systems | textarea | COND | XF-R10 | hasNonEcmSystems = yes | `crossSystemImpactSummary`, `hasNonEcmSystems` | `ANA-02-T6-field-rules-tab6-connected-systems.md` |
| 46 | `crossSystemImpactSummary` | 6 Connected Systems | textarea | COND | XF-R10 | hasNonEcmSystems = yes | `contentSensitivity`, `currentBusinessApproach`, `deliveryDriverDetails`, `ecmSupportDescription`, `enterpriseImpact`, `existingEcmUsage`, `hasNonEcmSystems`, `impactedSystemNames`, `monthlyVolumeBand`, `primaryRequestCategory`, `requestNeedAndOutcome` | `ANA-02-T6-field-rules-tab6-connected-systems.md` |

## Cross-field rules per field

| Field | Cross-field consistency rules that read it |
|---|---|
| `sponsoringEngineeringLead` | XF-C18 |
| `governanceStakeholders` | XF-C20 |
| `intakeShortTitle` | XF-C19 |
| `primaryRequestCategory` | XF-C11, XF-C13, XF-C14, XF-C17, XF-C20 |
| `primaryTrackingId` | XF-C13 |
| `additionalTrackingIds` | XF-C13 |
| `currentBusinessApproach` | XF-C6, XF-C8, XF-C9, XF-C10, XF-C14, XF-C15, XF-C21 |
| `requestNeedAndOutcome` | XF-C6, XF-C8, XF-C9, XF-C10, XF-C14, XF-C15, XF-C19, XF-C21 |
| `ecmSupportDescription` | XF-C6, XF-C8, XF-C9, XF-C10, XF-C14, XF-C21 |
| `contentTypes` | XF-C1, XF-C2, XF-C3 |
| `contentActions` | XF-C2, XF-C3, XF-C4 |
| `contentArrival` | XF-C1, XF-C5, XF-C18 |
| `contentConsumers` | XF-C5, XF-C18 |
| `existingEcmUsage` | XF-C8 |
| `monthlyVolumeBand` | XF-C9 |
| `contentSensitivity` | XF-C10, XF-C20 |
| `retentionRequired` | XF-C4, XF-C20 |
| `enterpriseImpact` | XF-C6, XF-C8, XF-C9, XF-C10, XF-C14, XF-C21 |
| `businessImpactLevel` | XF-C11 |
| `nonDeliveryConsequence` | XF-C11 |
| `expectedBenefits` | XF-C16 |
| `successMeasures` | XF-C16 |
| `hasHardDeadline` | XF-C12 |
| `deliveryDriver` | XF-C12, XF-C13 |
| `deliveryDriverDetails` | XF-C6, XF-C8, XF-C9, XF-C10, XF-C14, XF-C21 |
| `deadlineConsequence` | XF-C11 |
| `isExternallyCommitted` | XF-C11, XF-C12 |
| `deliveryFundingStatus` | XF-C17 |
| `hasNonEcmSystems` | XF-C5, XF-C6, XF-C18 |
| `impactedSystemNames` | XF-C7 |
| `crossSystemImpactSummary` | XF-C6, XF-C7, XF-C8, XF-C9, XF-C10, XF-C14, XF-C21 |

## Options (select and multiselect fields)

**`primaryRequestCategory`** (select): New functionality → `newFunctionality`; Enhancement to an existing capability → `enhancement`; SHRP issue → `shrpIssue`; Corrective action → `correctiveAction`; Production issue or stabilization → `productionIssue`; Legal requirement → `legalRequirement`; Audit finding or commitment → `auditCommitment`; Regulatory commitment → `regulatoryCommitment`; Risk or control remediation → `riskRemediation`; Business process or operating-model change → `businessChange`; Technology modernization or platform upgrade → `modernization`; Other → `other`

**`ecmSupportNeeded`** (multiselect): Not sure - let ECM recommend → `notSure`; Business intake and discovery → `intakeDiscovery`; Solution architecture → `solutionArchitecture`; Content repository or ICMP onboarding → `icmpOnboarding`; Content capture (scan, upload, email intake) → `contentCapture`; Document AI or iDocs (classify, extract) → `idocsAi`; Document generation → `documentGeneration`; Print and mail → `printMail`; Virus scanning → `virusScan`; eSignature → `eSignature`; API onboarding → `apiOnboarding`; Kafka or event integration → `eventIntegration`; Records and retention → `recordsRetention`; Content migration → `contentMigration`; Testing support → `testingSupport`; Other → `other`

**`contentTypes`** (multiselect): Scanned paper documents → `scannedPaper`; Digital documents such as PDF or Word → `digitalDocuments`; Images or photos → `images`; Emails and attachments → `emails`; Electronic forms → `eForms`; Letters, statements, or notices we send out → `outboundCorrespondence`; Signed agreements or contracts → `signedAgreements`; Audio or video → `audioVideo`; Other → `other`

**`contentActions`** (multiselect): Receive or collect it → `receive`; Store and manage it securely → `store`; Search, view, or retrieve it → `retrieve`; Automatically classify it or pull data out of it → `classifyExtract`; Create documents from templates or data → `generate`; Collect signatures → `sign`; Print and mail it → `printMail`; Keep it for a required period, then dispose of it → `retain`; Move it from another system → `migrate`; Check it for viruses or malware → `virusScan`; Not sure → `notSure`

**`contentArrival`** (multiselect): Scanned from paper → `scan`; Uploaded by staff or customers → `userUpload`; By email → `email`; Sent by another system through an API → `api`; Scheduled batch file transfer → `batch`; Real-time events or messages → `event`; We create it ourselves → `generated`; Not sure → `notSure`

**`contentConsumers`** (multiselect): Employees through a web screen → `employeeUi`; Customers through a portal or app → `customerChannel`; Another application through an API → `systemApi`; Another application through events or messages → `systemEvent`; Reporting or analytics → `reporting`; Auditors or regulators → `auditRegulator`; Not sure → `notSure`

**`existingEcmUsage`** (select): Yes → `yes`; No - new to ECM → `no`; Not sure → `unsure`

**`monthlyVolumeBand`** (select): Under 10,000 → `lt10k`; 10,000 to 100,000 → `10kTo100k`; 100,000 to 1 million → `100kTo1m`; 1 million to 10 million → `1mTo10m`; Over 10 million → `gt10m`; Not known yet → `unknown`

**`contentSensitivity`** (multiselect): Customer personal information → `customerPii`; Employee personal information → `employeePii`; Financial or account information → `financial`; Health information → `health`; Legal or privileged material → `legalPrivileged`; Internal business information only → `internalOnly`; Not sure → `notSure`

**`retentionRequired`** (select): Yes → `yes`; No → `no`; Not sure → `unsure`

**`businessImpactLevel`** (select): Critical → `critical`; High → `high`; Medium → `medium`; Low → `low`; Needs assessment → `toBeAssessed`

**`expectedBenefits`** (multiselect): Improved customer or user experience → `customerExperience`; Reduced business or operational risk → `riskReduction`; Regulatory or audit compliance → `compliance`; Operational efficiency → `operationalEfficiency`; Cost avoidance → `costAvoidance`; Direct cost reduction → `costReduction`; Revenue or growth enablement → `revenueEnablement`; Control improvement → `controlImprovement`; Cycle-time reduction → `cycleTime`; Improved data quality → `dataQuality`; Platform simplification → `platformSimplification`; Enterprise reuse → `enterpriseReuse`; Improved employee experience → `employeeExperience`; New business → `newBusiness`; Other → `other`

**`hasHardDeadline`** (select): Yes → `yes`; No → `no`; Not yet confirmed → `unknown`

**`deliveryDriver`** (multiselect): Customer commitment → `customerCommitment`; Legal requirement → `legalRequirement`; Regulatory commitment → `regulatoryCommitment`; Audit commitment → `auditCommitment`; SHRP issue → `shrpIssue`; Corrective action → `correctiveAction`; Program or release milestone → `programMilestone`; Contract or vendor end date → `contractEnd`; Technology end of life → `endOfLife`; Business launch or event → `businessEvent`; Other → `other`

**`isExternallyCommitted`** (select): Yes - formally committed → `formallyCommitted`; Yes - informally communicated → `informallyCommunicated`; No → `no`; Not sure → `unsure`

**`deliveryFundingStatus`** (select): Fully approved → `approved`; Partially approved → `partiallyApproved`; Approval pending → `pending`; Not yet requested → `notRequested`; Not required (run budget) → `notRequired`

**`hasNonEcmSystems`** (select): Yes → `yes`; No → `no`; Not sure → `unsure`

## Question text (as shown in the wizard)

| Field | Question |
|---|---|
| `requestorName` | Who is the primary requestor and accountable business contact for this intake? |
| `requestorRole` | What is the requestor's product or business role for this initiative? |
| `requestingLob` | Which line of business, business area, product, or program is requesting the work? |
| `sponsoringProductOwner` | Who is the sponsoring product owner accountable for business scope and priority? |
| `sponsoringArchitect` | Who is the sponsoring LOB architect for this request? |
| `sponsoringEngineeringLead` | Who is the sponsoring engineering lead accountable for technical delivery? |
| `businessTeams` | Which business teams, subject-matter experts, operations groups, or approvers must take part? |
| `governanceStakeholders` | Which governance, control, or stakeholder teams must review, decide, approve, or provide evidence? |
| `ecmTechnicalTeams` | If you already know which ECM teams should be involved, name them. |
| `intakeShortTitle` | Provide a short, business-friendly title that clearly summarizes this ECM intake request. |
| `primaryRequestCategory` | Which single category best describes the primary reason or business driver for this request? |
| `otherRequestCategoryDetails` | If you selected Other, describe the request category that was not listed. |
| `primaryTrackingId` | Enter the primary SHRP, corrective action, incident, legal, audit, regulatory, risk, program, epic, or other authoritative tracking ID. |
| `additionalTrackingIds` | List any additional issue, action, incident, legal, audit, risk, regulatory, program, epic, or work-item IDs related to this request. |
| `currentBusinessApproach` | Describe how this works today: the current business process, capability, or service, and how it affects people, customers, controls, or outcomes. |
| `requestNeedAndOutcome` | What change, opportunity, or outcome is this request meant to deliver, and how will it improve the current approach? |
| `ecmSupportNeeded` | If you already know which kinds of ECM help you need, select them. |
| `otherEcmSupportDetails` | If you selected Other, describe the additional support that is not listed. |
| `ecmSupportDescription` | Is there anything specific you already know you need ECM to provide, decide, design, integrate, change, test, or support? |
| `contentTypes` | What kinds of content are involved? Select all that apply. |
| `otherContentTypeDetails` | If you selected Other content, describe it. |
| `contentActions` | What needs to happen to this content? Select all that apply. |
| `contentArrival` | How does the content arrive? Select all that apply. |
| `contentConsumers` | Who or what needs to use the content once it is stored? Select all that apply. |
| `existingEcmUsage` | Does this application or business area already use ECM or ICMP today? |
| `existingEcmDetails` | Which ECM capabilities or applications are already in use? |
| `monthlyVolumeBand` | Roughly how many documents or items will be handled per month? |
| `contentSensitivity` | Does the content include any of the following? Select all that apply. |
| `retentionRequired` | Do legal, regulatory, or business rules require keeping this content for a set period? |
| `enterpriseImpact` | What broader enterprise impact, dependency, or reuse opportunity does this request create? |
| `businessImpactLevel` | What is the overall business impact level of this request? |
| `nonDeliveryConsequence` | What is the consequence of not doing this at all? |
| `expectedBenefits` | Which types of benefits are expected from this work? Select all that apply. |
| `otherBenefitDetails` | If you selected Other benefit, describe the benefit that was not listed. |
| `successMeasures` | How will you know the change worked? |
| `hasHardDeadline` | Does this request have a hard deadline that cannot move without material business impact? |
| `requestedDeliveryDate` | What date is requested for ECM delivery, production readiness, business validation, or the committed milestone? |
| `deliveryDriver` | What is driving the requested date? Select all that apply. |
| `deliveryDriverDetails` | Describe the commitment, event, milestone, dependency, or obligation that makes this date necessary. |
| `deadlineConsequence` | If the date is missed, what outcome, commitment, dependency, or opportunity is affected? |
| `isExternallyCommitted` | Has the requested date been committed or communicated outside the immediate request team? |
| `deliveryCommitmentOwner` | Who owns, approved, or communicated the delivery commitment? |
| `deliveryFundingStatus` | What is the current funding status for this request? |
| `hasNonEcmSystems` | Are any applications, platforms, services, vendors, business processes, or technical teams outside ECM affected by this request? |
| `impactedSystemNames` | Name the affected applications, platforms, services, or vendors. |
| `crossSystemImpactSummary` | In plain terms, describe how content or information moves between these systems and ECM, and who hands off to whom. |
