# ANA-02-T5: Field rules, tab 5: Timeline and Funding

Today's date comes from the session clock. Never assume it.

### hasHardDeadline
- **Class:** REQ · **Type:** select
- **Accept:** `yes`, `no` or `unknown`. `unknown` is accepted, because the deadline may not be confirmed yet. Record it as INFO.
- **Reject:** missing or invalid.
- **Clarify:** it is `no`, but `isExternallyCommitted = formallyCommitted`, or `deliveryDriver` contains `regulatoryCommitment`, `legalRequirement` or `auditCommitment`.

### requestedDeliveryDate
- **Class:** COND · **Type:** date
- **Required when:** `hasHardDeadline = yes`. Otherwise OPT.
- **Accept:** a real calendar date, after today, in a format that can be read unambiguously. Normalise it to ISO `YYYY-MM-DD`. If the day/month order is ambiguous (for example 03/04/2027), raise CLARIFY instead of guessing.
- **Reject:** a past date or today. Placeholder dates (`1900-01-01`, `2099-12-31`, `9999-12-31`, `01/01/2000`). "ASAP", "Q2", "next year", "TBD". Partial dates such as a month only. If a month or quarter is all the requestor has, ask for the specific date that the commitment uses.
- **Clarify:** the date is more than `MAX_DELIVERY_HORIZON_MONTHS` (`ANA-00-intake-config.md`) away. The date is less than 30 days away (confirm it is achievable as a requested date, not a promise).
- **Ask:** "What exact date is needed? If the commitment is for a month or quarter, please give the specific date it falls on."

### deliveryDriver
- **Class:** COND · **Type:** multiselect
- **Required when:** `requestedDeliveryDate` is present.
- **Accept:** one or more valid keys.
- **Reject:** empty, or invalid keys.
- **Clarify:** it contains a commitment type (`legalRequirement`, `regulatoryCommitment`, `auditCommitment`, `shrpIssue` or `correctiveAction`) that differs from `primaryRequestCategory`, and no tracking ID covers it.
- **Ask:** "What is driving this date? Please select everything that applies."

### deliveryDriverDetails
- **Class:** COND · **Type:** textarea
- **Required when:** `requestedDeliveryDate` is present.
- **Accept:** at least 15 meaningful words naming the specific commitment, event or obligation, and what is due on that date.
- **Reject:** "business need", "management ask", "priority", "leadership wants it", or "as committed" with no named commitment.
- **Ask:** "What specific commitment, event or obligation sets this date, and what has to be done by then?"

### deadlineConsequence
- **Class:** COND · **Type:** textarea
- **Required when:** `hasHardDeadline = yes`.
- **Accept:** at least 15 meaningful words describing the concrete effect of missing the date: a penalty, a breach, customer impact, a missed launch, and so on.
- **Reject:** "delay", "impact", "escalation", or "not good" with no specific effect.
- **Ask:** "If the date is missed, what specifically happens?"

### isExternallyCommitted
- **Class:** COND · **Type:** select
- **Required when:** `requestedDeliveryDate` is present.
- **Accept:** any valid key except `unsure`.
- **Reject:** `unsure`. Ask the requestor to check with the product owner. The question is whether the date was told to anyone outside the team.
- **Ask:** "Has this date been formally committed or informally shared outside your immediate team?"

### deliveryCommitmentOwner
- **Class:** COND · **Type:** person
- **Required when:** `isExternallyCommitted` is `formallyCommitted` or `informallyCommunicated`.
- **Accept / Reject:** `SHARED-02-identity-validation.md`.
- **Ask:** "Who made or approved this commitment? Please give their full name and employee ID or work email."

### deliveryFundingStatus
- **Class:** REQ · **Type:** select
- **Accept:** any valid key.
- **Reject:** missing or invalid.
- **Clarify:** it is `notRequired`, but the request needs new build work, meaning the category is `newFunctionality` or `modernization`. Ask the requestor to confirm that no funding is needed.
