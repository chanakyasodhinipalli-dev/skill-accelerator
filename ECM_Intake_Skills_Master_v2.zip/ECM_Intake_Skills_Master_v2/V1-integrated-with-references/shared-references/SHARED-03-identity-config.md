# SHARED-03: Identity configuration

**Used by:** ECMIntakeAnalysis and ECMIntakeDiscovery and, in the split version, ECMIntakeAnalysisFollowUp and ECMIntakeDiscoveryFollowUp.

The ECM team sets these values before go-live. A value of `UNSET` means "not configured". When a value is `UNSET`, use the fallback rule in the right-hand column. Never invent a value for a setting.

| Key | Value | Fallback rule when UNSET |
|---|---|---|
| `CORPORATE_EMAIL_DOMAINS` | UNSET | Accept a well-formed email only if its domain isn't a public, free-mail or placeholder domain (see below). Record `verification: "format-only"`. |
| `PUBLIC_EMAIL_DOMAINS` | gmail.com, googlemail.com, yahoo.com, yahoo.co.in, outlook.com, hotmail.com, live.com, msn.com, icloud.com, me.com, aol.com, proton.me, protonmail.com, rediffmail.com, zoho.com, gmx.com, mail.com, yandex.com | Always set. Emails on these domains are rejected for person fields. |
| `PLACEHOLDER_EMAIL_DOMAINS` | example.com, example.org, test.com, domain.com, company.com, email.com, abc.com, xyz.com | Always set. These are rejected as fake. |
| `EMPLOYEE_ID_PATTERN` | UNSET | Accept 4 to 12 alphanumeric characters that include at least one digit. Reject all-same digits (0000, 1111), simple sequences (1234, 123456, 987654), and the placeholders listed in `SHARED-01-quality-standards.md`. Record `verification: "format-only"`. |
| `DIRECTORY_LOOKUP_TOOL` | UNSET | If a people-directory tool is available in the session, use it (`SHARED-02-identity-validation.md`, section I3). If not, use format checks only and record `verification: "format-only"`. |
| `SESSION_IDENTITY_SOURCE` | UNSET | If the workflow provides the signed-in user's full name with an ID or email, it can prefill `requestorName` (`source: "session-identity"`). Otherwise the requestor provides it. |

## Note for the ECM team
- Setting `CORPORATE_EMAIL_DOMAINS` and `EMPLOYEE_ID_PATTERN` raises identity verification from "format-only" to "pattern".
- Connecting a directory tool raises it to "directory".
