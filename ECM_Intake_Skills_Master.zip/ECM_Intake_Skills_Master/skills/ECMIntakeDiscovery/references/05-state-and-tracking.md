# 05: Discovery model and tracking (the canonical model)

```json
{
  "modelType": "ECMDiscoveryModel",
  "schemaVersion": "1.0",
  "intakeId": "",
  "status": "IN_DISCOVERY | AWAITING_REQUESTOR | DISCOVERY_COMPLETE",
  "currentRound": 0,
  "baseContext": { "...the Normalized Discovery Context, read-only..." },
  "baseCorrections": [
    { "path": "content.monthlyVolumeBand", "baseValue": "10kTo100k", "correctedValue": "100kTo1m",
      "round": 2, "questionId": "D2-3", "requestorStatement": "<verbatim>" }
  ],
  "domains": {
    "<domainFile>": {
      "status": "APPLICABLE | CANDIDATE | NOT_APPLICABLE",
      "evidence": [ { "rule": "DA-04", "path": "content.arrival", "value": "scan" } ],
      "statusHistory": [ { "round": 0, "status": "CANDIDATE" }, { "round": 1, "status": "APPLICABLE", "because": "D1-2" } ],
      "dataPoints": {
        "<DP-ID>": {
          "status": "SATISFIED_FROM_BASE | SATISFIED_FROM_DISCOVERY | OPEN | REJECTED | CLARIFY | NOT_REQUIRED | PENDING_WITH",
          "basePath": "content.arrival",
          "initial": { "value": null, "round": null, "source": null },
          "updates": [ { "value": "", "round": 2, "source": "requestor | nominee | base", "respondent": { "...I1 object" }, "questionId": "D2-1" } ],
          "current": null,
          "normalized": null,
          "issues": [ { "id": "DIS-0003", "severity": "BLOCKER | CLARIFY | INFO", "detail": "", "raisedRound": 2, "resolvedRound": null } ],
          "pendingWith": null
        }
      }
    }
  },
  "requirements": [ "...see 03-requirement-derivation.md..." ],
  "productSpecs": { "<productKey>": { "...fields from the domain file's specification section..." } },
  "hintReconciliation": [ { "hint": "printMail", "outcome": "not applicable", "because": "D1-4 answer" } ],
  "uncoveredNeeds": [ { "evidence": "<quote>", "source": "D2-5", "status": "OPEN | CONFIRMED_FOR_REVIEW" } ],
  "fitChecks": [ { "requirementId": "", "configKey": "" } ],
  "rounds": [ { "round": 1, "priorityAsked": "P1", "questions": [ { "id": "D1-1", "targets": ["domain:esignature:applicability"] } ], "unmatched": [] } ]
}
```

## Rules
1. **`baseContext` is never edited.** Corrections go into `baseCorrections`. Every rule reads the *effective* value: the latest correction if there is one, otherwise the base value.
2. **Data points satisfied from base** record `initial.source = "base"` with the base path. If the requestor later gives a different value, that is a base correction (see `06-follow-up-protocol.md`), not a silent overwrite.
3. **Updates are appended, never overwritten**, exactly as in analysis.
4. Every answer records **who gave it** (the `respondent` I1 object). If the respondent isn't the requestor, they must be a nominee identified with a full name plus an ID or email.
5. **Issue IDs** run `DIS-0001` and up. **Question IDs** are `D<round>-<n>`.
6. A **data point that is no longer required** (its condition became false, or its domain became `NOT_APPLICABLE`) gets `status: NOT_REQUIRED`. Its history is kept.
