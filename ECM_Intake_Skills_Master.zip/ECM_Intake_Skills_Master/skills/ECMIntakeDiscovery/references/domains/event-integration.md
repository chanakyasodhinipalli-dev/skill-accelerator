# Domain: Kafka / event integration (`eventIntegration`)

**Purpose:** exchanging business events or messages between ECM and other applications.

**Applicability question (CANDIDATE only):** "Should ECM send or receive real-time event messages to or from other applications?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-EV-01 | Direction | `content.arrival`, `content.consumers` | "Will ECM receive events from other applications, publish events for them, or both?" | `receive`, `publish` or `both` | technical | always | **yes** |
| DP-EV-02 | Business events | — | "Which business events are involved, and what does each one mean?" | Named events, each with a one-line meaning | business | always | no |
| DP-EV-03 | Producer and consumer applications | `systems.impactedSystems` | "For each event, which application sends it and which receives it? What is each one's application ID?" | For each event: producer plus consumer, with names and IDs | technical | always | no |
| DP-EV-04 | Volumes | — | "How many of each event per hour on average, and at the peak?" | Numbers with units | technical | always | no |
| DP-EV-05 | Ordering and duplicates | — | "Must events be processed in order? Is it a problem if one arrives twice?" | Ordering yes or no; duplicates "tolerated" or "must be prevented" | technical | always | no |
| DP-EV-06 | Event content | — | "Does each event carry a reference to a document, or the document itself, plus which details?" | `reference` or `document`, plus a list of details | technical | always | no |
| DP-EV-07 | Failure handling | — | "If an event can't be processed, who handles it?" | A team plus a contact | technical | always | no |

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-EV-01 | integration | ECM shall {receive/publish} the event {event} ({meaning}) from or to {application}. | DP-EV-01, DP-EV-02, DP-EV-03 | `EVENT_PLATFORM_DETAILS` |
| TR-EV-02 | non-functional | Event handling shall support {average} per hour, with peaks of {peak}. | DP-EV-04 | `EVENT_PLATFORM_DETAILS` |
| TR-EV-03 | integration | {event} shall be processed {in order / in any order}, with duplicates {tolerated / prevented}. | DP-EV-05 | — |
| TR-EV-04 | data | {event} shall carry {reference/document} and {details}. | DP-EV-06 | — |
| TR-EV-05 | operational | Unprocessable events shall be handled by {team}. | DP-EV-07 | — |

## Product specification (`eventIntegration`)
`direction*`, `events* [ {name, meaning, producer, consumer, volumes, ordering, duplicates, payload} ]`, `failureOwner*`.

## Reviews triggered
- **R-EV-1 ECM integration architect:** always.
