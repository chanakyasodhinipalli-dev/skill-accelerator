# Domain: Solution architecture (`solutionArchitecture`)

**Purpose:** the end-to-end flow across systems, and the overall non-functional needs.

**Applicability question (CANDIDATE only):** "Do you need ECM to help design how this fits with your other systems?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-SA-01 | Role of each system | `systems.impactedSystems`, `systems.crossSystemFlow` | "For each system ([list]), does it send content to ECM, read from ECM, or both? Does it connect by API, events, batch files, or through people using screens?" | For each system: a role plus a connection style | technical | `systems.hasNonEcmSystems = yes` | **yes** |
| DP-SA-02 | Availability need | — | "During which hours must this be available, and what happens to the business if it's down?" | Hours with a time zone, plus the impact | business | always | no |
| DP-SA-03 | Recovery need | — | "After an outage, how long can the business wait for the service to return, and how much recent content could it afford to lose?" | Two durations with their units | business | always | no |
| DP-SA-04 | Peak periods | — | "Are there busy periods, such as month-end or seasonal peaks?" | Periods, or "none" | business | always | no |
| DP-SA-05 | Dependencies on other programmes | — | "Does this depend on other projects or releases? If so, which ones, and when are they due?" | Names plus dates, or "none" | business | always | no |

**Recalculation note:** a DP-SA-01 answer that names API or event connections can make the api-onboarding or event-integration domain APPLICABLE through a base correction. Confirm it with the requestor as a P1 conflict.

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-SA-01 | integration | {system} shall {send to / read from} ECM by {connection style}. | DP-SA-01 | — |
| TR-SA-02 | non-functional | The service shall be available {hours}. | DP-SA-02 | `REPOSITORY_SLA` |
| TR-SA-03 | non-functional | The service shall be restored within {time}, with no more than {loss} of content lost. | DP-SA-03 | `REPOSITORY_SLA` |
| TR-SA-04 | non-functional | Capacity shall cover these peak periods: {periods}. | DP-SA-04 | — |
| TR-SA-05 | operational | Delivery shall be coordinated with {programmes}, due {dates}. | DP-SA-05 | only when any |

## Product specification (`solutionArchitecture`)
`systemRoles*`, `availability*`, `recovery* {time, loss}`, `peaks*`, `dependencies*`.

## Reviews triggered
- **R-SA-1 ECM solution architect:** always.
- **R-SA-2 Sponsoring LOB architect:** when `ownership.architect` is assigned.
