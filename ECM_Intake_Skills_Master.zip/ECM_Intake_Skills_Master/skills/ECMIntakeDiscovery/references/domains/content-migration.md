# Domain: Content migration (`contentMigration`)

**Purpose:** moving existing content from another system into ECM.

**Applicability question (CANDIDATE only):** "Does existing content need to be moved into ECM from another system?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-MIG-01 | Source system | `systems.impactedSystems` | "Which system is the content coming from? What's its application ID, and who owns it?" | A name, an ID, and an owner (I1) | technical | always | no |
| DP-MIG-02 | Volume to migrate | — | "How many documents, what total size, and covering which date range?" | A count, a size with its unit, and a date range | technical | always | no |
| DP-MIG-03 | Formats in the source | — | "What file formats are in the source system?" | A list | technical | always | no |
| DP-MIG-04 | Metadata and mapping | — | "Which document details exist in the source system, and who will map them to ECM's index fields?" | A list of fields, plus a mapping owner (I1) | technical | always | no |
| DP-MIG-05 | Cutover constraints | — | "Are there constraints on when the move can happen, such as blackout periods or a required finish date?" | Constraints with dates, or "none" | business | always | no |
| DP-MIG-06 | Validation and sign-off | — | "How will you confirm that everything moved correctly, and who signs it off?" | The checks, plus an approver (I1) | business | always | no |
| DP-MIG-07 | Source decommission | — | "Will the source system be switched off afterwards? If so, by when?" | No, or yes plus a date | business | always | no |
| DP-MIG-08 | Known content issues | — | "Are there known problems in the source content, such as duplicates, corrupt files or missing details?" | A list, or "none known" | technical | always | no |

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-MIG-01 | data | {count} documents ({size}, {date range}) shall be migrated from {source} into ECM. | DP-MIG-01, DP-MIG-02 | `MIGRATION_TOOLING` |
| TR-MIG-02 | data | The migration shall handle source formats {formats}. | DP-MIG-03 | `SUPPORTED_FILE_FORMATS` |
| TR-MIG-03 | data | The source fields {fields} shall be mapped to ECM index fields, with the mapping owned by {owner}. | DP-MIG-04 | — |
| TR-MIG-04 | operational | The migration shall respect {constraints}. | DP-MIG-05 | — |
| TR-MIG-05 | operational | The migration shall be validated by {checks} and signed off by {approver}. | DP-MIG-06 | — |
| TR-MIG-06 | operational | The migration shall complete before the source decommission date {date}. | DP-MIG-07 | only when yes |
| TR-MIG-07 | data | The migration shall address these known issues: {issues}. | DP-MIG-08 | only when any |

## Product specification (`contentMigration`)
`source*`, `volume*`, `formats*`, `metadataMapping*`, `cutoverConstraints*`, `validation*`, `decommission*`, `knownIssues*`.

## Reviews triggered
- **R-MIG-1 ECM migration lead:** always.
