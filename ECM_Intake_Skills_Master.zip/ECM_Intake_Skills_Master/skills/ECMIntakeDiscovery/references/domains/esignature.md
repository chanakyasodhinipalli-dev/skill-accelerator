# Domain: eSignature (`eSignature`)

**Purpose:** collecting electronic signatures on documents.

**Applicability question (CANDIDATE only):** "Do people need to sign documents electronically as part of this process?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-ES-01 | Documents to be signed | — | "Which documents need to be signed?" | Named documents | business | always | no |
| DP-ES-02 | Signers | — | "For each document, who signs (customers, employees, third parties), how many signers are there, and must they sign in a set order?" | For each document: signer types, a count, and the order (or "any order") | business | always | no |
| DP-ES-03 | Confirming signer identity | — | "How must you be sure the signer is who they say they are?" | A described method in business terms, plus the rule or policy that requires it, or "no specific requirement" | business | always | no |
| DP-ES-04 | Signing channel | — | "Where do people sign: in person, from an email link, or in a portal or app?" | One or more channels | business | always | no |
| DP-ES-05 | Volumes | — | "How many documents are signed per month, and at the peak?" | Numbers with units | business | always | no |
| DP-ES-06 | Keeping signed documents and evidence | — | "Where must signed documents, and the record of who signed and when, be kept?" | ECM or a named system | business | always | **yes** |
| DP-ES-07 | Legal or regulatory signature rules | — | "Is there a law, regulation or policy that sets how these documents must be signed? Please name it." | A named rule, or "none" | business | the category is legal or regulatory, or `legalPrivileged` is in sensitivity | no |

**Recalculation note:** if DP-ES-06 = ECM, the ICMP repository and records-retention domains become CANDIDATES.

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-ES-01 | functional | The solution shall collect electronic signatures on {documents}. | DP-ES-01 | `ESIGNATURE_CAPABILITIES` |
| TR-ES-02 | functional | {document} shall be signed by {signers} in {order}. | DP-ES-02 | — |
| TR-ES-03 | security | Signer identity shall be confirmed by {method}, as required by {rule}. | DP-ES-03 | `ESIGNATURE_CAPABILITIES` |
| TR-ES-04 | functional | Signing shall be available {channels}. | DP-ES-04 | `ESIGNATURE_CAPABILITIES` |
| TR-ES-05 | non-functional | eSignature shall support {volumes}. | DP-ES-05 | — |
| TR-ES-06 | data | Signed documents and signature evidence shall be kept in {location}. | DP-ES-06 | — |
| TR-ES-07 | security | Signing shall comply with {rule}. | DP-ES-07 | only when one is named |

## Product specification (`eSignature`)
`documents*`, `signers*`, `identityAssurance*`, `channels*`, `volumes*`, `evidenceLocation*`, `governingRule`.

## Reviews triggered
- **R-ES-1 eSignature product team:** always.
- **R-ES-2 Legal:** when DP-ES-07 names a rule.
