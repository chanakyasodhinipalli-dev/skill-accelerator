# Domain: Content capture (`contentCapture`)

**Purpose:** getting content into ECM by scanning, user upload or email.

**Applicability question (CANDIDATE only):** "Will documents be scanned, uploaded by people, or received by email as part of this request?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-CAP-01 | Channel details | `content.arrival` | "For each way documents arrive ([channels]), where does it happen and who does it?" | For each channel: a location or application, plus the people involved | business | always | no |
| DP-CAP-02 | File formats and largest size | — | "Which file types arrive, and what's the largest file you'd expect?" | A list of formats, plus a maximum size with its unit | business | always | no |
| DP-CAP-03 | Scanning setup | — | "Where is scanning done, how many scanning points are there, and is there any colour or special paper handling?" | Locations, a count, and special needs or "none" | business | `content.arrival` has `scan` | no |
| DP-CAP-04 | Email intake | — | "Which mailbox or mailboxes receive these documents, and do you need the email text as well as the attachments?" | Mailbox names, plus "attachments only" or "email and attachments" | business | `content.arrival` has `email` | no |
| DP-CAP-05 | Upload source | — | "Which application or portal are documents uploaded from, and by whom (staff or customers)?" | An application name plus the user type | business | `content.arrival` has `userUpload` | no |
| DP-CAP-06 | Checks at capture | — | "What must be checked when a document arrives, for example that it's complete, readable, or that all required documents are there?" | A list of checks, or "none" with a reason | business | always | no |
| DP-CAP-07 | Time to availability | — | "Once a document arrives, how quickly must it be available to use?" | A duration with its unit | business | always | no |
| DP-CAP-08 | Exception handling | — | "What should happen to documents that are unreadable or incomplete, and which team handles them?" | An action, plus a team and a named contact | business | always | no |

## Requirement templates
| ID | Type | Statement | Inputs | Fit check |
|---|---|---|---|---|
| TR-CAP-01 | functional | Content shall be captured through {channels} at {locations or applications} by {people}. | DP-CAP-01 | — |
| TR-CAP-02 | functional | Capture shall accept {formats}, up to {max size}. | DP-CAP-02 | `SUPPORTED_FILE_FORMATS`, `MAX_FILE_SIZE` |
| TR-CAP-03 | functional | Scanning shall be supported at {locations} across {count} scanning points, with {special handling}. | DP-CAP-03 | — |
| TR-CAP-04 | integration | Documents shall be ingested from mailboxes {mailboxes}, capturing {scope}. | DP-CAP-04 | — |
| TR-CAP-05 | integration | Uploads shall be accepted from {application} by {user type}. | DP-CAP-05 | — |
| TR-CAP-06 | functional | At capture, the solution shall check: {checks}. | DP-CAP-06 | — |
| TR-CAP-07 | non-functional | Captured documents shall be available within {duration}. | DP-CAP-07 | — |
| TR-CAP-08 | operational | Unreadable or incomplete documents shall be {action}, and routed to {team or contact}. | DP-CAP-08 | — |

## Product specification (`contentCapture`)
`channels* []`, `formats*`, `maxFileSize*`, `scanning`, `emailIntake`, `uploadSource`, `captureChecks*`, `availabilityTarget*`, `exceptionHandling*`.

## Reviews triggered
- **R-CAP-1 Capture product team:** always.
