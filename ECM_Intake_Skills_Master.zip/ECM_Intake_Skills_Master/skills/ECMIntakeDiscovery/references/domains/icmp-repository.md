# Domain: ICMP repository (`icmpOnboarding`)

**Purpose:** storing, managing, finding and retrieving content in ICMP.

**Applicability question (CANDIDATE only):** "Does this content need to be stored in ECM so people or systems can find and retrieve it later?"

## Data points
| ID | Need | Base reuse | Ask | Accept | Resp | Required when | Gate |
|---|---|---|---|---|---|---|---|
| DP-REP-01 | The business document kinds to store | `content.types` (as context only; too broad to satisfy this) | "Please list each kind of document you'll store, using the names your business uses, for example the form or letter names." | 1 or more specific document names. "Documents" and "files" are rejected. | business | always | **yes** |
| DP-REP-02 | Where each document kind comes from | — | "For each document, is it produced by your organisation's own systems, or received from customers or third parties?" | For each kind: `internal` or `external`, plus the producing system or party | business | always | no |
| DP-REP-03 | Index fields | — | "Which details will people or systems use to find these documents, for example a customer or account number? For each, which system holds the value?" | 1 or more field names, each with its source system and whether it is always available | business | always | no |
| DP-REP-04 | How content is retrieved | `content.consumers` | "How will documents be looked up (by which details), and how quickly must they appear?" | Retrieval patterns, plus a response need with a unit, for example "within 3 seconds" | business | `content.actions` has `retrieve` | no |
| DP-REP-05 | Exact volumes | `content.monthlyVolumeBand` (as context) | "How many documents a month, on average and on the busiest day? What's the typical file size and page count?" | Numbers with units: monthly average, peak day, average MB, average pages. They must fall inside the base band, or raise a base-correction conflict. | business | always | no |
| DP-REP-06 | Growth | — | "How do you expect these volumes to change over the next 3 years?" | A percentage or a numeric forecast, or "stable" with a reason | business | always | no |
| DP-REP-07 | Changes after storage | — | "After a document is stored, can it be changed or replaced? If so, must earlier versions be kept?" | "Never changed", or "changed" plus whether versions are kept | business | always | no |
| DP-REP-08 | Deletion rights | — | "Who may delete documents, and when?" | A role or team plus the conditions, or "no one; disposal by retention only" | business | the records-retention domain is NOT_APPLICABLE | no |
| DP-REP-09 | Batch file delivery | `content.arrival` = batch | "For batch files: how are they delivered, how often, in what time window, and how many documents per batch?" | Mechanism, frequency, window with time zone, and batch size | technical | `content.arrival` has `batch` | no |
| DP-REP-10 | Existing ECM application to extend | `content.existingEcmDetails` | "Which existing ECM application should this extend? What is its application ID?" | A name plus an ID | technical | `content.existingEcmUsage = yes` | no |

## Requirement templates
| ID | Type | Statement | Inputs | Condition | Fit check |
|---|---|---|---|---|---|
| TR-REP-01 | functional | The solution shall store these document kinds: {DP-REP-01}. | DP-REP-01 | always | `SUPPORTED_FILE_FORMATS` |
| TR-REP-02 | operational | Each document kind in {DP-REP-01} shall be submitted to Imaging Governance for a trusted or untrusted decision and, for trusted content, allocation of document category, type and subtype. | DP-REP-01, DP-REP-02 | always | — |
| TR-REP-03 | data | Each stored document shall be indexed by {DP-REP-03 fields}, with values sourced from {systems}. | DP-REP-03 | always | — |
| TR-REP-04 | non-functional | Documents shall be retrievable by {patterns} within {response need}. | DP-REP-04 | DP-REP-04 required | `REPOSITORY_SLA` |
| TR-REP-05 | non-functional | The solution shall support {monthly} documents a month, with peaks of {peak day} a day, averaging {MB} MB and {pages} pages, growing {growth}. Volumes shall be assessed through IVaaS. | DP-REP-05, DP-REP-06 | always | `MAX_FILE_SIZE` |
| TR-REP-06 | functional | Stored documents shall {be immutable / allow replacement, with or without version retention} as specified. | DP-REP-07 | always | — |
| TR-REP-07 | security | Deletion shall be limited to {DP-REP-08}. | DP-REP-08 | DP-REP-08 required | — |
| TR-REP-08 | integration | Batch files shall be accepted by {mechanism}, {frequency}, within {window}, with up to {batch size} documents. | DP-REP-09 | DP-REP-09 required | — |
| TR-REP-09 | functional | The onboarding shall extend the existing ECM application {DP-REP-10}. | DP-REP-10 | DP-REP-10 required | — |

## Product specification (`icmpOnboarding`)
`documentKinds* [ {name, origin, producer} ]`, `indexFields* [ {name, sourceSystem, alwaysAvailable} ]`, `retrieval {patterns, responseNeed}`, `volumes* {monthlyAvg, peakDay, avgSizeMB, avgPages, growth}`, `changePolicy*`, `deletionRights`, `batch`, `existingApplication`.

## Reviews triggered
- **R-REP-1 Imaging Governance:** always (taxonomy and trust decision).
- **R-REP-2 ECM repository architect:** always.
