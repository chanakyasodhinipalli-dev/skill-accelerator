# 04: Identifying and prioritising discovery gaps

A **gap** is any of the following:
- **G-A.** A `CANDIDATE` domain whose applicability question isn't answered yet.
- **G-B.** A data point in a live domain that is required (its "required when" is true) and isn't satisfied.
- **G-C.** A data point answer that failed validation (`REJECTED`) or needs clarification (`CLARIFY`).
- **G-D.** A conflict between a discovery answer and the base context, or between two discovery answers.
- **G-E.** An uncovered need (`03-requirement-derivation.md`, rule 1) that the requestor still needs to confirm or describe more fully.

## Priority

| Priority | What it covers | Why it goes first |
|---|---|---|
| **P1** | G-A applicability questions. G-D conflicts that affect which domains apply. Data points marked `gate: true`, whose answer can turn a domain or other data points on or off. | These answers can remove whole sets of questions, so asking them first avoids wasted questions. |
| **P2** | Required data points that a product's specification needs (formats, volumes, operations, integrations, identities). | The core of the specification. |
| **P3** | Required non-functional and operational data points (peaks, growth, availability expectations, support contacts). Remaining clarifications. | They refine the specification. |

## Which gaps each round asks
- **If any P1 gap is open:** ask **all** open P1 gaps, and only those. Their answers may change what P2 and P3 need.
- **Otherwise:** ask **all** open P2 and P3 gaps together, grouped by product.
- **Always:** re-ask every gap that a previous answer failed to close, at the same priority.

## Ordering inside a round
Group the questions by product domain, in the order the domains appear in `02-domain-applicability.md`. Core onboarding and security go last. Inside each domain, ask in data-point order.

## Fit checks are not gaps
Items marked `FIT_CHECK_PENDING` go to reviewers. They are never asked of the requestor, and never block completion.
