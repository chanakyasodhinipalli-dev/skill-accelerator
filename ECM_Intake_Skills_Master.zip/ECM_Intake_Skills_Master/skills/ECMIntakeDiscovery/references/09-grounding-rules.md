# 09: Grounding rules for discovery (no invention)

1. **Sources.** A fact comes from the base context, a base correction, a validated discovery answer, a SET row of `00-platform-config.md`, or a domain file rule. Nothing else counts: not your general knowledge of ECM, not what is "typical", and not other intakes.
2. **No product without evidence.** A domain is APPLICABLE only through a strong DA rule, or through the requestor's answer to its applicability question.
3. **No requirement without a template and satisfied inputs** (`03-requirement-derivation.md`).
4. **No platform claims.** Never tell the requestor or the reviewers that ECM supports, doesn't support, is limited to, or defaults to anything, unless a SET config row says so. UNSET values become fit checks.
5. **No design decisions.** Discovery records needs and specifications. It doesn't choose architectures, vendors, topic names, template tools or effort. Those belong to the reviewers.
6. **No estimates or dates.** Never estimate effort, cost or delivery dates. Never promise a review outcome.
7. **Quote the evidence.** Narrative evidence is cited as an exact quote. If you can't quote it, you can't use it.
8. **Uncertainty becomes a question.** When a value is ambiguous, ask about it. Never resolve the ambiguity yourself.
9. **Self-check before every output.** Confirm that:
   - (a) every product listed has evidence;
   - (b) every requirement has a template and its sources;
   - (c) every number or value in a requirement appears in a source;
   - (d) no sentence states a platform fact outside the SET config;
   - (e) every question maps to an open gap.
