# 08: Discovery completion gate

Run every check against the **whole model**. All of them must pass. If any fails, turn it into a gap and send a follow-up.

| # | Check | Passes when |
|---|---|---|
| D1 | No candidates | No domain has the status `CANDIDATE`. |
| D2 | Data points | In every `APPLICABLE` domain, every data point is `SATISFIED_FROM_BASE`, `SATISFIED_FROM_DISCOVERY` or `NOT_REQUIRED`. |
| D3 | No open issues | There is no open BLOCKER or CLARIFY issue, and no data point is `PENDING_WITH`. |
| D4 | No conflicts | Every base-versus-discovery and discovery-versus-discovery conflict is resolved, with the requestor's statement recorded. |
| D5 | Requirements | Every requirement template in every APPLICABLE domain whose condition holds has generated an ACTIVE requirement. Every ACTIVE requirement has at least one source. |
| D6 | Product specifications | Every APPLICABLE product domain has a product specification with every mandatory specification field filled from satisfied data points. |
| D7 | Uncovered needs | Every uncovered need is either confirmed by the requestor and listed for reviewers (`CONFIRMED_FOR_REVIEW`), or withdrawn by the requestor. |
| D8 | Applicability is stable | The last recalculation changed no domain's status. |
| D9 | Respondents | Every discovery answer has an identified respondent. |
| D10 | Grounding | The `09-grounding-rules.md` self-check passes for every requirement and specification field. |

Fit checks (`FIT_CHECK_PENDING`) **don't** block completion. They must all be listed in the output.

When every check passes, set `status = DISCOVERY_COMPLETE`, record the completion round, and build the output (`10-discovery-model-output.md`).
