# 02: Determining applicable discovery domains

A **domain** is one ECM product or service, or one cross-cutting concern, that discovery may need to specify. Each domain has a file in `domains/`.

## Statuses
- **`APPLICABLE`**: at least one **strong** rule fires. The domain's file is loaded and its data points are collected.
- **`CANDIDATE`**: only **weak** rules fire. The domain's file is loaded, but its **applicability question** must be answered first, and is asked as priority P1. The answer turns the domain into `APPLICABLE` or `NOT_APPLICABLE`.
- **`NOT_APPLICABLE`**: no rule fires. The output records the reason as "no signal in [fields checked]". The domain's file isn't loaded.

Each status carries `evidence`: a list of `{rule, field, value}` entries. For narrative evidence, the entry includes the quoted phrase.

## Domains that always apply
| Domain | File | Why |
|---|---|---|
| Core onboarding | `domains/core-onboarding.md` | Every ECM engagement needs application identity, environments, team allocation and access. |
| Security and compliance | `domains/security-compliance.md` | Every engagement needs a classification and access model. How deep it goes depends on `content.sensitivity`. |

## Rules for product and service domains

`A` = strong rule, which makes the domain APPLICABLE. `W` = weak rule, which makes it CANDIDATE.

| ID | Domain (file / key) | Rule | Type |
|---|---|---|---|
| DA-01 | ICMP repository (`icmp-repository` / `icmpOnboarding`) | `content.actions` contains `store` or `retrieve` | A |
| DA-02 | ICMP repository | `content.existingEcmUsage = yes`, and the actions include anything other than `migrate` | A |
| DA-03 | ICMP repository | `icmpOnboarding` is in `request.ecmSupportHints`, with no DA-01 or DA-02 | W |
| DA-04 | Content capture (`content-capture` / `contentCapture`) | `content.arrival` contains `scan`, `userUpload` or `email` | A |
| DA-05 | Content capture | `content.types` contains `scannedPaper` or `emails`, with no DA-04 | W |
| DA-06 | Content capture | `contentCapture` is in the hints, with no DA-04 | W |
| DA-07 | Document AI / iDocs (`document-ai` / `idocsAi`) | `content.actions` contains `classifyExtract` | A |
| DA-08 | Document AI / iDocs | `idocsAi` is in the hints, or a narrative mentions classifying, extracting, indexing or reading data from documents, with no DA-07 | W |
| DA-09 | Document generation (`document-generation` / `documentGeneration`) | `content.actions` contains `generate` | A |
| DA-10 | Document generation | `content.types` contains `outboundCorrespondence`, or `documentGeneration` is in the hints, with no DA-09 | W |
| DA-11 | Print and mail (`print-mail` / `printMail`) | `content.actions` contains `printMail` | A |
| DA-12 | Print and mail | `printMail` is in the hints, or a narrative mentions posting or mailing letters, with no DA-11 | W |
| DA-13 | Virus scanning (`virus-scan` / `virusScan`) | `content.actions` contains `virusScan`, **or** `content.arrival` contains `userUpload`, `email` or `api` | A |
| DA-14 | eSignature (`esignature` / `eSignature`) | `content.actions` contains `sign` | A |
| DA-15 | eSignature | `content.types` contains `signedAgreements`, or `eSignature` is in the hints, with no DA-14 | W |
| DA-16 | API onboarding (`api-onboarding` / `apiOnboarding`) | `content.arrival` contains `api`, **or** `content.consumers` contains `systemApi` | A |
| DA-17 | API onboarding | `apiOnboarding` is in the hints, or `content.consumers` contains `customerChannel`, with no DA-16 | W |
| DA-18 | Event integration (`event-integration` / `eventIntegration`) | `content.arrival` contains `event`, **or** `content.consumers` contains `systemEvent` | A |
| DA-19 | Event integration | `eventIntegration` is in the hints, with no DA-18 | W |
| DA-20 | Records and retention (`records-retention` / `recordsRetention`) | `content.retentionRequired = yes`, **or** `content.actions` contains `retain` | A |
| DA-21 | Records and retention | the category is `legalRequirement`, `regulatoryCommitment` or `auditCommitment`, or `content.types` contains `signedAgreements`, with no DA-20 | W |
| DA-22 | Content migration (`content-migration` / `contentMigration`) | `content.actions` contains `migrate` | A |
| DA-23 | Content migration | `contentMigration` is in the hints, or `request.primaryCategory = modernization`, with no DA-22 | W |
| DA-24 | Solution architecture (`solution-architecture` / `solutionArchitecture`) | `systems.hasNonEcmSystems = yes`, **or** three or more product domains are APPLICABLE | A |
| DA-25 | Solution architecture | `solutionArchitecture` is in the hints, with no DA-24 | W |
| DA-26 | Testing and performance (`testing-performance` / `testingSupport`) | any of ICMP repository, content capture, API onboarding or event integration is APPLICABLE | A |
| DA-27 | Testing and performance | `testingSupport` is in the hints, with no DA-26 | W |
| DA-28 | Batch ingestion (handled inside `icmp-repository`) | `content.arrival` contains `batch` | A (adds the batch data points in `icmp-repository`) |
| DA-29 | Any domain named in a live domain file's "Recalculation note" | the discovery answer that the note describes is satisfied | W (the named domain becomes CANDIDATE, unless it is already APPLICABLE) |

## Requestor hints and evidence
- `request.ecmSupportHints` are the requestor's own guesses. **On their own they never make a domain APPLICABLE**; they only make it a CANDIDATE.
- If a hint is selected but its domain ends up `NOT_APPLICABLE` after the applicability question, record this in `hintReconciliation` with the requestor's answer.
- If a domain is APPLICABLE with no matching hint, that is normal. Record it in `hintReconciliation` as "inferred, not requested".

## Order
Evaluate DA-01 to DA-23 first. Then DA-24, which counts the APPLICABLE product domains. Then DA-26 to DA-28. Re-run the whole table during recalculation whenever a fact it reads changes.
