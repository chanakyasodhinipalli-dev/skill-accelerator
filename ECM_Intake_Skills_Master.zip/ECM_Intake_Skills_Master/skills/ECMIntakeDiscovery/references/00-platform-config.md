# 00: ECM platform configuration

This file is the **only** source of platform facts for discovery. Rows marked **SET** are confirmed ECM rules from the Onboard360AI design. Rows marked **UNSET** are for the ECM team to fill in before go-live.

While a value is UNSET, the skill:
- records what the requestor needs;
- marks the related requirement `FIT_CHECK_PENDING`;
- lists it for the ECM reviewers.

It must never state, guess or imply the platform value.

## Confirmed platform rules (SET)

| Key | Value |
|---|---|
| `ENV_LADDER` | Innovation → Non-Prod → Production. Environments are reached in order; none can be skipped. |
| `ENV_NO_SCRUM_TEAM` | Without an allocated scrum team, onboarding is limited to Innovation. |
| `ENV_INTERNAL_ONLY` | ProdFix is internal to ICMP and is never offered to partners. |
| `SERVICE_ACCOUNT_BY_ENV` | Innovation and Non-Prod use the QAEnt service account. Production uses the production account. |
| `ACCESS_ROUTING` | Service accounts (creation and groups) go through ART in every environment. Human user access goes through ART for QAEnt and through AIMS for ADEnt. |
| `APP_IDENTIFIERS` | Every onboarding application needs a BAM App ID and a Remedy ID. |
| `CERTIFICATES` | Certificates are issued through Venafi. |
| `API_GATEWAY` | ECM APIs are consumed through the Apigee marketplace, by subscription. |
| `VOLUME_ASSESSMENT` | Volumes are assessed through IVaaS. |
| `LOAD_TESTING` | Load testing is SPLI (System Performance Load Ingestion testing). The SPLI ticket is raised in the allocated scrum team's own Jira project. |
| `INTAKE_PROJECT` | ECM intakes live in Jira project LJKX (format `LJKX-####`). |
| `TAXONOMY_AUTHORITY` | Imaging Governance decides whether content is trusted or untrusted, allocates the document category, type and subtype for trusted content, and maintains the DKE (Document Knowledge Engine) that trains the LLM iDocs uses to classify untrusted content. |

## Platform values to be set by ECM (UNSET)

| Key | Used by domain | Value |
|---|---|---|
| `SUPPORTED_FILE_FORMATS` | capture, repository, migration | UNSET |
| `MAX_FILE_SIZE` | capture, repository, api | UNSET |
| `REPOSITORY_SLA` (availability, retrieval latency) | repository, solution-architecture | UNSET |
| `API_RATE_LIMITS` | api-onboarding | UNSET |
| `APIGEE_PRODUCTS` (names, operations) | api-onboarding | UNSET |
| `EVENT_PLATFORM_DETAILS` (topics naming, schema registry, retention) | event-integration | UNSET |
| `IDOCS_CAPABILITIES` (classification, extraction, languages) | document-ai | UNSET |
| `DOCGEN_CAPABILITIES` (template tooling, output formats) | document-generation | UNSET |
| `PRINT_MAIL_CAPABILITIES` (mail classes, cut-off times, return mail) | print-mail | UNSET |
| `ESIGNATURE_CAPABILITIES` (signer authentication methods, evidence) | esignature | UNSET |
| `VIRUS_SCAN_BEHAVIOUR` (scan points, quarantine handling) | virus-scan | UNSET |
| `RECORDS_SCHEDULE_SOURCE` (where retention periods are defined) | records-retention | UNSET |
| `MIGRATION_TOOLING` | content-migration | UNSET |
| `VOLUME_BAND_TIER_THRESHOLD` | tier signal | UNSET |

## How to use UNSET values
- **Ask the requestor what they need**, in their terms. For example: "What's the largest file you expect?"
- **Write the requirement as a need**: "The solution shall accept files up to 200 MB." Do not write it as a platform fact.
- **Set `fitCheck: "FIT_CHECK_PENDING"`** and give the config key in `fitCheckKey`.
- **The ECM reviewers resolve fit checks.** They are not discovery gaps and don't block `DISCOVERY_COMPLETE`. Every one of them must still be listed in the output for review.
