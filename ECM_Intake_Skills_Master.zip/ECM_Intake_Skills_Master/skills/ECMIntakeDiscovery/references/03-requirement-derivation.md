# 03: Deriving safe requirements

A requirement is **safe** only when every part of its statement comes from a satisfied data point or a context field, through a template in a domain file. Nothing else is safe.

## Rules
1. **Template only.** A requirement can come only from a requirement template (`TR-<domain>-<nn>`) in a loaded domain file. You may not write a free-form requirement. If you notice a need that no template covers, raise it as a gap ("uncovered need"), quote the evidence, and list it for reviewers in `uncoveredNeeds`. Don't turn it into a requirement.
2. **All inputs satisfied.** A template produces a requirement only when every data point it needs has the status `SATISFIED_FROM_BASE` or `SATISFIED_FROM_DISCOVERY`. If any input is open, the requirement doesn't exist yet. It isn't drafted and doesn't appear anywhere.
3. **Values are substituted, never invented.** Placeholders in the template (`{volume}`, `{formats}` and so on) are filled with the exact normalised values of the data points. No rounding up, adding a safety margin, or adding things like "and other formats".
4. **Traceability.** Each requirement records:
```json
{ "id": "REQ-<domain>-<nnn>", "template": "TR-<domain>-<nn>", "type": "functional | integration | data | security | non-functional | operational | environment",
  "statement": "The solution shall ...", "sources": [ { "kind": "base", "path": "content.arrival" }, { "kind": "dp", "id": "DP-CAP-03" } ],
  "productKey": "contentCapture", "priority": "must | should", "fitCheck": "NONE | FIT_CHECK_PENDING", "fitCheckKey": null,
  "status": "ACTIVE | WITHDRAWN", "derivedRound": 2, "withdrawnRound": null, "withdrawnReason": null }
```
5. **Priority.** A requirement is `must` when the template says so, or when its source answer is a stated mandatory need. It is `should` only where the template allows it **and** the requestor said "nice to have". Never set priority from your own judgement.
6. **Platform values.** Templates may state ECM platform rules only from the SET rows of `00-platform-config.md`. If the template depends on an UNSET value, set `fitCheck: "FIT_CHECK_PENDING"`.
7. **Recalculation.** When an input changes, regenerate the requirement. If the statement changes, withdraw the old ID (`status: WITHDRAWN`, with the reason) and issue a new ID. Requirements are never edited in place, so reviewers can see what changed.
8. **Wording.** Use "The solution shall" plus one testable need. Use measurable values where the data point gives them. Don't name vendors or technologies unless the data point or a SET config row names them.
