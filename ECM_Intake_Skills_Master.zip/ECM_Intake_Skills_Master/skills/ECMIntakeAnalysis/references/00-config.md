# 00 — Organisation configuration

The ECM team sets these values before go-live. A value of `UNSET` means "not configured". When a value is `UNSET`, use the fallback rule in the right-hand column. Never invent a value for a setting.

| Key | Value | Fallback rule when UNSET |
|---|---|---|
| `CORPORATE_EMAIL_DOMAINS` | UNSET | Accept a well-formed email only if its domain is not a public or free-mail domain (see `PUBLIC_EMAIL_DOMAINS`). Record `verification: "format-only"`. |
| `PUBLIC_EMAIL_DOMAINS` | gmail.com, googlemail.com, yahoo.com, yahoo.co.in, outlook.com, hotmail.com, live.com, msn.com, icloud.com, me.com, aol.com, proton.me, protonmail.com, rediffmail.com, zoho.com, gmx.com, mail.com, yandex.com | (Always set.) Emails on these domains are rejected for person fields. |
| `PLACEHOLDER_EMAIL_DOMAINS` | example.com, example.org, test.com, domain.com, company.com, email.com, abc.com, xyz.com | (Always set.) Rejected as fake. |
| `EMPLOYEE_ID_PATTERN` | UNSET | Accept 4–12 alphanumeric characters that include at least one digit. Reject all-same digits (0000, 1111), simple sequences (1234, 123456, 987654), and the placeholders listed in `02-quality-standards.md`. Record `verification: "format-only"`. |
| `DIRECTORY_LOOKUP_TOOL` | UNSET | If a people-directory tool is available in the session, use it (see `04-identity-validation.md`). If not, use format checks only and record `verification: "format-only"`. |
| `TRACKING_ID_PATTERNS` | UNSET | Accept an ID if it contains at least one digit, is 4–40 characters long, is not a placeholder, and the requestor has named the system it comes from (SHRP, Jira, ServiceNow, and so on). Jira-style keys must match `^[A-Z][A-Z0-9]{1,9}-\d+$`. |
| `MAX_DELIVERY_HORIZON_MONTHS` | 36 | A requested delivery date more than this many months away gets a `CLARIFY` issue. |
| `SESSION_IDENTITY_SOURCE` | UNSET | If the workflow provides the signed-in user's name with an ID or email, it can prefill `requestorName` (`source: "session-identity"`). Otherwise the requestor provides it. |

## Notes for the ECM team

- Setting `CORPORATE_EMAIL_DOMAINS` and `EMPLOYEE_ID_PATTERN` changes identity verification from format-only to pattern-verified. Connecting a directory tool changes it to directory-verified.
- Add the real formats for SHRP, corrective action, incident, audit and regulatory IDs to `TRACKING_ID_PATTERNS`, for example `SHRP: ^SHRP-\d{6}$`.
