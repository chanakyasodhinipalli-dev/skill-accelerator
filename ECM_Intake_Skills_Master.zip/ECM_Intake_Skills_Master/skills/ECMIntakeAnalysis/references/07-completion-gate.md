# 07: Base intake completion gate

Run every check, in order, against the **whole record**, not only the fields that changed. Every check must pass. If any check fails, turn it into a gap and go back to the follow-up step.

| # | Check | Passes when |
|---|---|---|
| G1 | Required fields | Every `DC` and `REQ` field has `status = VALID`. |
| G2 | Conditional fields | The XF-R conditions are re-evaluated on the current values. Every field whose condition is true has `status = VALID`. Every field whose condition is false is `NOT_APPLICABLE`. |
| G3 | Optional fields | Every non-blank optional field has `status = VALID`. Junk is never accepted, even in an optional field. |
| G4 | No open issues | There is no open `BLOCKER` or `CLARIFY` issue anywhere in the record. |
| G5 | No pending people | No field has `status = PENDING_WITH`. |
| G6 | "Not sure" | No `DC` field holds `notSure`, `unsure` or `unknown`. |
| G7 | Identities | Every person value, and every contact inside a team field, is an I1 object with a full name and at least one identifier. |
| G8 | Cross-field | Every XF-C rule was evaluated against the current values in this pass and none fires unresolved. |
| G9 | Provenance | Every `current` value traces to `data-capture`, `follow-up`, `session-identity`, `directory`, `requestor-volunteered` or `requestor-confirmed-move`. Any other source fails the gate. |
| G10 | Normalization | Every field with `status = VALID` has a `normalized` value of the correct type. |
| G11 | Re-validation | Every value changed in the latest round has been through field, quality, identity and cross-field validation in this round. |

If the gate passes, set `status = BASE_INTAKE_COMPLETE`, record `completedRound`, and build the Normalized Discovery Context (`08-normalized-discovery-context.md`).

If the gate fails, list which checks failed in the round log, convert each failure into an issue on the relevant field, and send the follow-up. **Never emit a partial context.**
