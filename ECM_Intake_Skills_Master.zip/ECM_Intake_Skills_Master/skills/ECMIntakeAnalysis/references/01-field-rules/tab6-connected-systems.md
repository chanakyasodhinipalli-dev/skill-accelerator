# Tab 6: Connected Systems

### hasNonEcmSystems
- **Class:** DC · **Type:** select
- **Accept:** `yes` or `no`.
- **Reject:** `unsure`. Follow the "not sure" procedure. The sponsoring engineering lead or architect usually knows.
- **Clarify:** it is `no`, but any of these hold:
  - `contentArrival` contains `api`, `event` or `batch`
  - `contentConsumers` contains `systemApi` or `systemEvent`
  - the narratives name another application, portal, vendor or system.

  Quote the evidence and ask.
- **Ask:** "Are any applications, portals, vendors or systems outside ECM involved, for example a system that sends you the content or one that reads it?"

### impactedSystemNames
- **Class:** COND · **Type:** textarea (list)
- **Required when:** `hasNonEcmSystems = yes`.
- **Accept:** a list in which every entry is a **specific** system, application, platform or vendor product name, for example "Loan Origination System (LOS)" or "Customer Portal – Mobile App". An application ID is welcome but optional at this step.
- **Reject:**
  - Generic entries: "upstream system", "downstream apps", "core systems", "vendor", "portal", "CRM" or "mainframe" on its own with no product or application name.
  - Entries that are ECM products themselves (ICMP, iDocs, Capture). Explain that ECM components are not "outside ECM".
- **Clarify:**
  - A system named in the narratives is missing from the list.
  - Only one system is listed, but both inbound (`contentArrival` contains `api`, `event` or `batch`) and outbound (`contentConsumers` contains `systemApi` or `systemEvent`) integrations are indicated. Ask whether the same system both sends and reads.
- **Ask:** "Please list each system outside ECM by its actual name, for example the application or product name your teams use, not a general description."

### crossSystemImpactSummary
- **Class:** COND · **Type:** textarea
- **Required when:** `hasNonEcmSystems = yes`.
- **Accept:** at least 25 meaningful words describing the sequence. It must name the systems from `impactedSystemNames`, say what each one sends or receives, and say in which order.
- **Reject:** under 25 words. Text that names no system. "Standard integration". "Same as today". "Architect to confirm".
- **Clarify:** the sequence mentions a system that isn't in `impactedSystemNames`, or leaves out one that is.
- **Ask:** "In simple steps, how does content or information move between [list of systems] and ECM? For example: which system sends what, which stores it, and which reads it."
