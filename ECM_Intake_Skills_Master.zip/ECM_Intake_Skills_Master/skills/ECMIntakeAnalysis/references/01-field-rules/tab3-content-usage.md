# Tab 3: Content and Usage

This tab is the main input for product discovery. Every multiselect here is `DC`. For each one, `notSure` is not accepted, whether alone or combined with other keys. When the requestor answers `notSure`, follow the "not sure" procedure in `05-follow-up-protocol.md`: explain the options in everyday words, then give the requestor the choice of answering or naming a person who can (name plus ID or email). The field stays open until a real answer is recorded.

### contentTypes
- **Class:** DC · **Type:** multiselect
- **Accept:** one or more valid keys, excluding `notSure`.
- **Reject:** empty, or invalid keys.
- **Clarify:**
  - The narratives mention a kind of content that isn't selected. For example, the narrative says "customers sign the agreement" but `signedAgreements` isn't selected. Quote the phrase and ask.
  - `contentArrival` contains `scan` but `scannedPaper` isn't selected.
  - `contentActions` contains `printMail` or `generate` but `outboundCorrespondence` isn't selected.
- **Ask:** "What kinds of content are involved? For example: paper you scan, PDFs or Word files, photos, emails, online forms, letters you send out, signed contracts."

### otherContentTypeDetails
- **Class:** COND · **Type:** text
- **Required when:** `contentTypes` contains `other`.
- **Accept:** at least 3 meaningful words naming the content, for example "engineering CAD drawings".
- **Reject:** "other", "files", "documents", "data", "stuff".
- **Ask:** "You selected 'Other'. What kind of content is it?"

### contentActions
- **Class:** DC · **Type:** multiselect
- **Accept:** one or more valid keys, excluding `notSure`.
- **Reject:** empty, invalid keys, or `notSure`.
- **Clarify:**
  - `retentionRequired = yes` and `retain` isn't selected. Ask whether the content must be kept for the required period as part of this request.
  - The narrative describes an action that isn't selected, for example "we mail statements" without `printMail`, or "extract the account number" without `classifyExtract`. Quote the phrase.
  - Only `receive` is selected. Ask what happens to the content after it is received: is it stored, searched or sent on?
- **Ask:** "What needs to happen to the content? For example: collect it, store it, look it up later, pull data out of it automatically, create documents, get signatures, print and post it, keep it for a set period, or move it from another system."

### contentArrival
- **Class:** DC · **Type:** multiselect
- **Accept:** one or more valid keys, excluding `notSure`.
- **Reject:** empty, invalid keys, or `notSure`.
- **Clarify:**
  - It contains `api` or `event`, and `hasNonEcmSystems = no`. A sending system must exist. Ask which system sends it.
  - It contains only `generated`, but `contentActions` doesn't contain `generate`.
- **Ask:** "How does the content arrive? For example: scanned from paper, uploaded by people, emailed in, sent by another system automatically, sent in a scheduled file, or created by you."

### contentConsumers
- **Class:** DC · **Type:** multiselect
- **Accept:** one or more valid keys, excluding `notSure`.
- **Reject:** empty, invalid keys, or `notSure`.
- **Clarify:** it contains `systemApi` or `systemEvent`, and `hasNonEcmSystems = no`.
- **Ask:** "Once the content is stored, who or what uses it? For example: staff on a screen, customers in a portal or app, another application, reports, or auditors."

### existingEcmUsage
- **Class:** DC · **Type:** select
- **Accept:** `yes` or `no`.
- **Reject:** `unsure`. Follow the "not sure" procedure. The requestor's sponsoring engineering lead or product owner usually knows.
- **Clarify:**
  - It is `no`, but the narratives mention ICMP or an existing ECM repository.
  - It is `yes`, but `currentBusinessApproach` describes a fully paper-based or manual process with no system.
- **Ask:** "Does this application or business area already store content in ECM or ICMP today?"

### existingEcmDetails
- **Class:** COND · **Type:** textarea
- **Required when:** `existingEcmUsage = yes`.
- **Accept:** at least one named application or capability, with an application ID if the requestor has one. An ID is not required at this stage.
- **Reject:** "yes", "ECM", "ICMP", "some apps", "the usual".
- **Ask:** "Which application or ECM capability is already in use? Please give its name, and its application ID if you have it."

### monthlyVolumeBand
- **Class:** DC · **Type:** select
- **Accept:** any band key except `unknown`.
- **Reject:** `unknown`. Ask for a best estimate band, explaining that an order of magnitude is enough, and offer ways to estimate: items per day × 22, the current monthly count from the existing process, or forecast customer numbers. The requestor may instead name a person who knows (with an ID or email); the field stays open until the band is given.
- **Clarify:** the band conflicts with numbers in the narratives. For example, the narrative says "about 500 applications a day" (about 11,000 a month) but the band is `lt10k`. Show the calculation and ask which is right.
- **Ask:** "Roughly how many documents or items will be handled each month? An order of magnitude is enough."

### contentSensitivity
- **Class:** DC · **Type:** multiselect
- **Accept:** one or more valid keys, excluding `notSure`. `internalOnly` must not be combined with any personal, financial, health or legal key.
- **Reject:** empty, `notSure`, or `internalOnly` combined with sensitive keys.
- **Clarify:** the narratives mention customers' personal, financial or health details, but no matching key is selected. Quote the phrase.
- **Ask:** "Does the content include any personal, financial, health or legal information? Please select everything that applies."

### retentionRequired
- **Class:** DC · **Type:** select
- **Accept:** `yes` or `no`.
- **Reject:** `unsure`. Follow the "not sure" procedure. A records management or compliance contact usually knows.
- **Clarify:** it is `no`, but the category is `legalRequirement`, `regulatoryCommitment` or `auditCommitment`, or `contentTypes` contains `signedAgreements`.
- **Ask:** "Do any legal, regulatory or business rules require this content to be kept for a set period?"
