# Field rules: how to read them

Each tab file has one block per field, in wizard order. Every block uses these labels:

- **Class**
  - `DC`: discovery-critical. The value must be valid and specific. "Not sure" or "unknown" is never accepted, and the field blocks completion until it is resolved.
  - `REQ`: always required. Accepted options include any honest "unknown"-type option that the field block explicitly allows.
  - `COND`: required only when its condition is true. When the condition is false, the field's status is `NOT_APPLICABLE`, and any value it holds is kept in history but excluded from the normalized output.
  - `OPT`: may be blank. If a value is given, it must pass every quality and identity rule, because junk is never accepted, even in optional fields.
- **Type**: as in `field-catalog.json`.
- **Accept**: what a valid value looks like.
- **Reject (BLOCKER)**: conditions that make the value unacceptable.
- **Clarify (CLARIFY)**: conditions that need confirmation or correction.
- **Ask**: the plain-language follow-up to adapt. Never include example values that could be mistaken for the requestor's real data.

The general rules in `02-quality-standards.md` (junk, placeholders, fakes, duplicates, label echoes) apply to every text field, in addition to the rules here. The person rules in `04-identity-validation.md` apply to every `person` field and to every named contact inside a team field.

Word counts mean meaningful words. Stop-words, filler phrases and repeated words don't count.
