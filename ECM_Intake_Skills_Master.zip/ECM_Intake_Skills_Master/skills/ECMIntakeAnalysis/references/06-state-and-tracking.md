# 06: Intake record and tracking

The intake record is the single working model for the analysis step. The workflow persists it between turns. If the workflow can't persist it, keep the latest record as one compact JSON block in the session and replace it every round. Never keep two copies.

## Record shape

```json
{
  "recordType": "ECMIntakeAnalysisRecord",
  "schemaVersion": "1.0",
  "intakeId": "<from workflow, or LJKX key when available>",
  "questionnaireVersion": "6.0",
  "status": "IN_ANALYSIS | AWAITING_REQUESTOR | BASE_INTAKE_COMPLETE",
  "currentRound": 0,
  "fields": {
    "<fieldName>": {
      "initial": { "value": "<as submitted>", "source": "data-capture | session-identity", "round": 0 },
      "updates": [
        { "value": "<new value>", "source": "follow-up | directory | requestor-volunteered | requestor-confirmed-move",
          "round": 2, "answersQuestion": "Q1-4", "mode": "replace | append" }
      ],
      "current": "<the value now in force>",
      "normalized": "<canonical form, e.g. option keys, ISO date, person object>",
      "status": "VALID | INVALID | MISSING | CLARIFY | NOT_APPLICABLE | PENDING_WITH",
      "issues": [
        { "id": "ISS-0007", "severity": "BLOCKER | CLARIFY | INFO", "rule": "Q5 | XF-C9 | I2 | field", 
          "detail": "<short internal note>", "raisedRound": 1, "resolvedRound": null, "resolution": null }
      ],
      "pendingWith": null
    }
  },
  "rounds": [
    { "round": 1, "questionsAsked": [ { "id": "Q1-1", "fields": ["requestorName"], "issueIds": ["ISS-0001"] } ],
      "replyReceived": true, "fieldsUpdated": ["requestorName"], "unmatched": [], "notes": [] }
  ]
}
```

## Rules
1. **`initial` is written once and never changed.** Fields the requestor left blank have `initial.value = null`.
2. **Every change is appended to `updates`.** `current` always equals the latest update's value, or `initial` when there are no updates. For `mode: "append"` (Q6 partial answers), `current` is the earlier value plus the new text, and the update stores only the new text.
3. **`normalized`** is set only when `status = VALID`. It uses option keys for selects, ISO dates, I1 objects for people, and arrays for lists.
4. **Issues are never deleted.** A resolved issue gets `resolvedRound` and a `resolution`: `corrected`, `confirmed-with-reason` (with the reason text), or `not-applicable`.
5. **Status logic for each field:**
   - Any open BLOCKER: `INVALID`. If there's no value at all, `MISSING`.
   - Otherwise, any open CLARIFY: `CLARIFY`.
   - A DC field whose only problem is "not sure", and the requestor named a person: `PENDING_WITH`, which still blocks.
   - A condition that is false: `NOT_APPLICABLE`.
   - Otherwise: `VALID`.
6. **Record status:**
   - `AWAITING_REQUESTOR` after a follow-up is sent.
   - `IN_ANALYSIS` while processing.
   - `BASE_INTAKE_COMPLETE` only by passing `07-completion-gate.md`.
7. **IDs:**
   - Issues are numbered sequentially across the record (`ISS-0001` …).
   - Questions are numbered `Q<round>-<n>`.
8. **Requestor-volunteered values** for fields that weren't asked about get `source: "requestor-volunteered"` and are validated normally.
9. **Moves suggested by Q9** happen only after the requestor confirms, with `source: "requestor-confirmed-move"`.

## Comparing initial and final
At completion, every field reports `changed: true|false`, `roundsChanged: [..]`, `initial` and `final`. This comparison goes into the Normalized Discovery Context `provenance`, and lets reviewers see how much the base intake moved from the first submission.
