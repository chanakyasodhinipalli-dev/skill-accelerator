# 04: Identity validation

These rules apply to every `person` field (`requestorName`, `sponsoringProductOwner`, `sponsoringArchitect`, `sponsoringEngineeringLead` and `deliveryCommitmentOwner`). They also apply to every named contact inside a team field (`businessTeams`, `governanceStakeholders` and `ecmTechnicalTeams`).

## I1. A valid person reference has
1. A **full name**: at least a given name and a family name. One-word names are accepted only if the requestor says the person has a single legal name. Record that statement.
2. **One identifier**, at least: an **employee ID** that passes `EMPLOYEE_ID_PATTERN`, or a **corporate email** that passes `CORPORATE_EMAIL_DOMAINS`. Both are welcome.
3. When both are given, they must be consistent. An email local part that clearly names a different person is a `CLARIFY`.

Record each person as:
`{ "fullName": "...", "employeeId": "..."|null, "email": "..."|null, "verification": "directory"|"pattern"|"format-only"|"session-identity", "verifiedAtRound": n }`

## I2. Always rejected as a person value (BLOCKER)
- **Roles and titles** with or without a qualifier: manager, my manager, line manager, director, VP, head, lead, team lead, tech lead, architect, LOB architect, solution architect, enterprise architect, engineer, developer, product owner, PO, product manager, BA, business analyst, SME, owner, sponsor, approver, admin, support, ops, PM, scrum master, CTO, CIO, "the business".
- **Pronouns and relationships:** me, myself, I, us, we, our team, my team, my boss, my lead, them, him, her, someone, anyone, the requestor, same person, same as above.
- **Teams or groups** in a person field: "Risk team", "Architecture", "Engineering", a distribution list, a mailbox name.
- **A name without an identifier**, or **an identifier without a name**.
- **Generic or shared mailboxes:** an email whose local part is a function or role (`ecm-support@`, `team@`, `info@`, `admin@`, `noreply@`, `helpdesk@`).
- **Public, free-mail or placeholder email domains** (`00-config.md`).
- Anything that fails `02-quality-standards.md` Q1, Q2, Q3 or Q8.

Exception for "me" or "myself": if `SESSION_IDENTITY_SOURCE` provides the signed-in user's full name **and** an ID or email, resolve it to that identity, record `verification: "session-identity"`, and tell the requestor whose identity was recorded. Otherwise reject it and ask.

## I3. Directory verification (when a directory tool is available)
1. Look up the given email or ID.
2. The intake value is accepted only when the lookup finds **exactly one active** person **and** the name matches. Small spelling variations are fine, and the directory's spelling is then recorded with the requestor's original kept in history.
3. **No match** (`BLOCKER`): "I couldn't find [ID or email] in the directory. Please check it."
4. **Several matches**, for example a name-only search: list the candidates by name, title and email, and ask the requestor to pick one. Never pick on their behalf.
5. **Inactive or departed person** (`BLOCKER`): ask for the current person accountable.
6. **The tool fails or times out:** fall back to format checks, record `verification: "format-only"`, and add INFO `directory-unavailable`.

Use **only** the directory's returned data. Never add a title, department or manager that the tool didn't return.

## I4. Team fields
Each entry in `businessTeams`, `governanceStakeholders` or `ecmTechnicalTeams` must have:
- A **specific team or function name**: an organisational unit you could find in an org chart or a service catalog, for example "Enterprise Records Management", not "records".
- For `businessTeams` and `governanceStakeholders`: **at least one named contact** that passes I1.
- For `ecmTechnicalTeams`: a contact is optional. If one is given, it must pass I1.

A list is accepted only when **every** entry passes. Validate each entry on its own. Keep the valid entries, and ask only about the failing ones.

## I5. "Not yet assigned"
- `sponsoringArchitect` and `sponsoringEngineeringLead`: the explicit reply "not yet assigned" is accepted. Record it as `{"assigned": false}` with INFO for reviewers.
- `requestorName`, `sponsoringProductOwner` and `deliveryCommitmentOwner` (when required): "not yet assigned" is a `BLOCKER`. Explain that discovery can't begin without an accountable person, and keep the field open.

## I6. Privacy
Use identity data only to validate the intake and to hand it to the next step. Don't add any personal detail about a person beyond what the requestor or the directory provided.
