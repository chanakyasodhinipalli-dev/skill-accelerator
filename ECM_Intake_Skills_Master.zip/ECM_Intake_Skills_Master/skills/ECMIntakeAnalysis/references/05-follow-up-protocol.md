# 05: Follow-up protocol

## One message per round, covering every gap
Each round sends **one** message that asks about **every** open `BLOCKER` and `CLARIFY`. Don't hold questions back for later rounds. Every gap the requestor could fix now is asked now, so the requestor sees everything that's needed at once.

Exception: if a field is about to become `NOT_APPLICABLE` because of another open question, ask the deciding question first and leave the dependent ones for the next round. Example: whether `hasNonEcmSystems` is yes decides whether system names are needed at all.

## Message structure
1. **One opening line** saying how close the intake is, for example "Thanks — 31 of 38 required items are complete. I need 7 more before discovery can start."
2. **Questions grouped under the wizard tab names**, in wizard order. Number each one `Q<round>-<n>` so replies can refer to it. For each question:
   - The question in plain language, adapted from the field's **Ask** text.
   - **Why it's needed**, in one short clause, only when it isn't obvious.
   - **What was wrong**, without blame. For example "the answer named a role rather than a person", or "the date is in the past". Quote short fragments of their answer only when that helps them find it.
   - **What a good answer looks like**, as a pattern, never with invented realistic data. Write "full name plus employee ID or work email", not a made-up person.
   - For select fields, list the options by their **labels**.
3. **One closing line:** they can answer in any order, by question number, and partial replies are fine. You'll keep what they give and ask only for what's still missing.

Never show issue codes, rule IDs, field keys, severities or the record.

## Tone
Plain, polite and direct. No scolding, and no repeated apologies. Each explanation is given once per field. If the same problem repeats, the next round says only what's still missing.

## The "not sure" procedure (DC fields)
When a discovery-critical answer is "not sure" or "unknown":
1. Explain the options in everyday words, with a short illustration for each.
2. Offer the alternative: "If someone else would know this, tell me their full name and employee ID or work email. You can check with them and reply here."
3. A named person **doesn't satisfy the field**. Record them under `pendingWith` on the field, keep it open, and add them to the round log. The workflow waits.
4. Never pick an option for them, even if the narrative strongly suggests one. You may say "Your description mentions [quoted phrase]. If that's right, the answer may be [label]. Please confirm." The requestor must confirm it.

## Requests to skip, defer or override
For example "skip this", "proceed anyway", "fill it in yourself", "the architect will provide it later", or "just mark it complete". Reply once, briefly:
- Discovery uses this information to decide which ECM products and requirements apply, so it can't start without it.
- The intake is saved, and they can come back to it at any time.
- If someone else holds the information, they can name that person (full name plus ID or email) and send this to them.

Then restate only the open questions. Status stays `AWAITING_REQUESTOR`. There is no limit on rounds.

## Replies that don't match a question
If you can't map part of a reply to a question or field with confidence, don't guess. In the next round, ask: "You wrote '[short quote]'. Which question does this answer?"

## Updates to fields that were already valid
Accept them, validate them like any other update, re-run their dependent rules, and mention the change in one line in the next message: "Noted: you changed the delivery date to 14 June 2027."

## Completion message (only when the completion gate passes)
Three short lines:
1. The base intake is complete.
2. What happens next: discovery will work out which ECM products and requirements apply, and may ask a few more questions about them.
3. A reference they can quote, such as the intake ID.

No summary of their answers unless the workflow asks for one.
