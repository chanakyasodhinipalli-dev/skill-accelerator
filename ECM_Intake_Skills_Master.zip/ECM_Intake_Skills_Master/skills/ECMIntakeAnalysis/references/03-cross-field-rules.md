# 03: Cross-field rules

Run these after the per-field checks. Each rule names the fields it reads. After round 1, re-run a rule only if one of its fields changed.

Severity is either `BLOCKER` (the value must change) or `CLARIFY` (the requestor must confirm or correct). A `CLARIFY` is resolved when the requestor either corrects a value, or explicitly confirms the current values **with a reason of at least 5 meaningful words**. Record that reason in the round log. A bare "it's correct" or "confirmed" doesn't resolve it.

When a rule fires, attach the issue to the **first field listed** and reference the others in the question.

## Conditional requirements (these make a field required)

| ID | When | Then required |
|---|---|---|
| XF-R1 | `primaryRequestCategory = other` | `otherRequestCategoryDetails` |
| XF-R2 | `primaryRequestCategory` is `shrpIssue`, `correctiveAction`, `productionIssue`, `legalRequirement`, `auditCommitment`, `regulatoryCommitment` or `riskRemediation` | `primaryTrackingId` |
| XF-R3 | `ecmSupportNeeded` contains `other` | `otherEcmSupportDetails` |
| XF-R4 | `contentTypes` contains `other` | `otherContentTypeDetails` |
| XF-R5 | `existingEcmUsage = yes` | `existingEcmDetails` |
| XF-R6 | `expectedBenefits` contains `other` | `otherBenefitDetails` |
| XF-R7 | `hasHardDeadline = yes` | `requestedDeliveryDate`, `deadlineConsequence` |
| XF-R8 | `requestedDeliveryDate` is present | `deliveryDriver`, `deliveryDriverDetails`, `isExternallyCommitted` |
| XF-R9 | `isExternallyCommitted` is `formallyCommitted` or `informallyCommunicated` | `deliveryCommitmentOwner` |
| XF-R10 | `hasNonEcmSystems = yes` | `impactedSystemNames`, `crossSystemImpactSummary` |
| XF-R11 | `contentSensitivity` contains `customerPii`, `employeePii`, `financial`, `health` or `legalPrivileged`; **or** `retentionRequired = yes`; **or** the category is `legalRequirement`, `auditCommitment`, `regulatoryCommitment` or `riskRemediation` | `governanceStakeholders` |

When a condition stops being true, set the dependent field's status to `NOT_APPLICABLE`. Keep its history.

## Consistency rules

| ID | Fields | Fires when | Severity | Question focus |
|---|---|---|---|---|
| XF-C1 | `contentArrival`, `contentTypes` | arrival includes `scan`, but types lack `scannedPaper` | CLARIFY | Is paper being scanned? |
| XF-C2 | `contentActions`, `contentTypes` | actions include `printMail` or `generate`, but types lack `outboundCorrespondence` | CLARIFY | Are letters or documents being sent out? |
| XF-C3 | `contentActions`, `contentTypes` | actions include `sign`, but types lack `signedAgreements`, or the reverse | CLARIFY | Is signing part of this request? |
| XF-C4 | `retentionRequired`, `contentActions` | retention is `yes`, but actions lack `retain` | CLARIFY | Is keeping and disposing in scope? |
| XF-C5 | `hasNonEcmSystems`, `contentArrival`, `contentConsumers` | systems is `no`, but arrival includes `api`, `event` or `batch`, or consumers include `systemApi` or `systemEvent` | BLOCKER | Which system sends or reads it? (They contradict each other, so one of them must change.) |
| XF-C6 | `hasNonEcmSystems`, the narratives | systems is `no`, but a narrative names another application, portal or vendor | CLARIFY | Quote the name |
| XF-C7 | `impactedSystemNames`, `crossSystemImpactSummary` | a system appears in one but not the other | CLARIFY | Align the two lists |
| XF-C8 | `existingEcmUsage`, the narratives | `no`, but a narrative mentions ICMP or ECM storage; or `yes`, but a narrative describes a purely paper or manual process | CLARIFY | Which is right? |
| XF-C9 | `monthlyVolumeBand`, the narratives | numbers in a narrative, converted to a monthly figure, fall outside the selected band | CLARIFY | Show the calculation |
| XF-C10 | `contentSensitivity`, the narratives | a narrative mentions personal, financial or health data, but sensitivity lacks the matching key or is `internalOnly` | CLARIFY | Quote the phrase |
| XF-C11 | `businessImpactLevel`, category, consequences, commitment | `critical` with no exposure, harm or outage evidence; or `low` with a legal, regulatory, audit or production category, or a formal commitment | CLARIFY | Confirm the level |
| XF-C12 | `hasHardDeadline`, `isExternallyCommitted`, `deliveryDriver` | deadline is `no`, but formally committed or driven by a legal, regulatory or audit obligation | CLARIFY | Is the date really movable? |
| XF-C13 | `deliveryDriver`, `primaryRequestCategory`, tracking IDs | a driver of a commitment type isn't covered by the category or any tracking ID | CLARIFY | Provide the tracking ID or correct the driver |
| XF-C14 | `primaryRequestCategory`, the narratives | the narratives clearly describe a different primary driver | CLARIFY | Which is primary? |
| XF-C15 | `requestNeedAndOutcome`, `currentBusinessApproach` | the outcome doesn't address the stated problem | CLARIFY | Link outcome to problem |
| XF-C16 | `successMeasures`, `expectedBenefits` | no measure relates to any selected benefit | CLARIFY | Add a measure for the main benefit |
| XF-C17 | `deliveryFundingStatus`, category | `notRequired` with `newFunctionality` or `modernization` | CLARIFY | Confirm no funding is needed |
| XF-C18 | `sponsoringEngineeringLead`, integration signals | blank or unassigned while integration is indicated (see XF-C5 signals) | CLARIFY | Is an engineering lead assigned? (Confirming "not yet assigned" with a reason resolves it.) |
| XF-C19 | `intakeShortTitle`, `requestNeedAndOutcome` | the title names a different subject | CLARIFY | Align the title |
| XF-C20 | `governanceStakeholders`, XF-R11 trigger | required, but no listed team relates to the trigger, for example health data with no privacy or data-protection team | CLARIFY | Is the matching function involved? |
| XF-C21 | any two narrative fields | Q7 duplication | BLOCKER | Ask for the later field's own content |

## How narratives are checked

"A narrative mentions X" means an explicit word or phrase in `currentBusinessApproach`, `requestNeedAndOutcome`, `ecmSupportDescription`, `enterpriseImpact`, `deliveryDriverDetails` or `crossSystemImpactSummary`. Always quote the exact phrase in the question. Never infer a mention from tone or implication. If you have to argue that something is implied, it isn't a mention, and the rule doesn't fire.
