# Example: ECMIntakeAnalysis, round 1

*Synthetic test data. Names and IDs are invented for testing only.*

## Submission (excerpt)
| Field | Submitted value |
|---|---|
| requestorName | (prefilled) Priya Raman, E1048273 |
| sponsoringProductOwner | my manager |
| sponsoringArchitect | LOB architect |
| intakeShortTitle | ECM request |
| primaryRequestCategory | regulatoryCommitment |
| primaryTrackingId | (blank) |
| currentBusinessApproach | Branch staff scan loan applications and email them to the back office, who key the details into the loan system. |
| requestNeedAndOutcome | Improve efficiency and customer experience. |
| contentArrival | scan, email |
| contentTypes | digitalDocuments |
| contentActions | notSure |
| monthlyVolumeBand | lt10k |
| hasNonEcmSystems | no |
| contentSensitivity | customerPii, financial |
| governanceStakeholders | Compliance |

## Issues the skill should raise
| Field | Severity | Why |
|---|---|---|
| sponsoringProductOwner | BLOCKER | Role, not a person (I2) |
| sponsoringArchitect | BLOCKER | Role, not a person. Blank or "not yet assigned" would have been accepted (I5). |
| intakeShortTitle | BLOCKER | Generic title |
| primaryTrackingId | BLOCKER | Required for regulatory commitment (XF-R2) |
| currentBusinessApproach | BLOCKER | Part (c), the problem, is missing; under 40 words |
| requestNeedAndOutcome | BLOCKER | Generic (Q5); no anchors; doesn't relate to the problem |
| contentTypes | CLARIFY | Scanning is selected, but scanned paper isn't (XF-C1). The narrative says "email them", but emails aren't selected. |
| contentActions | BLOCKER | "Not sure" isn't accepted on a discovery-critical field |
| hasNonEcmSystems | CLARIFY | The narrative names "the loan system" (XF-C6) |
| governanceStakeholders | BLOCKER | Required (XF-R11); a generic team with no named contact (I4) |

## Expected follow-up message (shape)
> Thanks. Most of the intake is in place. I need 10 more items before discovery can start. You can answer in any order, using the question numbers.
>
> **Requestor and Ownership**
> **Q1-1.** Who is the product owner accountable for scope and priority? The answer named a role. Please give their full name and their employee ID or work email.
> **Q1-2.** If a sponsoring architect is assigned, please give their full name and employee ID or work email. If not, reply "not yet assigned".
> **Q1-3.** Because this request involves customer personal and financial information and is driven by a regulatory commitment, please name the governance teams that must review it. For each, give the team's specific name and a contact's full name with their employee ID or work email.
>
> **Request Summary**
> **Q1-4.** Please give a short title that says what is changing and for which business area.
> **Q1-5.** This is driven by a regulatory commitment, so it needs the authoritative tracking ID. Please give the ID and say which system it comes from.
> **Q1-6.** You've described what happens today. What is the main problem or limitation with the current way of working?
> **Q1-7.** What should be different once this is delivered, and for whom? Please describe the result, not the technology.
>
> **Content and Usage**
> **Q1-8.** You selected "Scanned from paper" and mentioned emailing documents. Should "Scanned paper documents" and "Emails and attachments" be added to the kinds of content?
> **Q1-9.** What needs to happen to the content? For example: collect it, store it, look it up later, pull data out of it automatically… (options listed). If someone else knows, give me their full name and employee ID or work email.
>
> **Connected Systems**
> **Q1-10.** You mentioned "the loan system". Is it a system outside ECM that's involved in this request?
>
> Partial replies are fine. I'll keep what you give and ask only for what's still missing.
