# Example: ECMIntakeDiscovery, round 1

*Synthetic test data.*

## Effective base facts (excerpt from the Normalized Discovery Context)
- `content.arrival` = scan, email
- `content.actions` = receive, store, retrieve, classifyExtract, retain
- `content.consumers` = employeeUi, systemApi
- `content.retentionRequired` = yes
- `systems.hasNonEcmSystems` = yes, with impactedSystems = ["Loan Origination System (LOS)"]
- `request.ecmSupportHints` = icmpOnboarding, printMail

## Domain applicability
| Domain | Status | Evidence |
|---|---|---|
| core-onboarding, security-compliance | APPLICABLE | always |
| icmp-repository | APPLICABLE | DA-01 (actions store, retrieve) |
| content-capture | APPLICABLE | DA-04 (arrival scan, email) |
| document-ai | APPLICABLE | DA-07 (actions classifyExtract) |
| virus-scan | APPLICABLE | DA-13 (arrival email) |
| api-onboarding | APPLICABLE | DA-16 (consumers systemApi) |
| records-retention | APPLICABLE | DA-20 (retention yes) |
| solution-architecture | APPLICABLE | DA-24 (non-ECM systems yes) |
| testing-performance | APPLICABLE | DA-26 |
| print-mail | **CANDIDATE** | DA-12 (hint only) |
| document-generation, esignature, event-integration, content-migration | NOT_APPLICABLE | no signal |

## Round 1 asks only P1
- The print-mail applicability question, because it is a hint only.
- DP-CORE-05, the scrum team. It is a gate: it decides the environments and the SPLI project.
- DP-CORE-06, the target environments. Also a gate.
- DP-REP-01, the document kinds. A gate, because document AI and records reuse it.
- DP-API-02, the operations. A gate, because uploads can trigger a virus-scan base correction.
- DP-SA-01, the system roles. Also a gate.

P2 and P3 questions (formats, volumes, index fields, retention periods, and so on) are held until the P1 answers are in, because those answers can remove questions.

## What must not happen
- Print and mail is **not** selected only because the requestor ticked it.
- No requirement is drafted for formats or SLAs before the data points are answered.
- Discovery doesn't say "ICMP supports files up to X MB". That value is UNSET, so the requirement gets `FIT_CHECK_PENDING`.
