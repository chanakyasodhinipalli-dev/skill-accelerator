# Item Catalogue

> Agent instruction · everything the partner can ask for by name

Partners will ask in their own words. Resolve what they say to an item id, confirm the match back to them in one line, then apply the entry rules in `01_entry-modes.md`.

Two levels are selectable:

- **Skill level** (`UC3`) — the whole use case, its goal and all its procedures.
- **Procedure level** (`UC3.11`) — one procedure on its own.

If a partner names something that maps to several items, offer the two or three closest and ask which. If it maps to nothing, say so plainly rather than running the nearest thing.

---

| Item id | Level | Name | Skill | Phase | Rules |
|---|---|---|---|---|---|
| `UC1` | skill | POC Assistance | `poc-assistance` | P1 | BR-03, BR-04, BR-06, BR-13, BR-11, BR-09 |
| `UC1.1` | procedure | Intake-Free Activity Catalogue | `poc-assistance` | P1 | BR-03 |
| `UC1.2` | procedure | Apigee Innovation API Connectivity | `poc-assistance` | P3 | BR-04, BR-06, BR-13 |
| `UC1.3` | procedure | Document Ingestion (POC) | `poc-assistance` | P2 | — |
| `UC1.4` | procedure | Search & Read Documents | `poc-assistance` | P2 | BR-11, BR-13 |
| `UC1.5` | procedure | ICMP UI Access Guidance | `poc-assistance` | P1 | BR-09 |
| `UC1.6` | procedure | Documentation Pointers | `poc-assistance` | P1 | — |
| `UC2` | skill | Intake Verification | `intake-verification` | P3 | BR-01, BR-02 |
| `UC2.1` | procedure | LJKX Key Format Validation | `intake-verification` | P1 | BR-01 |
| `UC2.2` | procedure | Duplicate Intake Prevention | `intake-verification` | P2 | BR-02 |
| `UC2.3` | procedure | ECM Intake Creation Walkthrough | `intake-verification` | P2 | — |
| `UC2.4` | procedure | Intake Summarisation & Scope Interpretation | `intake-verification` | P3 | — |
| `UC2.5` | procedure | Scrum Team Project Key Resolution | `intake-verification` | P3 | — |
| `UC2.6` | procedure | Unresolved & Unlinked Field Handling | `intake-verification` | P3 | — |
| `UC3` | skill | Foundational Setup | `foundational-setup` | P1 | BR-11, BR-07, BR-08, BR-10, BR-09, BR-12 |
| `UC3.1` | procedure | ICMP Foundations | `foundational-setup` | P2 | — |
| `UC3.2` | procedure | ICMP Capabilities Catalogue | `foundational-setup` | P2 | BR-11 |
| `UC3.3` | procedure | Repository Support | `foundational-setup` | P2 | — |
| `UC3.4` | procedure | ICMP FileNet | `foundational-setup` | P2 | — |
| `UC3.5` | procedure | Documentum | `foundational-setup` | P2 | — |
| `UC3.6` | procedure | DMS | `foundational-setup` | P2 | — |
| `UC3.7` | procedure | MARS | `foundational-setup` | P2 | — |
| `UC3.8` | procedure | Legacy Repositories | `foundational-setup` | P2 | — |
| `UC3.9` | procedure | Marketplace Access | `foundational-setup` | P3 | — |
| `UC3.10` | procedure | Service Account Provisioning | `foundational-setup` | P3 | BR-07, BR-08, BR-10 |
| `UC3.11` | procedure | QAEnt Service Account Creation | `foundational-setup` | P3 | BR-08, BR-10 |
| `UC3.12` | procedure | ADEnt Service Account Creation | `foundational-setup` | P3 | BR-08, BR-10 |
| `UC3.13` | procedure | User Access Provisioning | `foundational-setup` | P3 | BR-09 |
| `UC3.14` | procedure | QAEnt User Access | `foundational-setup` | P3 | BR-09 |
| `UC3.15` | procedure | ADEnt User Access (AIMS) | `foundational-setup` | P3 | BR-09 |
| `UC3.16` | procedure | ART / AIMS Routing Boundary | `foundational-setup` | P1 | BR-08, BR-09 |
| `UC3.17` | procedure | BAM Lookup | `foundational-setup` | P1 | — |
| `UC3.18` | procedure | Venafi Certificates | `foundational-setup` | P1 | BR-11, BR-12 |
| `UC3.19` | procedure | Ownership & Support Assessment | `foundational-setup` | P2 | — |
| `UC4` | skill | Volume Assessment | `volume-assessment` | P3 | BR-19, BR-20, BR-21, BR-22 |
| `UC4.1` | procedure | Volume Rationale & Stakes | `volume-assessment` | P1 | BR-19, BR-20 |
| `UC4.2` | procedure | Per-Operation Volume Collection | `volume-assessment` | P1 | BR-19 |
| `UC4.3` | procedure | Special-Day & Growth Profiling | `volume-assessment` | P1 | BR-19, BR-21 |
| `UC4.4` | procedure | IIVaaS / ICMP UI User Profiling | `volume-assessment` | P1 | BR-19 |
| `UC4.5` | procedure | Estimation & Buffer Guidance | `volume-assessment` | P1 | BR-19, BR-22 |
| `UC4.6` | procedure | Capacity Planning Ticket Creation | `volume-assessment` | P3 | BR-19, BR-21 |
| `UC5` | skill | Load Testing (SPLI) | `load-testing-spli` | P3 | BR-22 |
| `UC5.1` | procedure | Test Case Derivation | `load-testing-spli` | P2 | — |
| `UC5.2` | procedure | Load Test Template Mapping | `load-testing-spli` | P2 | — |
| `UC5.3` | procedure | SPLI Requirement Package | `load-testing-spli` | P2 | BR-22 |
| `UC5.4` | procedure | SPLI Ticket Creation | `load-testing-spli` | P3 | BR-22 |
| `UC6` | skill | Apigee Subscription | `apigee-subscription` | P1 | BR-04, BR-05, BR-06, BR-10, BR-13, BR-14, BR-15, BR-16 |
| `UC6.1` | procedure | Consumer Application Creation / Modification | `apigee-subscription` | P1 | BR-04, BR-05 |
| `UC6.2` | procedure | App Identifier Population & Validation | `apigee-subscription` | P1 | BR-06, BR-10 |
| `UC6.3` | procedure | Environment ↔ Service Account Mapping | `apigee-subscription` | P2 | BR-10 |
| `UC6.4` | procedure | Scope Selection & Permission Explanation | `apigee-subscription` | P2 | BR-13 |
| `UC6.5` | procedure | Subscription Tier Identification | `apigee-subscription` | P2 | BR-14, BR-15 |
| `UC6.6` | procedure | Subscription Form Completion & Submission | `apigee-subscription` | P1 | BR-05, BR-06 |
| `UC6.7` | procedure | Approval Evidence Package | `apigee-subscription` | P1 | BR-16 |
| `UC7` | skill | Postman Collection Generation | `postman-collection-generation` | P3 | BR-13 |
| `UC7.1` | procedure | Scope-Driven Collection Build | `postman-collection-generation` | P3 | BR-13 |
| `UC7.2` | procedure | Environment Variable Seeding | `postman-collection-generation` | P3 | — |
| `UC7.3` | procedure | Download Delivery | `postman-collection-generation` | P3 | — |
| `UC8` | skill | Environment Progression | `environment-progression` | P2 | BR-17, BR-18, BR-21 |
| `UC8.1` | procedure | Progression Gating Rules | `environment-progression` | P2 | BR-17, BR-18 |
| `UC8.2` | procedure | Per-Environment Sign-Off Capture | `environment-progression` | P3 | BR-18 |
| `UC8.3` | procedure | Scrum Team Dependency Check | `environment-progression` | P3 | BR-17 |
| `UC8.4` | procedure | Volume-Change Obligation Notice | `environment-progression` | P1 | BR-21 |

---

## Common phrasings

Resolved from the catalogue, not hand-maintained.

| Partner says | Item |
|---|---|
| "check my intake" / "look up my ticket" | `UC2` |
| "is my Jira number valid" | `UC2.1` |
| "which project do my tickets go in" | `UC2.5` |
| "what can ICMP do" | `UC3.2` |
| "which repository am I on" | `UC3.3` |
| "service account" / "how do I get an account" | `UC3.10` |
| "ART or AIMS" / "where do I request access" | `UC3.16` |
| "certificates" | `UC3.18` |
| "who supports this" / "ownership" | `UC3.19` |
| "volumes" / "capacity" | `UC4` |
| "we do not know our volumes" | `UC4.5` |
| "load testing" / "SPLI" | `UC5` |
| "subscribe to the APIs" / "Apigee" | `UC6` |
| "which tier" | `UC6.5` |
| "what scopes do I need" | `UC6.4` |
| "postman collection" | `UC7` |
| "move to production" / "sign-off" | `UC8` |
| "just trying it out" / "POC" | `UC1` |