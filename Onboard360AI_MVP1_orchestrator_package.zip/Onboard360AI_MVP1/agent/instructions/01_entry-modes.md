# Entry Modes

> Agent instruction · how a session starts and how the partner chooses what to run

Onboard360AI supports **two entry modes**. Offer both explicitly in the opening message — a
partner who does not know direct pick exists will sit through the whole sequence to reach one step.

## Mode A — Sequential flow

The full onboarding path, in order, from the eligibility gate.

- **No feature number required.** The LJKX onboarding intake covers the whole sequence.
- Determine the branch first: POC, or actual project implementation.
- Run the branch order, gate by gate. Do not skip.

```
POC ............. UC1 (drawing on UC3 for access) → UC6 → UC7
Implementation .. UC2 → UC3 → UC4 → UC6 → UC7 → UC5 → UC8
```

## Mode B — Direct pick

The partner names a single item — a whole skill (`UC3`) or one procedure inside it (`UC3.11`).

- **A PZTTD feature number is required before the item runs.**  [BR-25]
- See `02_pzttd-feature-gate.md` for how to collect and verify it.
- Consult `03_item-catalogue.md` to resolve what the partner named to an item id. Partners will
  ask in their own words — "the ART or AIMS thing", "just the certificates" — not by item id.

## What counts as "in between"

The gate exists to keep out-of-sequence work traceable to a feature. Apply it as follows:

| Situation | PZTTD required? |
|---|---|
| Starting the sequential flow from the beginning | **No** |
| Progressing to the next item in sequence | **No** |
| Resuming the sequence where it was left off | **No** |
| Naming any item as the first thing in a session | **Yes** |
| Jumping forward past an unrun item | **Yes** |
| Going back to re-run a completed item | **Yes** |
| Running a POC item while on the implementation branch, or the reverse | **Yes** |

One verified PZTTD covers the item it was given for and everything run sequentially from it. A
**further** out-of-sequence pick needs its own feature number — or the partner confirming the same
feature covers it, which you record.

## Ambiguity

If the partner's intent is unclear — "can we look at volumes?" could be a question or a request to
run UC4 — ask which they mean before invoking the gate. Do not ask for a feature number to answer a
question. **The gate applies to running an item, not to talking about one.**

## Switching modes mid-session

A partner may move between modes freely.

- Direct pick → sequential: ask where they want the sequence to resume, then run it in order from
  there. No further feature number for the onward sequence.
- Sequential → direct pick: apply the gate to the picked item.

Always tell the partner which mode they are in and what it means for prerequisites.
