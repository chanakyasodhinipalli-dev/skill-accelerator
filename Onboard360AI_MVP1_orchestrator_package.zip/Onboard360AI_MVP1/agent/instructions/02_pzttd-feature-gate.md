# PZTTD Feature Gate

> Agent instruction · required whenever the flow is entered anywhere other than its start
> Business rules: **BR-25**, **BR-26**

## The rule

Entering the onboarding flow at any point other than its start — a direct pick, or a jump out of
sequence — requires a **PZTTD feature number**, and that feature must be a **child of the LJKX
onboarding intake**.  [BR-25]

Sequential work from the beginning does not need one: the LJKX intake already covers it.

## Why

The LJKX intake authorises the onboarding as a whole. Individual pieces of work picked out of
sequence are tracked as **PZTTD feature tickets underneath it**. Without the feature number, work
happens that nobody can trace back to an approved intake — and the team that owns the intake has no
record that it was done. Say this to the partner if they push back; it is a traceability
requirement, not paperwork.

## Collecting it

Ask directly, and say what it is for:

> "That's an out-of-sequence pick, so I need the PZTTD feature number it sits under before I run
> it. It should be a feature ticket under your LJKX onboarding intake — format `PZTTD-1234`."

## Validating it — in this order, and stop at the first failure

### 1. Format  [BR-26]

Regex: `^PZTTD-\d+$`

| Valid | Invalid | Why |
|---|---|---|
| `PZTTD-1234` | `1234` | no project key |
| `PZTTD-89` | `PZTTD` | no number |
| `PZTTD-7` | `PZTTD1234` | no hyphen |
| | `pzttd-1234` | accept case-insensitively, but normalise to upper case |
| | `LJKX-1234` | that is the intake, not a feature — see below |

Validate the format **before** any tool call. On failure, name the rule that was broken and re-ask.
Never auto-correct the key: a partner who typed the wrong project may be looking at the wrong ticket
entirely.

### 2. Retrieve

Call **Jira MCP `get_issue`** with the normalised key.

- Not found, or no access → report the diagnosis in plain language. Do not proceed.

### 3. Verify parentage  [BR-26]

Call **Jira MCP `get_issue_links`** and establish the parent. Accept any of: parent, epic link, or a
"child of" issue link that resolves to an `LJKX-\d+` key.

| Outcome | What you do |
|---|---|
| Parent resolves to an LJKX intake | Proceed to step 4 |
| Parent resolves to a non-LJKX issue | **Refuse.** Say the feature is not under an ICMP onboarding intake, and ask for one that is |
| No parent at all | **Refuse.** Ask them to link the feature to their LJKX intake first, then come back |
| At phase 1 or 2, links are not retrievable | Ask the partner to confirm the parent intake key, record it as partner-supplied provenance, and say plainly you could not verify it |

### 4. Reconcile against journey state

| Situation | What you do |
|---|---|
| No intake key held yet | Record the parent LJKX key from the feature as the intake key, provenance `system` |
| Held intake key matches the parent | Proceed |
| Held intake key differs from the parent | **Surface the conflict.** Do not overwrite. Ask which is correct — they may be onboarding two systems, or looking at the wrong ticket |

## If the partner has no PZTTD

Do not refuse and stop. Give them the route:

1. Confirm the LJKX intake exists — if not, that is the real gap, and they need `UC2` first.
2. Tell them to raise a PZTTD feature under that intake.
3. Offer to continue with anything that does **not** need the gate: answering questions about the
   item, explaining what it will ask for, or running the sequence from the beginning.

## Recording

On success, record in journey state: `pzttdFeatureKey`, `pzttdParentIntake`, the item it authorises,
and the provenance of the parentage check (`system` if verified via links, `partner` if confirmed
verbally). Restate the feature number when you report the item's output, so the partner's own record
ties the work to the ticket.

## Scope of one feature number

A verified PZTTD covers **the item it was given for, and anything run sequentially onward from it**.
A further out-of-sequence pick needs its own feature number, or the partner explicitly confirming
the same feature covers it — which you record with `partner` provenance.
