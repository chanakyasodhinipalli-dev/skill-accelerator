# Tools, Integration Phases and Runtime Disclosure

> Agent instruction

## Integration maturity

| Phase | Mode | Behaviour |
|---|---|---|
| **P1** | Link out | Return Confluence and knowledge-base links; the partner self-serves |
| **P2** | Read and guide | Read those pages, answer and guide from them step by step |
| **P3** | Direct integration | MCP or system API — read, write, validate live |

Operate at the highest phase enabled. If a P3 call fails, degrade to P2, then P1, and say which mode you are in.

## Runtime disclosure  [BR-23]

State in your opening message, and again on entering each skill, both of:

1. **What is integrated today** — which systems you can reach, and whether that means linking, guiding, or transacting.
2. **What the next phase adds**.

One or two lines. Orientation, not a disclaimer.

## Tool register

| Tool | Transport | Status | Phase | Functions |
|---|---|---|---|---|
| **Jira MCP** | MCP | AVAILABLE | P3 | `get_issue`, `get_project`, `get_issue_links` |
| **Jira MCP** | MCP | AVAILABLE | P3 | `create_issue`, `get_issue` |
| **Knowledge Base / Confluence** | Local reference material | PHASED | P1 now, P2 target | `return_links`, `read_and_answer` |
| **Apigee API Marketplace** | Not integrated — instructions only | PLANNED | P1 now, P3 target | `(future) list_apis`, `(future) create_subscription`, `(future) get_subscription_status` |
| **BAM — Business Application Management** | Not integrated — instructions only | PLANNED | P1 now, P3 target | `(future) get_application` |
| **Venafi** | Not integrated — instructions only | PLANNED | P1 now, P3 target | `(future) request_certificate`, `(future) get_certificate_status` |
| **ART — Access Request Tool** | Not integrated — instructions only | PLANNED | P1 now, P3 target | `(future) create_service_account_request`, `(future) add_group_membership`, `(future) create_user_access_request` |
| **AIMS — Access and Identity Management System** | Not integrated — instructions only | PLANNED | P1 now, P3 target | `(future) request_ldap_group_access` |
| **ICMP & iDocs APIs** | Direct API | AVAILABLE | P3 | `icmp_ingest`, `icmp_search`, `icmp_retrieve`, `icmp_notifications`, `idocs_document_services` |
| **Local Tools** | Local (Tachyon SDK) | AVAILABLE | P3 | `validate_format`, `assemble_payload`, `state_read_write` |
| **Postman Collection Generator** | Local tool | AVAILABLE | P3 | `build_collection`, `emit_download` |