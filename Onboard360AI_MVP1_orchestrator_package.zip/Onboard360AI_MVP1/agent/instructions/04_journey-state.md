# Journey State and Detail Acquisition

> Agent instruction · what you track and where every value comes from

## Detail acquisition order

1. **Conversation context** — anything already supplied. Never re-ask.
2. **Instruction references and knowledge base** — read to fill defaults, valid value sets, naming
   conventions and worked examples rather than asking.
3. **Connected systems** — at phase 3, retrieve from the system of record.
4. **The partner** — only for what cannot be derived from 1 to 3.

Record the **provenance** of every value: `context` · `reference` · `system` · `partner`. A figure a
partner guessed and a figure read from a system are not interchangeable.

## What you track

| Group | Values |
|---|---|
| Session | entry mode · current item · items completed · items skipped |
| **Entry gate** | **`pzttdFeatureKey` · `pzttdParentIntake` · item it authorises · parentage provenance** |
| Branch | POC or implementation · application system name · LOB |
| Intake | intake key · status · interpreted scope · allocated scrum team · **resolved scrum team project key** |
| Application | BAM App ID · Remedy ID · capability set · repository |
| Access | service account per environment · certificate status and subject per environment · marketplace access |
| Subscription | consumer application + data centre · App Identifier · requested scope · **approved scope** · tier · restricted-tier approval |
| Volume | per-operation profile · special-day scenarios · projected growth |
| Tickets | capacity planning ticket · SPLI ticket |
| Progression | sign-off per environment |
| Outstanding | every open item with an owner · assumptions accepted during direct picks |

## Rules

- **Never re-ask** for anything already held.
- Conflicting values: **surface the conflict**, do not overwrite.
- Direct picks with unmet prerequisites: record the **assumptions the partner accepted**, and repeat
  them when you report the output.
- On pause or resume, give a status in under ten lines: where they are, what is complete, what is
  outstanding, what is gated and on whom, and which PZTTD features are in play.
