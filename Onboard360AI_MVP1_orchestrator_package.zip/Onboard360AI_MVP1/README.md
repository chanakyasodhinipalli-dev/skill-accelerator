# Onboard360AI — ICMP Partner Onboarding · MVP 1
## One orchestrating agent · 8 skills · instructions as `.md`

| | |
|---|---:|
| Agents | **1** — `onboard360ai`, orchestration only |
| Sub-agents | **0** |
| Skills | **8** |
| Agent instruction references | 9 |
| Skill instruction references | 55 |
| Selectable items | **63** |
| Business rules | 26 (BR-25 and BR-26 are new) |

## What is new in this revision

**Two entry modes.** The partner can run the full sequence, or pick any individual item — a whole
skill (`UC3`) or one procedure inside it (`UC3.11`). Both are offered explicitly in the opening
message, because a partner who does not know direct pick exists will sit through the whole sequence
to reach the one step they came for.

**The PZTTD feature gate.** Entering the flow anywhere other than its start requires a **PZTTD
feature number that is a child of the LJKX intake**.

| Situation | PZTTD required? |
|---|---|
| Starting the sequence from the beginning | No |
| Progressing to the next item in order | No |
| Resuming where it was left off | No |
| Naming an item as the first thing in a session | **Yes** |
| Jumping forward past an unrun item | **Yes** |
| Going back to re-run a completed item | **Yes** |
| Crossing between the POC and implementation branches | **Yes** |

Verification is four steps, stopping at the first failure: **format** (`^PZTTD-\d+$`, checked before
any tool call) → **retrieve** (`get_issue`) → **verify parentage** (`get_issue_links`; parent, epic
link or "child of" must resolve to an `LJKX-\d+` key) → **reconcile** against journey state,
surfacing a conflict rather than overwriting.

One verified feature covers the item it was given for and anything run sequentially onward. A
further out-of-sequence pick needs its own.

**The gate applies to running an item, not to talking about one.** Questions about what an item does
are answered without it.

## Structure

```
Onboard360AI_MVP1/
├── _manifest.json
├── agent/
│   ├── onboard360ai.json            the orchestrator
│   ├── onboard360ai.md
│   └── instructions/                9 agent-level .md references
│       ├── 00_orchestration.md
│       ├── 01_entry-modes.md
│       ├── 02_pzttd-feature-gate.md
│       ├── 03_item-catalogue.md
│       ├── 04_journey-state.md
│       ├── 05_business-rules.md
│       ├── 06_reference-data.md
│       ├── 07_tools-and-phases.md
│       └── 08_glossary.md
├── skills/
│   ├── 01_poc-assistance/
│   │   ├── skill.json
│   │   ├── skill.md
│   │   └── instructions/*.md        procedure references
│   └── … 8 skills
└── _shared/
    ├── business-rules.json · glossary.json · tools.json
    └── item-catalogue.json          every selectable item
```

## Skills and selectable items

| Item | Skill | Branch | Procedures | Item ids | Next |
|---|---|---|---|---|---|
| `UC1` | POC Assistance | POC | 6 | `UC1.1`–`UC1.6` | foundational-setup |
| `UC2` | Intake Verification | IMPLEMENTATION | 6 | `UC2.1`–`UC2.6` | foundational-setup |
| `UC3` | Foundational Setup | BOTH | 19 | `UC3.1`–`UC3.19` | apigee-subscription, volume-assessment |
| `UC4` | Volume Assessment | IMPLEMENTATION | 6 | `UC4.1`–`UC4.6` | load-testing-spli, apigee-subscription |
| `UC5` | Load Testing (SPLI) | IMPLEMENTATION | 4 | `UC5.1`–`UC5.4` | environment-progression |
| `UC6` | Apigee Subscription | BOTH | 7 | `UC6.1`–`UC6.7` | postman-collection-generation, environment-progression |
| `UC7` | Postman Collection Generation | BOTH | 3 | `UC7.1`–`UC7.3` | end |
| `UC8` | Environment Progression | IMPLEMENTATION | 4 | `UC8.1`–`UC8.4` | apigee-subscription |

Every item is directly selectable. `_shared/item-catalogue.json` and
`agent/instructions/03_item-catalogue.md` carry the full list, plus a table of common partner
phrasings ("the ART or AIMS thing" → `UC3.11`) so requests can be matched to items.

## Field mapping to the Agent Admin UI

**Agent** — one only.

| Admin UI field | Source |
|---|---|
| Agent name | `agent/onboard360ai.json` → `name` |
| Description | → `description` |
| System instruction | → `systemInstructions` (14,461 chars) |
| User instruction | → `userInstructions` |
| Goals | → `goals[]` |
| Tools / functions | → `tools[]` |
| Questions | → `questions[]` — includes the entry-mode and PZTTD gate questions |
| Reference materials | upload `agent/instructions/*.md` |

**Skills** — repeat for each of the 8.

| Admin UI field | Source |
|---|---|
| Skill name | `skills/NN_<id>/skill.json` → `name` |
| Description | → `description` |
| System instruction | → `systemInstructions` |
| User instruction | → `userInstructions` |
| Reference materials | upload that skill's `instructions/*.md` |
| Questions | → `questions[]` |

## Before importing

1. **Confirm PZTTD.** The project key, the `^PZTTD-\d+$` format, and that features are children of
   the LJKX intake — the gate refuses anything whose parent is not an LJKX issue.
2. **Jira `get_issue_links`** is a new binding, needed for the parentage check. Without it the gate
   degrades to asking the partner to confirm the parent, recorded as partner-supplied.
3. **Confluence URLs** — still `<CONFLUENCE_URL:...>` placeholders.
4. **Upload every instruction file.** A skill without its instructions has key instructions but no detail.

## Enforcement note

`BR-25` and `BR-26` are the gate. As instructions the model may skip them under pressure from an
impatient partner. If the Tachyon contract layer can bind to skill entry, bind a `pre_skill` check:
*if entry is out of sequence and no verified `pzttdFeatureKey` is in state, block.* That makes the
gate structural rather than behavioural, which is what you want for a traceability rule.
