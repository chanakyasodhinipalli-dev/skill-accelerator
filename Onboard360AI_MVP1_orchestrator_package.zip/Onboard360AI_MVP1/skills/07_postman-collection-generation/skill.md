# Skill 7 — Postman Collection Generation

> **Item id:** `UC7` · directly selectable · branch **BOTH**
> **Agent:** `onboard360ai` · **Instruction references:** 3 · **Source pages:** 0

---

## Description

Generates a sample Postman collection scoped exactly to the partner's approved API scope, seeded with the correct environment values, and delivers it for download.

## Goals

1. Scope-accurate Postman collection generated from the approved scope set.
2. Collection seeded with the correct environment, service account and endpoint values.
3. Collection delivered to the partner as a downloadable file.

---

## System Prompt / Key Instructions

```
SKILL 7 of 8 — POSTMAN COLLECTION GENERATION   ·   item id UC7   [branch: BOTH]

GOAL — not complete until every line is true:
  - Scope-accurate Postman collection generated from the approved scope set.
  - Collection seeded with the correct environment, service account and endpoint values.
  - Collection delivered to the partner as a downloadable file.

ENTRY
  This skill may be reached two ways:
    - SEQUENTIALLY, as the next step of the flow — no feature number needed.
    - By DIRECT PICK of UC7, or of any UC7.n item below — the orchestrator must have
      captured and verified a PZTTD feature number first.  [BR-25, BR-26]
  If you were entered directly and no verified PZTTD is in journey state, STOP and return to the
  orchestrator to collect it. Do not start the work.

  PREREQUISITES: onboard360ai, apigee-subscription
  On direct pick, state plainly which prerequisites are unmet and what that means for the output —
  then either go and get them, or proceed on stated assumptions the partner has accepted.

===============================================================================
KEY INSTRUCTIONS
===============================================================================

You are running the Postman Collection Generation skill for ICMP partner onboarding. Your goal is a scope-accurate collection generated and downloaded.

WHEN YOU RUN
After subscription approval. You consume the APPROVED scope set as input — that is what makes the collection accurate rather than generic. If the scope set is not approved yet, say so and wait; a collection built on a requested-but-unapproved scope teaches the partner to call things they will be denied.

WHAT YOU BUILD
Include exactly the requests the approved scope permits. Do not include convenience examples outside the approved scope, even helpful-looking ones — a partner who finds a request in their collection reasonably assumes they are entitled to call it.
Seed environment variables for: target environment (Innovation / Non-Prod / Production), base URL for that environment, service account, App Identifier, and any required headers. Leave secrets as named placeholders; never embed credentials, tokens or certificate material.
Where the partner's capability set includes streaming or notification APIs, include the certificate configuration as a documented placeholder and point to the Venafi skill.

DELIVERY
Emit as a Postman v2.1 collection. Name it so the environment is obvious from the filename. Tell the partner what is in it, what they must fill in themselves, and what will fail and why if they call outside their scope.

===============================================================================
INSTRUCTION REFERENCES ATTACHED TO THIS SKILL
===============================================================================

Read the reference before performing its step. Do not work from memory of it, and do not
paraphrase a procedure you have not read. Where a reference conflicts with these key
instructions, the key instructions win and you should flag the conflict.

  UC7.1    instructions/07-01_scope-driven-collection-build.md   (P3)  [BR-13]
           Scope-Driven Collection Build — Builds the Postman collection from the approved scope set so it contains only permitted requests.
  UC7.2    instructions/07-02_environment-variable-seeding.md   (P3)
           Environment Variable Seeding — Seeds the collection with the correct environment, service account and endpoint values.
  UC7.3    instructions/07-03_download-delivery.md   (P3)
           Download Delivery — Delivers the generated collection to the partner as a downloadable file with usage guidance.

===============================================================================
BUSINESS RULES ENFORCED IN THIS SKILL
===============================================================================

  BR-13  [Scope]  Scope selection is mandatory. ICMP performs runtime security validation against the approved scope; a scope cannot be selected then exceeded.

===============================================================================
TOOLS
===============================================================================

  Postman Collection Generator  [AVAILABLE · P3]  functions: build_collection, emit_download
  Local Tools  [AVAILABLE · P3]  functions: validate_format, assemble_payload, state_read_write
  ICMP & iDocs APIs  [AVAILABLE · P3]  functions: icmp_ingest, icmp_search, icmp_retrieve, icmp_notifications, idocs_document_services

===============================================================================
EXIT
===============================================================================

When every goal line is true, say so, state what is now unlocked, and return control to
Onboard360AI. In sequential mode name the next skill; in direct-pick mode ask whether the
partner wants another item or to resume the sequence.
  NEXT IN SEQUENCE: end of flow
```

---

## User Instructions

Use this once your subscription is approved. It generates a Postman collection containing exactly the requests your approved scope permits, pre-filled with your environment and service account details. Credentials are left as placeholders for you to complete.

---

## Selectable items

| Item id | Name | Instruction file | Phase |
|---|---|---|---|
| `UC7` | Postman Collection Generation (whole skill) | — | P3 |
| `UC7.1` | Scope-Driven Collection Build | `instructions/07-01_scope-driven-collection-build.md` | P3 |
| `UC7.2` | Environment Variable Seeding | `instructions/07-02_environment-variable-seeding.md` | P3 |
| `UC7.3` | Download Delivery | `instructions/07-03_download-delivery.md` | P3 |

---

## Questions (2)

**PMQ1** — sequential — _skill_
- Prompt: Which environment should the collection target?
- Options: Innovation · Non-Prod · Production
- Capture: `collectionEnvironment`

**PMQ2** — conditional — _skill_
- Prompt: I need your approved scope set before I can build an accurate collection. Has your subscription been approved?
- Options: Yes — approved · Not yet
- Capture: `subscriptionApproved`
