# Onboard360AI — Single Consolidated Skill

The whole MVP1 architecture — **1 master agent, 8 sub-agents, 59 skills, 24 business
rules** — flattened into **one skill definition**, for testing.

Generated from the package, so it stays in sync with the decomposed version.

## Variants

| Variant | System prompt | ~Tokens | Contains |
|---|---:|---:|---|
| **FULL** | 170,872 chars | ~42.7k | Every skill's system instructions verbatim, plus steps, questions and reference materials |
| **COMPACT** | 137,143 chars | ~34.3k | Skill instructions trimmed to their first 14 lines; steps and reference lists dropped |
| **LEAN** | 87,261 chars | ~21.8k | Ordered steps only per skill; explanatory prose dropped. Load-bearing rules survive in sections 6 and 7 |

All three contain all 59 procedures, all 24 business rules, and the full reference
data. Start with **LEAN** unless you specifically need the prose.

## Files per variant

| File | Use |
|---|---|
| `*_system_prompt.txt` | Paste straight into the skill's System Instruction field |
| `*.json` | Programmatic import — matches `idox-skill/1.0` with `skillType: monolith` |
| `*.md` | Review copy: title, description, prompt, questions, references, component map |

## Structure of the prompt

```
0   Who you are — master over 8 stages, and itself a sub-agent of the
    Platform Specialist Agent
1   MVP 1 scope
2   Runtime disclosure rule + integration maturity model + current state by system
3   Detail acquisition order (context → KB → systems → partner) with provenance
4   Journey state — the full list the model must self-maintain
5   Operating protocol — stage order, hard prerequisites, how to move
6   Reference data — Jira keys, environments, ART/AIMS matrix, certificate
    subjects, tiers, App Identifier, NGDC, capabilities, repositories, volume
7   Business rules BR-01 … BR-24
8   Tools and functions
9   STAGE 0  — Onboard360AI entry            (4 procedures)
10  STAGE 1  — POC Assistance                (6)
11  STAGE 2  — Intake Verification           (6)
12  STAGE 3  — Foundational Setup            (19)
13  STAGE 4  — Volume Assessment             (6)
14  STAGE 5  — Load Testing (SPLI)           (4)
15  STAGE 6  — Apigee Subscription           (7)
16  STAGE 7  — Postman Collection Generation (3)
17  STAGE 8  — Environment Progression       (4)
18  Guardrails
19  Glossary
```

Section numbering mirrors the decomposed architecture, so a finding here maps
back to a specific agent or skill.

## What changed in the flattening

- The runtime disclosure block, phase statement and MVP note were repeated on all
  68 components. Stated **once**, in sections 1 and 2.
- Sub-agent **goals** became stage **terminal conditions** — section 5 tells the
  model it is not done with a stage until its goal is met.
- Agent-to-agent handoffs became **stage transitions** with the same
  prerequisites and gates.
- Scattered reference values were consolidated into **section 6** so the model
  has one place to look rather than finding them inside skill prose.

## What you lose

Worth knowing before you compare results against the decomposed version:

- **No enforcement points.** Contracts fired at pre-model, post-model, pre-tool
  and post-tool boundaries between components. One skill has no boundaries, so
  BR-01 key validation and BR-21 project key protection become instructions the
  model may ignore rather than gates it cannot pass.
- **No scoped tool surface.** Every tool is visible at every stage, so the
  "agent may only call tools it declares" property is gone.
- **Attention dilution.** ~22–43k tokens of instruction sit in front of every
  turn, including for a partner who only wants the POC path.
- **No isolated testing.** You cannot exercise one skill without the rest.
- **Self-maintained state.** Section 4 asks the model to track what the runtime
  tracked structurally, with provenance. Expect drift over a long session.

Useful as a baseline to measure the decomposed architecture against.
